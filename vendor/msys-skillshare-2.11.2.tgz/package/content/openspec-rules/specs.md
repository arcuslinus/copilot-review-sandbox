---
flags:
  acceptanceScenarios: true
  apiContracts: true
---
{%- if flags.acceptanceScenarios %}
- Use Given/When/Then format for acceptance scenarios
- Include error cases and permission/capability requirements
- Reference Zod schemas for any new validation rules
{%- endif %}
{%- if flags.apiContracts %}
- Specify GraphQL operation signatures (query/mutation name, input/output types) where applicable
- Specify REST API endpoint signatures (method, path, request/response types) where applicable
{%- endif %}
{{ customRules }}
