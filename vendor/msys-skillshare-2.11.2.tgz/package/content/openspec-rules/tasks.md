---
flags:
  tddWorkflow: true
  taskStructure: true
  formatStep: true
---
{%- if features.codingEngineers and engineers.length %}
- Assign the most relevant coding engineer to each task group; the available engineers and their domains are listed in {{ engineersListPath }} — read it first
- Group tasks by feature slice first (each `## N. Section` is a complete vertical increment), then by package/directory within a slice
- Use the heading format `### <package-or-scope> (<engineer-name>)`, with a name from {{ engineersListPath }}
- Keep each task mapped to a single engineer; if none fits, use a plain `### <scope>` heading
{%- endif %}
{%- if flags.tddWorkflow != false %}
- Before writing code, read existing implementations in the affected modules to identify and follow established patterns (naming, structure, error handling, abstractions, test style) — do not introduce new approaches when the codebase already has a convention
{%- if features.codingEngineers and engineers.length %}
- Follow TDD at the granularity of each feature slice. When one engineer owns both the tests and implementation for a slice, keep the full cycle in one task (write failing test → see it fail → implement → pass). When the slice's tests and implementation fall to different engineers (e.g. tests centralized under `src/` while the behavior is authored elsewhere), split the slice: the test-owning engineer writes the failing tests and confirms they fail, the implementing engineer(s) author the code, and a final `### Verify` group with no engineer assignment runs the suite green
{%- else %}
- Follow test-driven development (TDD) for each task: (1) write failing tests (2) verify they fail (3) implement the feature (4) verify tests pass
{%- endif %}
{%- endif %}
{%- if flags.taskStructure %}
- Break tasks into chunks that touch at most 2-3 packages
- Order tasks respecting any codegen dependency chains
- Include explicit codegen, migration, and type-generation steps where needed
{%- endif %}
{%- if flags.formatStep %}
- Include a formatting step for modified files using `{{ formatCommand }}`
{%- endif %}
{%- if customRules %}
{{ customRules }}
{%- endif %}
- Include one mandatory consistency-sweep task: for every value, name, or behavior changed during implementation, whole-tree grep the old and the new form and reconcile every restatement — proposal, design, tasks, the change's delta specs, the canonical specs (including pre-existing scenarios the change invalidates), the archive copy when present, code comments, and docs; a change that altered no shared fact completes this as a quick confirmation. This pre-merge task is positioned after all implementation task groups and any custom or repo-specific tasks, and before the remaining pre-merge tail tasks when present — QA instructions, post-merge checklist, docs revision (the template fixes its placement — no manual reordering needed)
{%- if features.skillsets %}
- The final task in `tasks.md` MUST be this dispatch invocation, ordered last (after any custom or repo-specific tasks) — it replaces the separate QA-instructions, post-merge-checklist, and docs-revise final tasks, since the dispatch triages and runs whichever of those apply. Use this exact task text: `(Mandatory, non-skippable) Invoke /dispatch wrap-up via the Skill tool — execute now, do not defer or list as remaining, do not gate on a question to the user. The dispatch triages which follow-up work applies (QA instructions, the post-merge checklist, docs-revise, commit/push/PR) and runs the scheduled members unattended.`
{%- else %}
{%- if flags.qaInstructions %}
- Before merging, invoke `/create-qa-instructions` via the Skill tool to generate QA instructions for this change and post them to the corresponding Jira ticket. This pre-merge task is positioned after any custom or repo-specific tasks (the template fixes its placement — no manual reordering needed)
{%- endif %}
{%- if flags.postMergeChecklist %}
- Before merging, invoke `/create-post-merge-checklist` via the Skill tool to derive this change's post-merge action items and post them to the corresponding Jira ticket. Generating and posting the checklist is a pre-merge step (it lands before the PR merges, even though the items it records run after merge). This task is positioned after any custom or repo-specific tasks and after the QA task when present (the template fixes its placement — no manual reordering needed)
{%- endif %}
{%- if features.autoDocs %}
- The final task in `tasks.md` MUST be the docs-revise invocation, ordered last (after any custom or repo-specific tasks). Use this exact task text: `(Mandatory, non-skippable) Invoke /docs-revise via the Skill tool — execute now, do not defer or list as remaining, do not gate on a question to the user. docs-revise itself determines whether any docs actually change.`
{%- endif %}
{%- endif %}
