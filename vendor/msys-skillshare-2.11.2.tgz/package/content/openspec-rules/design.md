---
flags:
  architecturePatterns: true
  dataChanges: true
---
{%- if flags.architecturePatterns %}
- Reference existing services and utilities before introducing new abstractions
- Include sequence diagrams for flows spanning multiple services or handlers
{%- endif %}
{%- if flags.dataChanges %}
- Address persisted query workflows if GraphQL operations are added or changed
- Consider reader/writer pool implications for database changes
- Note migration strategy and type regeneration steps if schema changes
{%- endif %}
{{ customRules }}
