---
flags:
  jiraConventions: true
  scopeBoundaries: true
  appImpact: true
  changeImpact: true
---
{%- if flags.jiraConventions %}
- When creating a change with "{{ runPrefix }} openspec new change", prefix the change name with the JIRA ticket ID (e.g. meis-1234-add-feature)
- Extract JIRA ID from branch name or conversation context; if unavailable, ask the user
{%- endif %}
{%- if flags.scopeBoundaries %}
- Include a "Non-goals" section to clarify scope boundaries
{%- endif %}
{%- if flags.appImpact %}
- Identify which apps and libs are affected
- Note if database migrations are needed
- Note if GraphQL schema changes are needed
{%- endif %}
{%- if flags.changeImpact %}
- Flag if changes touch shared infrastructure
- Flag if changes require infrastructure updates (new Lambda apps, ECS services, Temporal workers, S3 buckets, SQS queues, SNS topics, secrets, API Gateway endpoints, new environment variables, or changes to existing AWS resource configuration)
{%- endif %}
{{ customRules }}
