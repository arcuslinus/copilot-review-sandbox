---
name: docs-add
description: >
  Create new documentation in docs/ for undocumented modules, features,
  integrations, patterns, or infrastructure. Use when the user says "document
  this", "add docs for X", "write docs for the Y module", "this feature has no
  docs", "create a doc about Z", or mentions anything that should be documented
  but isn't yet. Also triggers when the user provides a topic as an argument
  (e.g. `/docs-add quote export`) — treat the argument as the subject to
  document.
license: MIT
compatibility: Requires docs/ directory with markdown files and a git repository.
metadata:
  author: meistersystems
  version: "1.0"
---

Create new documentation in `docs/` for a topic that has no documentation yet. Investigate the codebase to understand the subject, write thorough docs, and update the documentation indexes.

**Do NOT create documentation without explicit approval.** Always present the proposed documentation — by default a concise summary table (full content is shown on request) — and get user sign-off before writing any file.

---

> **Not compatible with `/batch`.** This skill must not be run via `/batch`.
> Documentation changes are interdependent (cross-references, shared README, scope checks) and require
> coordinated output. If you are a sub-agent spawned by `/batch`, **stop immediately** and report back
> that this skill cannot be parallelized via `/batch`. For initializing documentation across an entire
> repository, use `/docs-init` instead.

---

## Scope: `docs/` vs `openspec/`

This project separates **usage documentation** from **implementation specifications**:

<!-- prettier-ignore -->
| | `docs/` | `openspec/specs/` |
| --- | --- | --- |
| **Purpose** | How to use the system, general knowledge, feature docs | Implementation specs, design decisions, requirements, tasks |
| **Audience** | Developers using/operating the system | Developers building/changing the system |
| **Content** | Setup guides, architecture overviews, feature usage, troubleshooting | Requirements, design rationale, implementation plans, task lists |
| **Managed by** | These skills (`/docs-audit`, `/docs-revise`, `/docs-add`) | OpenSpec skills (`/openspec-*`) |

**This skill operates ONLY on `docs/`.** Never create or modify files in `openspec/`.
If the topic the user wants documented is actually an implementation spec (requirements, design decisions, task lists), explain that it belongs in `openspec/specs/` and suggest using the `/openspec-*` skills instead.

---

## Step 1: Identify the subject

Determine what needs documentation. The subject comes from one of:

1. **Skill argument** — the user invoked `/docs-add <topic>`. Use the argument as the subject.
2. **Conversation context** — the user mentioned something undocumented. Extract the subject from context.
3. **Ask the user** — if neither of the above provides a clear subject, ask what they want documented.

Once the subject is identified, confirm it with the user via the **AskUserQuestion** tool with options:

1. **Confirm subject (default)** — proceed with `{subject}` as the documentation subject.
2. **Refine subject** — let the user adjust the subject before proceeding.

The default is **Confirm subject**. In autonomous/non-interactive modes the default is selected automatically.

---

## Step 2: Cross-repo awareness check

Before creating documentation, verify the topic belongs in this repository and isn't already documented elsewhere.

### 2a. Check Atlassian MCP availability

Attempt to use the Atlassian MCP `search` tool. If it is unavailable (tool not found / not configured), call the **AskUserQuestion** tool with these options:

1. **Continue without cross-repo check (default)** — proceed with local-only behavior. Note in your output that cross-repo deduplication was skipped because the Atlassian MCP is not configured.
2. **Stop and configure Atlassian MCP** — explain that the Atlassian MCP enables cross-repo documentation deduplication via Confluence search, and stop execution so the user can configure it.

The default is **Continue without cross-repo check**. If selected, skip step 2b (Confluence search depends on the MCP) but still run step 2c — the repository scope check is local and does not depend on the MCP.

### 2b. Search Confluence for existing documentation

Use the Atlassian MCP `search` tool (Rovo Search) with a query derived from the topic:

```
search({ query: "<topic description>" })
```

Rovo Search is semantic — it matches across all Confluence spaces and returns ranked results with space keys. **Only consider results from the shared `docs` space** (all technical documentation lives there). Ignore results from other spaces. Classify each `docs`-space result:

- **Duplicate** (same topic, same intent, owned by another repo) → Inform the user: _"Documentation on this topic exists in the docs space under {repo}: '{page title}'. Consider linking to it instead of creating a duplicate."_ Let the user decide whether to proceed, link, or stop.
- **Related** (overlapping topic, different angle, owned by another repo) → Note as a **cross-reference candidate**. Collect the page title, Confluence page-ID URL, and owning repo name. These will be offered as cross-repo links in Step 5.
- **Owned by the current repo** → related documentation already exists locally. Call the **AskUserQuestion** tool with options `Update existing (default)` / `Create new`. The default is **Update existing**, which avoids duplication.
- **No relevant hits** → proceed normally.

### 2c. Check repository scope

Read `docs/README.md` and look for the **Scope** section. If it exists, check whether the topic falls within this repository's stated ownership:

- **"Owns" list includes the topic's domain** → proceed normally.
- **"Does not own" list includes the topic's domain** → warn the user: _"Based on this repository's scope, {topic} belongs in {other-repo}. Consider documenting it there instead."_ Let the user decide.
- **No `docs/README.md` or no Scope section** → skip the scope check and proceed normally.

---

## Step 3: Investigate the codebase

Read the source code to understand the subject thoroughly. Do not write docs from memory or assumptions — base everything on what the code actually does.

Search strategy:

```bash
# Find relevant source files
find apps/ libs/ -type f -name "*.ts" -o -name "*.tsx" | xargs grep -l "subject-keyword"

# Check for existing mentions in docs
grep -r "subject-keyword" docs/ --include="*.md"

# Check for related config, env vars, migrations
grep -r "subject-keyword" .env* docker-compose* apps/*/src/config/
```

Build understanding of:

- **What it is** — the module, feature, or concept and its purpose
- **How it works** — key files, entry points, data flow, dependencies
- **How to use it** — configuration, commands, API surface, UI flows
- **How it relates** — connections to other parts of the system
- **Prerequisites** — what needs to be set up or configured first
- **Gotchas** — edge cases, limitations, common mistakes

---

## Step 4: Determine file placement

Choose the right location in `docs/` based on what the subject is:

<!-- prettier-ignore -->
| Subject type | Location | Example |
| --- | --- | --- |
| System design, data flow | `docs/architecture/{topic}.md` | `docs/architecture/caching-layer.md` |
| User-facing feature | `docs/features/{feature-name}/overview.md` | `docs/features/webhooks/overview.md` |
| Feature-specific setup | `docs/features/{feature-name}/setup.md` | `docs/features/sap-s4hana/setup.md` |
| Feature architecture | `docs/features/{feature-name}/architecture.md` | `docs/features/sap-s4hana/architecture.md` |
| How-to, runbook | `docs/guides/{topic}.md` | `docs/guides/redis-caching.md` |
| **General** dev setup | `docs/setup/{topic}.md` | `docs/setup/getting-started.md` |
| Strategy, direction | `docs/steering/{topic}.md` | `docs/steering/api-strategy.md` |

**Feature organization rules:**

- Organize features by **business feature name**, not by app or library (e.g. `sap-s4hana-integration`, not `msys-sap-client`).
- Always create `overview.md` as the primary entry point. Add `setup.md`, `architecture.md`, `usage.md`, or `troubleshooting.md` as separate files when content is substantial enough.
- Feature-specific setup (env vars, third-party credentials, service config) goes in `docs/features/<name>/setup.md`, **not** in `docs/setup/`.
- `docs/setup/` is for **general** setup only (dev environment, tooling, onboarding). Add cross-references from `docs/setup/` to feature setup docs where relevant.

**Filenames and directories MUST be kebab-case.** Every `{topic}` and `{feature-name}` placeholder above is filled with lowercase ASCII letters and digits, with hyphens between words — no camelCase, snake_case, PascalCase, spaces, or uppercase letters. The only exception in `docs/` is `README.md`. See the **File Naming** section of `references/doc-conventions.md` for the full rule and examples.

Check for existing docs that partially cover the subject — it may make more sense to extend an existing doc than to create a new one.

---

## Step 5: Draft documentation

Write complete documentation, not outlines or stubs. Follow the conventions in `references/doc-conventions.md`.

Every doc must include:

- **H1 title** — clear, descriptive name for the topic
- **Overview paragraph** — what it is and why it exists (1–3 sentences, directly after H1)
- **Body sections** — organized by H2 headings, covering the areas identified in Step 2

Content guidelines:

- **Be specific** — use exact file paths, package names, and commands from the codebase
- **Include code examples** — show real usage, not hypothetical snippets
- **Commands must be copy-pasteable** — full commands, not fragments
- **Cross-reference** — link to related docs using relative paths
- **No filler** — every line should add value
- **No implementation specs** — focus on usage, not design rationale
- **Use compact table format** with `<!-- prettier-ignore -->` before each table

**Cross-repo references (from Step 2):**

If Step 2 collected cross-reference candidates (related content in other Confluence spaces), incorporate them into the draft:

- **Inline links** — where the draft text naturally mentions a topic covered by a cross-reference candidate, insert a page-level Confluence link with repo attribution (e.g., `([Page Title](confluence-url) in \`repo-name\``))
- **"Related documentation" footer** — add an `## Related documentation` section at the end of the doc listing all cross-repo references (including those already linked inline), using the format: `- [Page Title](confluence-url) (\`repo-name\`) — brief description`
- Do not force inline links where the topic is not naturally mentioned — the footer section is the catch-all
- Follow the cross-repo reference conventions in `references/doc-conventions.md`

For **feature docs**, create separate files in `docs/features/<feature-name>/`:

- `overview.md` — what and why (always create)
- `architecture.md` — key components and data flow (when non-trivial)
- `setup.md` — settings, env vars, prerequisites, third-party config (when applicable)
- `usage.md` — how to use it with examples (when substantial)
- `troubleshooting.md` — common issues and solutions (when known issues exist)

Name the feature folder by business feature, not by app/lib name.

For **architecture docs**, include:

- Overview — high-level description
- Components — key modules and responsibilities
- Data flow — how data moves through the system
- Entry points — where things start
- Technology choices — what's used and why (briefly)

For **guides**, include:

- Overview — what this guide covers
- Prerequisites — what you need before starting
- Steps — numbered, concrete instructions
- Verification — how to check it worked
- Troubleshooting — common issues

---

## Step 6: Show proposed documentation

**Before showing the user**, scan every proposed file and verify each markdown table starts with `<!-- prettier-ignore -->` and uses compact (no column padding) format. Fix any non-compliant tables in the drafts before presenting.

Present a concise summary table of all proposed files. Do NOT show full content by default — let the user request specific files or apply all at once:

```
## Proposed new documentation

<!-- prettier-ignore -->
| # | File | Action | Summary |
| --- | --- | --- | --- |
| 1 | docs/features/webhooks/overview.md | Create | What webhooks are, supported event types, delivery guarantees |
| 2 | docs/features/webhooks/setup.md | Create | Endpoint registration, signature verification, env vars |
| 3 | docs/features/webhooks/architecture.md | Create | Dispatcher topology, retry/backoff, dead-letter handling |
```

The `Action` column is always `Create` — docs-add only adds new files. The `Summary` is a one-line natural-language description of what the file covers (subject + placement rationale combined).

If cross-repo references were included, list them as separate, individually-approvable items below the summary table:

```
**Cross-repo references (approve or reject individually):**
- [a] Inline: [Page Title](url) in `repo-name` (line ~N) — {brief context}
- [b] Footer: [Page Title](url) (`repo-name`) — {description}
```

After showing the table, you **MUST** call the **AskUserQuestion** tool with the following options. Do not substitute a prose question, even if the choice feels binary — the options below are deliberate (defaults wired into auto/non-interactive modes).

1. **Apply all (default)** — create every proposed file without showing full content first.
2. **Show specific files first** — ask which numbered items to display (e.g. "1, 3"), show those file contents, then **re-prompt with the same four options** before proceeding.
3. **Show all content first** — display the full proposed content of every file, then **re-prompt with the same four options**.
4. **Request changes** — describe what to revise; the skill will redraft and re-prompt with the same four options.

The default is **Apply all**. In autonomous/non-interactive modes the default is selected automatically.

After every "Show specific files first" / "Show all content first" / "Request changes" branch, the skill MUST call `AskUserQuestion` again with the same four options — only `Apply all` proceeds to Step 7.

For per-item rejection or cross-repo reference approval, accept follow-up free-text when the user chooses "Show specific files first" or "Request changes" (e.g. "skip 2 and reject b").

---

## Step 7: Create with approval

1. Create only the files the user approved (everything if `apply all`, otherwise the items not rejected)
2. Format all new files:
   ```bash
   {{ formatCommand }} <new-files>
   ```
3. Show a summary of what was created

---

## Step 8: Update scope descriptor and documentation index

After the new documentation is created, follow the procedure in `references/readme-maintenance.md`:

1. **Check `docs/README.md` scope descriptor** — if the new documentation covers a domain not yet listed in the "Owns" section, propose adding it. If `docs/README.md` doesn't exist or has no Scope section, create one by investigating the codebase. When a scope update is proposed, call the **AskUserQuestion** tool with options `Apply scope update (default)` / `Skip scope update`. The default is **Apply scope update**.
2. **Regenerate root `README.md` documentation index** — auto-generated index of all doc files. No additional approval needed since it's a mechanical update.

---

## Guardrails

- **Investigate first** — always read the source code before writing docs; never write from assumptions
- **Get approval** — every new doc needs explicit user sign-off before creation
- **Complete docs only** — never create stubs, placeholders, or TODO-filled outlines
- **Stay in scope** — only create files in `docs/`. Never create or modify files in `openspec/`.
- **Respect doc conventions** — follow the project's formatting standards (see `references/doc-conventions.md`)
- **Don't duplicate** — check for existing docs that cover the subject before creating new ones; extend if appropriate
- **Run Formatter** — always format new files before finishing
- **No git operations** — Never commit, push, create branches, or open pull requests. The skill's job ends at writing files to disk and formatting them. Git operations are the user's responsibility.
- **Sub-agent boundaries** — Sub-agents write files only when the skill explicitly directs them to. Sub-agents never perform git operations (commit, push, branch, PR). In all other phases, sub-agents only read files and return structured results.
