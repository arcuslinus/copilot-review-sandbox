# README Maintenance Procedure

Maintain the `docs/README.md` scope descriptor and the root `README.md` documentation index.

---

## `docs/README.md` — scope descriptor

`docs/README.md` is the repository's scope descriptor. It defines what the repo owns and what belongs elsewhere. It is rendered as the Confluence stub page body (the repo's documentation entry point). It does **not** contain a documentation index — the index lives only in the root `README.md`.

```markdown
# {Repository Name}

{1-2 paragraph description of what this repository is and what it does.}

## Scope

**Owns:** {comma-separated list of domains, modules, features this repo is responsible for}

**Does not own:** {comma-separated list of things that belong elsewhere, with which repo owns them}
```

---

## Step 1: Check scope descriptor

Read `docs/README.md`. If it does not exist, create it with the structure above — investigate the codebase to determine what the repository owns. If it exists, check whether the scope section is still accurate given the work just completed:

- **New domain or feature added** → add it to the "Owns" list if not already there
- **Domain moved to another repo** → move it from "Owns" to "Does not own" (with target repo)
- **Description outdated** → update the description paragraph

If the scope section needs changes, show the proposed update and get user approval. The scope section is important for cross-repo documentation awareness — it determines whether docs-* skills recommend documenting a topic here or in another repo.

If `docs/README.md` exists but has no Scope section (e.g., it only has a TOC), replace it with the scope descriptor structure above. Investigate the codebase to determine what to put in the Owns/Does not own lists.

---

## Step 2: Scan docs/

Find all `.md` files in `docs/`, excluding `docs/README.md` itself:

```bash
find docs/ -name "*.md" -type f ! -path "docs/README.md" | sort
```

---

## Step 3: Extract descriptions

For each file, extract a one-line description using this fallback chain:

1. **First sentence after H1** — if the file starts with `# Title` followed by a paragraph, use the first sentence of that paragraph
2. **First sentence under `## Overview`** — if no immediate paragraph after H1, look for an Overview section
3. **H1 text** — if neither of the above yields a description, use the H1 title itself

Keep descriptions concise (one sentence, no trailing period).

---

## Step 4: Group by category

Group files by their immediate subdirectory under `docs/`:

<!-- prettier-ignore -->
| Subdirectory | Category name |
| --- | --- |
| `architecture/` | Architecture |
| `features/` | Features |
| `guides/` | Guides |
| `setup/` | Setup |
| `steering/` | Steering |

If a new subdirectory exists that is not listed above, add it as a new category using the subdirectory name in title case.

Files directly in `docs/` (not in a subdirectory) go under a "General" category.

---

## Step 5: Generate root `README.md`

The root `README.md` has three sections. The first two are **stable** (preserved if they already exist), the third is **auto-generated**.

### Section 1: Introduction (stable)

If the root `README.md` already contains content before the "Quick links" or "Documentation" heading, **preserve it exactly as-is**.

If it does not exist yet, write a short introductory paragraph about the project.

### Section 2: Quick links (stable)

If a "Quick links" section already exists, **preserve it exactly as-is**.

If it does not exist yet, create a quick links table:

```markdown
## Quick links

<!-- prettier-ignore -->
| Resource | Link |
| --- | --- |
| Getting started | [Setup guide](docs/setup/getting-started.md) |
| Troubleshooting | [Troubleshooting guide](docs/guides/troubleshooting.md) |
| AI skills | [AI skills guide](docs/guides/ai-skills.md) |
| Project structure | [Project structure](docs/architecture/project-structure.md) |
| Tech stack | [Tech stack](docs/architecture/tech-stack.md) |
| Scripts reference | [Scripts reference](docs/guides/scripts-reference.md) |
```

Only include links to files that actually exist. Remove rows for missing files.

### Section 3: Documentation (auto-generated)

This section is always regenerated. Replace everything from the `## Documentation` heading to the end of the file:

```markdown
## Documentation

> Auto-generated table of contents. Do not edit manually — maintained by `/docs-add`, `/docs-audit` and `/docs-revise` skills.

### {Category}

<!-- prettier-ignore -->
| Document | Description |
| --- | --- |
| [{filename}](docs/{relative-path}) | {description} |
```

- One table per category, sorted alphabetically by category name
- Within each table, sort rows alphabetically by filename
- Links use `docs/` prefix (e.g., `docs/architecture/foo.md`)
- Use the filename without extension as the display name, converted to title case with hyphens replaced by spaces
- **Always use compact table format** (no column padding) with `<!-- prettier-ignore -->` before each table to prevent merge conflicts

---

## Step 6: Format

Run Formatter on both files:

```bash
{{ formatCommand }} docs/README.md README.md
```

Formatter will format prose and lists but will **not** re-pad tables, because each table is preceded by a `<!-- prettier-ignore -->` comment.
