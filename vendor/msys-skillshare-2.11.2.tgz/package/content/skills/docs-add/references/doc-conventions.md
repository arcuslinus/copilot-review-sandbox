# Documentation Conventions

Standards for the `docs/` knowledge base in this project.

## File Organization

```
docs/
├── architecture/       # System design, module relationships, data flow
├── setup/              # Development environment, deployment, configuration
├── guides/             # How-to guides, troubleshooting, runbooks
├── features/           # Feature documentation (grouped by feature)
│   └── feature-name/   # e.g. sap-s4hana-integration, embeddable-wizard
│       ├── overview.md
│       ├── configuration.md
│       └── usage.md
└── steering/           # Product direction, tech strategy, team structure
```

## File Naming

All markdown files in `docs/` MUST use **kebab-case**: lowercase ASCII letters and digits, with hyphens between words. No camelCase, snake_case, PascalCase, spaces, or uppercase letters.

<!-- prettier-ignore -->
| Good | Bad |
| --- | --- |
| `confluence-sync.md` | `confluenceSync.md`, `Confluence-Sync.md`, `confluence_sync.md` |
| `getting-started.md` | `gettingStarted.md`, `GettingStarted.md` |
| `aws-infrastructure.md` | `AWS.md`, `aws_infrastructure.md` |
| `overview.md` | `Overview.md` |

The same rule applies to **directories** under `docs/` (e.g. `docs/features/sap-s4hana-integration/`, not `docs/features/sapS4hanaIntegration/`).

The single exception is `README.md`, which keeps its conventional uppercase name.

**Why kebab-case?** Consistency makes navigation, linking, and convention enforcement easier. Lowercase avoids case-sensitivity surprises across filesystems. Hyphens read better than underscores or camelCase in URLs (Confluence pages and direct GitHub links).

## Heading Structure

- **H1 (`#`)**: Document title — one per file, matches the topic
- **H2 (`##`)**: Major sections
- **H3 (`###`)**: Subsections
- **H4 (`####`)**: Only when H3 needs subdivision; avoid going deeper

Keep headings concise and descriptive. Use sentence case, not title case.

## Code Blocks

Always specify the language for syntax highlighting:

````markdown
```typescript
const example = "always specify language";
```
````

For shell commands, use `bash`:

````markdown
```bash
npm run dev
```
````

Commands should be copy-pasteable. Include the full command, not fragments.

## Diagrams

Use **mermaid** for diagrams that show flows, relationships, sequences, or state transitions — chart types mermaid renders well:

````markdown
```mermaid
graph TD
    A[Client] --> B[API Gateway]
    B --> C[Backend Service]
    C --> D[(Database)]
```
````

Choose the right mermaid diagram type:

- `graph TD` or `graph LR` — data flow, architecture, component interactions
- `sequenceDiagram` — request/response flows, multi-step processes
- `stateDiagram-v2` — state machines, lifecycle transitions
- `erDiagram` — data models, entity relationships

### When NOT to use mermaid

Use plain **`text` code blocks** for flat dependency lists, component inventories, and simple hierarchical trees. Mermaid turns these into verbose star graphs that are harder to read than the text original:

````markdown
```text
api-handler (Lambda)
  ├── @org/core           (CoreService, CorePlugIn)
  ├── @org/accounts       (AccountService, PermissionService)
  ├── @org/integrations   (IntegrationService -- API key lookup)
  └── @org/events         (EmitEvent)
```
````

**Rule of thumb:** if the diagram shows a _flow_ (A → B → C) or _interactions_ between components, use mermaid. If it shows a _flat list_ with a single parent (one root, N leaves), use a `text` block.

### Mermaid style conventions

Our docs are published to Confluence via the mermaid-cloud plugin, which supports full HTML formatting and Font Awesome icons. Write mermaid diagrams with these conventions to ensure they render well on Confluence.

**Subgraphs** — use flat (single-level) subgraphs to group related nodes. Do not nest subgraphs inside each other; nested subgraph titles render behind child nodes in most renderers. Let arrows convey hierarchy instead:

````markdown
```mermaid
graph TD
    subgraph layer1["Application layer"]
        A["Entry point"]
    end

    subgraph layer2["Service layer"]
        B["Business logic"]
    end

    A --> B
```
````

**Labels** — use standard double-quoted strings with HTML for rich formatting. Do not use backtick-quoted markdown syntax (`` ["`**bold**`"] ``) as it is not supported by most renderers:

- `["Label text"]` — standard rectangle
- `<br/>` for line breaks (not `\n`)
- `<b>` for bold, `<i>` for italic, `<code>` for monospace/code references
- `<ul><li>item</li></ul>` for bullet lists inside node labels
- Wrap nodes containing bullet lists in `<div style='text-align:left'>` for left alignment

**Font Awesome icons** — prefix node labels with `fa:fa-*` icons for visual distinction on Confluence. Common icons:

- `fa:fa-server` — backends, API services
- `fa:fa-database` — databases, data stores
- `fa:fa-bolt` — event systems, triggers
- `fa:fa-puzzle-piece` — plugins, modules, extensions
- `fa:fa-cogs` — services, processing engines
- `fa:fa-cloud` — external/cloud services
- `fa:fa-envelope` — messaging, notifications
- `fa:fa-shield` — auth, security

Use any other Font Awesome icon (`fa:fa-*`) when it better represents the concept — browse [Font Awesome v4 icons](https://fontawesome.com/v4/icons/) for the full set.

> **Note:** FA icons render on Confluence but show as text (`fa:fa-server`) in local editors (WebStorm, GitHub). This is an accepted trade-off.

> **Padding:** Add `&nbsp;` on every node label and subgraph title that uses an FA icon to prevent text clipping on Confluence. The mermaid-cloud plugin's width calculation does not account for icon width, causing the rightmost characters to be cut off. Place `&nbsp;` **before the first `<br/>`** (to pad the icon line, not a subsequent line). For labels without `<br/>`, place it at the end.
>
> - Multi-line: `["fa:fa-server <b>API Gateway</b> &nbsp;<br/><code>apps/backend</code>"]`
> - Single-line: `["fa:fa-bolt <b>Domain Events</b> &nbsp;"]`

**Node shapes** — use shape variations for visual distinction:

- `["..."]` — rectangle (default, for services and components)
- `[("...")]` — cylinder (databases, data stores)
- `{"..."}` — diamond (decision points)
- `(["..."])` — stadium (queues, event buses)

**Edge labels** — use `-->|"label"|` for short annotations on arrows. Keep labels brief.

**Complete example** using HTML formatting, FA icons, and bullet lists:

````markdown
```mermaid
graph TD
    API["fa:fa-server <b>API Gateway</b> &nbsp;<br/><code>src/api</code>"]
    SVC["fa:fa-cogs <b>Order Service</b> &nbsp;<br/><div style='text-align:left'><ul><li>Create orders</li><li>Calculate pricing</li><li>Apply discounts</li></ul></div>"]
    DB[("fa:fa-database <b>PostgreSQL</b> &nbsp;<br/><i>Order tables</i>")]
    EVENTS(["fa:fa-bolt <b>Domain Events</b> &nbsp;"])
    PLUGIN["fa:fa-puzzle-piece <b>Export Plugin</b> &nbsp;<br/><code>ExportPlugIn</code>"]

    API -->|"POST /orders"| SVC
    SVC --> DB
    SVC -->|"OrderCreated"| EVENTS
    EVENTS --> PLUGIN
```
````

## Cross-References

Link to other docs using relative paths:

```markdown
See [Architecture overview](../architecture/overview.md) for details.
```

When referencing source code files, use the repo-root-relative path:

```markdown
Entry point: `src/main.ts`
```

### Cross-repo references

When documentation from another repository is related to the current topic, link to it using Confluence page-ID URLs. All technical documentation lives in the shared `docs` Confluence space — cross-repo references link to other pages within this space that are owned by different repositories.

**Inline links** — use where the topic is naturally mentioned in the text, with the repository name for attribution:

```markdown
Authentication uses the same JWT middleware as the platform
([Platform Auth](https://foundfair.atlassian.net/wiki/spaces/docs/pages/4371447809/Auth+middleware) in `ms-platform`).
```

**"Related documentation" footer section** — add at the end of the file as a catch-all for all cross-repo references, including those already linked inline:

```markdown
## Related documentation

- [Auth Middleware](https://foundfair.atlassian.net/wiki/spaces/docs/pages/4371447809/Auth+middleware) (`ms-platform`) — JWT issuance, token format, RBAC roles
- [Sync Pipeline](https://foundfair.atlassian.net/wiki/spaces/docs/pages/1234567890/Sync+pipeline) (`msys-pim`) — Product data flow that triggers webhooks consumed here
```

**Rules:**

- **Same space only** — only cross-reference pages within the shared `docs` Confluence space. Ignore results from other spaces.
- Use **page-level links only** — do not append heading-level fragment anchors (`#heading-text`) as they break when headings are renamed on the target page
- Use **page-ID-based URLs** (`/wiki/spaces/docs/pages/PAGEID/Page+Title`), not display URLs (`/wiki/display/docs/Page+Title`)
- Cross-repo links resolve on Confluence, not in local markdown — this is acceptable since the target repo's docs aren't local anyway

## Tables

Use tables for structured comparisons. To reduce merge conflicts, always use **compact format** (no column padding) and add a `<!-- prettier-ignore -->` comment before each table to prevent Prettier from re-padding it:

```markdown
<!-- prettier-ignore -->
| Package | Purpose |
| --- | --- |
| `@org/backend-lib` | Core backend logic |
| `@org/common` | Shared utilities |
```

**Why compact?** Formatter pads table cells to align columns. When one cell's content changes width, every row is reformatted. In a multi-branch workflow this causes merge conflicts across the entire table — even when different branches edited different rows. Compact tables make each row independent.

## Content Guidelines

- **One concept per paragraph** — keep paragraphs short
- **Lead with the most important information** — don't bury the lede
- **Be specific** — use exact file paths, package names, and commands
- **Stay current** — update docs when the code they describe changes
- **No filler** — every line should add value; skip obvious information
- **Concrete over abstract** — prefer examples and commands over descriptions

## Architecture Docs

Should include:

- High-level system diagram (use mermaid — see Diagrams section)
- Key modules and their responsibilities
- Data flow between components
- Entry points and bootstrapping sequence
- Technology choices and rationale

## Setup Docs

Should include:

- Prerequisites (tools, versions, accounts)
- Step-by-step setup instructions with commands
- Configuration file locations and key settings
- Common troubleshooting steps
- How to verify the setup worked

## Feature Docs

Feature docs describe **how a feature works** from a user/developer perspective. They live in `docs/features/<feature-name>/`.

Should include:

- Overview — what the feature does and why it exists
- Configuration — settings, environment variables, prerequisites
- Usage — how to use it, with examples and code snippets
- Troubleshooting — common issues and solutions

Should NOT include (these belong in `openspec/specs/`):

- Implementation requirements
- Design decisions and rationale
- Implementation plans or task lists
- Technical spike results

## What does NOT belong in docs/

The following content is managed by OpenSpec and lives in `openspec/specs/`:

- Implementation specifications and requirements
- Design decisions with rationale
- Implementation plans and task breakdowns
- Change proposals and design documents

If you find this kind of content in `docs/`, flag it as misplaced.

## Formatting

- Format all docs: `{{ formatCommand }} docs/`
- Use standard Markdown (CommonMark compatible)
- One blank line between sections
- No trailing whitespace
- Files end with a single newline
