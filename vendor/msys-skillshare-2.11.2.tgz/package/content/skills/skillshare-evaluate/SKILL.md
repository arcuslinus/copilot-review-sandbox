---
name: skillshare-evaluate
description: Evaluate a repository's always-on AI instruction file (CLAUDE.md / AGENTS.md / cursor / copilot) for quality and size, then suggest and apply size-reducing improvements. Use when the user wants to reduce CLAUDE.md size, shrink the instruction footprint, analyze always-on instructions, audit instruction bloat, trim the per-interaction context cost, find redundant or relocatable instruction content, or says "evaluate instructions", "my CLAUDE.md is too big", "reduce instruction size", "what's bloating my AGENTS.md", "analyze the instruction footprint", or "clean up the instruction file". Runs the deterministic `skillshare analyze` CLI and reasons over its output to rank findings and apply local fixes through source-of-truth paths.
license: MIT
---

# Evaluate Skillshare Instructions

Analyze the repository's generated always-on instruction body for **quality** and **size**, rank size-reducing
findings, and — on confirmation — apply the locally-actionable ones through their source-of-truth path. The goal is to
minimize the **skillshare-managed** always-on footprint: that body is loaded on **every** interaction, so every token it
spends is a token spent on every turn.

> **Scope the claim to the managed surface.** This skill measures and edits only the skillshare-managed instruction
> body — **not** "the entire per-interaction context". Other always-on files co-reside at runtime (the developer's
> global `~/.claude/CLAUDE.md`, other tools' personal instruction files) and stack with this body, but they are **not**
> skillshare-managed or repo-actionable. The skill MUST NOT edit them. When such a co-resident file is detectable,
> surface a **one-line advisory** naming it as unanalyzed, so the scope boundary is acknowledged rather than implied
> away; cross-file duplication against it is **advisory only**.

> **Why size matters (the principle, not a cliff).** Always-on instructions compete for a finite **attention budget**
> with diminishing returns (Anthropic, *Effective context engineering*, 2025); the aim is "the smallest set of
> high-signal tokens." Research shows degradation begins **well below** the context window — mid-context recall drops
> (*Lost in the Middle*, Liu et al. 2023), reasoning degrades from ~3K tokens (*Same Task, More Tokens*, Levy et al.
> 2024; *Context Rot*, Chroma 2025). The most damaging content is **semantically-redundant, low-signal text** — exactly
> what R4/R7/R10/R11 target. The size thresholds below are engineering **heuristics, not proven failure points**. Speak
> in **tokens** first, bytes second.

This skill is a **deterministic-CLI + judgment split**: the `skillshare analyze` command does the trustworthy work
(resolve the single shared body, segment it into sections and `###` sub-sections, measure tokens/bytes/lines, attribute
each segment's sharing **`scope`**, build the catalog map) and emits JSON; this skill reasons over that JSON (rule
detection, ranking, apply). **Do not re-derive the measurements by hand** — consume them from the CLI.

> **Sizes from JSON, content from SOURCE.** Take all sizes, tokens, and the sharing `scope` from
> `analyze --json`. But content-level rules require reading the **source** splices — `.skillshare/instructions/*.md` and
> `content/instructions/base.md` — not the generated instruction file, which is gitignored/absent in most repos and
> must not be relied on. The coverage check (Step 5) additionally reads `docs/` and the catalog item `description`s to
> decide delete-vs-relocate.

> **One body per repo.** Instruction templates are tool-agnostic, so the rendered body is byte-identical across every
> synced tool — only the wrapper differs. Judge it **once**. The per-interaction cost is one file; the per-tool count is
> blast-radius / maintenance leverage, not per-interaction cost. Never sum sizes across tools.

---

## Step 1: Analysis is sync-independent

**No prior sync required** — but you still need an `analyze`-capable CLI. "No sync" means *don't regenerate files
first*; it does **not** mean analysis runs with no binary. `skillshare analyze` re-renders the body from current sources
(`base.md` + the worktree splices), so it works even when no managed file is on disk. When a live managed file **is**
present, it also does a best-effort read of it to report a **live-vs-prospective divergence** (see Step 7). Use the
`analyze`-capable CLI for the current context (Step 3): the installed `skillshare` in a consumer repo, or the
working-tree CLI `bun src/cli.ts analyze` in the skillshare repo itself when the released global CLI predates `analyze`.

`skillshare sync` belongs **after** apply, not before it: a confirmed **local** edit (splice / `repo.yml` / custom
skill) only becomes live once you re-sync the managed file (Step 7).

- **In a consumer repo:** post-apply sync is `{{ runPrefix }} skillshare sync`.
- **In the skillshare repo itself** (dogfooding): post-apply sync is the **globally-installed** `skillshare sync`,
  **not** the working-tree CLI (`bun src/cli.ts` / `bun skillshare`). The repo deliberately dogfoods the last released
  version; the working-tree CLI may refuse the released-schema config or apply an unreleased schema.

> `skillshare check` remains the strict CI/correctness gate for stale renders; `analyze` only surfaces an
> **informational** live-vs-prospective divergence warning when a live managed file is present.

> **Report-only / audit path.** If the user asks only to *audit* or *analyze* (no apply), run `analyze --json`, present
> the ranked findings (through Step 6), and **stop before the confirmation gate**. Step 7 applies only to the default
> apply flow.

## Step 2: Detect repo mode

Decide whether this is the **skillshare repo** or a **consumer repo** — it governs what may be edited later (Step 6).

- **Skillshare repo:** `package.json` `name` is `@msys/skillshare`, or `content/instructions/base.md` is present. Here
  the shared `base.md` and shared skills ARE the source of truth, so `skillshare-shared` findings may be edited.
- **Consumer repo:** anything else. Here `skillshare-shared` content is managed/regenerated and is **never** edited;
  such findings are advisory only.

## Step 3: Consume the analyzer output

Run `analyze --json` with the context-appropriate binary and reason over its output. In a **consumer repo** run
`{{ runPrefix }} skillshare analyze --json`. In the **skillshare repo itself** (dogfooding, where the released global
CLI may predate `analyze`) run the working-tree CLI `bun src/cli.ts analyze --json`. The JSON carries:

- **Per-section breakdown** — each `##` section with `tokensApprox`, `bytes`, lines, and percent of the surface
  (preamble/unsectioned content is its own segment). The body total carries `tokensApprox` and `bytes` too.
- **`subSections[]`** — each `##` section has a nested `###` breakdown, each sub-section carrying its own
  `tokensApprox`/`bytes`/percent and `scope`. Use this to decompose a heavy section into its sub-blocks (Step 4).
- **Sharing scope** — each section and sub-section carries a single `scope` field, one of
  `skillshare-shared` (distributed by the `@msys/skillshare` package), `repo-shared` (committed `.skillshare/` content,
  team-shared), `user-global` (personal `~/.skillshare` content, all your repos), or `user-repo` (personal gitignored
  content, this repo only) — plus `spliceFile` (the owning `.skillshare/instructions/*.md` for the three local scopes,
  else `null`) and its gating flag/feature. `skillshare-shared` is editable only inside the skillshare repo itself; the
  other three scopes are locally editable from the current repo/user config.
- **Catalog map** — `catalog.skills[]` and `catalog.agents[]`, each with a `name`, a `description` (from the item's
  frontmatter; may be `null`), and the same `scope` field, marking what is **distributed** by `@msys/skillshare`
  (`scope === "skillshare-shared"`) vs the three local scopes (`.skillshare/instructions/*.md`, `.skillshare/skills/`,
  `~/.skillshare`). Match section/sub-block **topics** against these `description`s (Step 5).
- **`managedHeader`** — the stripped managed-file header text (excluded from the body total and section percentages —
  `analyze` strips the wrapper before measuring). Use it to evaluate **R7**: routing guidance the header already
  conveys.
- **Size signals** (Step 4).

## Step 4: Read the SIZE signals

The CLI computes these; report on them in **tokens first** (bytes secondary), do not recompute:

- **Per-section breakdown** — `tokensApprox`/bytes/lines/% per section and per sub-section.
- **Section-share severity** — a section is flagged when it exceeds **>15%** of the surface **or >800 B**.
- **`sizeRating`** — total body classified **lean (≤4 KB) / moderate (4–8 KB) / bloated (>8 KB)** (this field replaces
  the former `budgetBand`).

**Share/severity is for RANKING only — never a filter.** Use it to order findings, not to decide which blocks to
audit. The size-independent content rules (R3, R6, R9, R10) apply to **every** section and sub-block regardless of its
share — coverage is enforced by the **disposition table** (Step 6), which carries one row per analyzer-emitted block.
**Decompose each `##` section via `subSections[]`** (don't treat a spliced section as one opaque blob); the
low-signal / reference tail aggregate — the bytes reclaimable from the long tail of small blocks that individually fall
below the severity threshold but add up — is reported alongside that table.

> The analyzer emits all sub-blocks in `subSections[]`, and may emit a `hasNormativeVerb`-style hint per block. When
> present, use it to surface static-reference candidates (R3) — but still sweep every block; the hint is a lead, not a
> filter.

## Step 5: Run the detection ruleset

These rules came from a real four-repo audit (msys-skillshare, ms-platform, infra, msys-pim). Apply them
**catalog-driven and domain-generic** — match a section's (or sub-block's) **topic** against the catalog entries'
**`description`** fields, **never against item names** and never against a hardcoded list. When you defer to a skill,
name the specific skill the catalog matched.

### Relocation — content that should move off the always-on surface

- **R1 — tool/prompt-mechanics prose.** A section explains how to operate a tool or how to prompt, and carries **no
  repo-specific token** (no repo name, path, command, or convention unique to this repo). → Move off the surface
  (delete-vs-relocate per the procedure below).
- **R2 — owned by an available skill or agent.** A section narrates a workflow whose responsibility is already owned by
  an available skill or agent. Match the section/sub-block **topic** against the catalog entries' `description` fields
  (not their names); name the **specific** skill to defer to. → Already covered on-demand → **delete** the always-on copy.
- **R3 — static reference data.** A pure enumeration with **no do/never/always directive** — directory trees, port
  maps, environment-variable lists, command internals duplicating `--help`. → Move off the surface to `docs/` (procedure below).
- **R16 — workflow/behavioral directive.** A section commands **what to do during the development workflow** — e.g.
  "create a changeset at the end", "cut a release after merge", task-shaping or pre-merge obligations. → Relocate to the
  **OpenSpec-rules layer** (`.skillshare/openspec-rules/<artifact>.md`, composed into `openspec/config.yaml` and loaded
  when an `openspec-*` workflow runs), **not** to `docs/` and **not** deleted merely because a `docs/` page covers it.
  Name the OpenSpec-rules layer because the dev workflow here almost always runs through OpenSpec, making it a reliable
  **push** trigger (the AIM-97 precedent moved OpenSpec-workflow prose off `base.md` by the same logic). When a specific
  catalog skill instead owns the topic, **R2 governs** — relocate into that skill. R16 is distinct from R1
  (tool-mechanics → docs/skill) and R3 (reference → docs).

#### Delete-vs-trim-vs-relocate — coverage-aware action selection

For **any** block that does not earn its always-on cost (R1/R2/R3/R16, or any low-signal finding), choose the action by
**two tests, not coverage alone** — because *how* content reaches the agent matters:

1. **Is the block behavioral or reference?** A **behavioral directive** carries a do/never/always/use verb; **reference**
   content is a pure enumeration with none (the same normative-verb signal R3 uses).
2. **Does a reliable PUSH trigger exist?** A **push** trigger surfaces content at the moment it is needed without the
   agent deciding to look — an auto-firing catalog skill/agent (matched by `description`), the OpenSpec-rules layer that
   loads when the workflow runs, or content that **is** default agent behavior. A `docs/` page is a **pull** resource:
   the agent reads it only **after** it has already decided to look, so the research task must itself be the trigger.

> grep / read `docs/` for the topic AND check the catalog skills/agents (match topic against their `description`s, not
> names) before acting — `docs/` is rarely empty, but a `docs/` hit only settles the **pull** question.

Act from the resulting cell:

```
                    │ Reliable PUSH trigger exists       │ No reliable trigger
                    │ (auto-skill/agent, OpenSpec-rules  │ (agent won't know to
                    │  layer, or IS default behavior)    │  look at the right time)
────────────────────┼────────────────────────────────────┼─────────────────────────
 Reference          │ DELETE (R3 — agent pulls docs      │ DELETE; keep a one-line
 (no directive)     │ when researching; the task is the  │ pointer only for a
                    │ trigger)                           │ specific non-obvious cue
────────────────────┼────────────────────────────────────┼─────────────────────────
 Behavioral         │ RELOCATE to that trigger layer     │ KEEP (one-line directive)
 (directive /       │ (skill body per R2 / OpenSpec rule │ — the always-on slot's
 obligation)        │ per R16), then delete the          │ actual job; or CREATE a
                    │ always-on copy                     │ trigger, then relocate
```

The operative rule: **a `docs/` page is sufficient grounds to DELETE a reference block, but never sufficient grounds to
delete a behavioral directive.** A behavioral directive leaves the always-on surface **only** when a push trigger will
surface it — relocate into the owning skill (R2) or the OpenSpec-rules layer (R16), or recognize it as default behavior
(R9) — otherwise **keep** it. Deleting "create a changeset at the end" because `docs/guides/releasing.md` exists removes
the behavior: the agent never reads `docs/guides/releasing.md` because nothing told it a release is owed.

Then the standard rungs apply within that rule:

- **Fully covered by a PUSH surface** (a catalog skill/agent owns it, or it is default behavior) → **DELETE** the
  always-on copy — a generalization of R5 to any on-demand push surface. Do **not** leave a pointer.
- **Reference fully covered by `docs/`** → **DELETE** (the pull model is fine here — the research task is the trigger).
- **Partially covered** (only part of the block is covered elsewhere) → **TRIM** to the unique, **not-elsewhere-covered
  residual** and delete the covered portion. `trim` is the middle rung between delete and relocate, and also subsumes
  **R14 compaction** — compacting verbose wording to its directive is a trim.
- **Worth keeping, no PUSH home exists** → create the home (a `docs/` page for reference, a skill via Step 8, or an
  OpenSpec-rule for a workflow directive) **then delete** the always-on copy.
- **Not worth keeping, no home** → delete outright.

A fix **MUST NOT grow the always-on surface**: prefer deletion or relocation over a per-section pointer. Leave a pointer
**only** for a specific, non-obvious trigger that an existing general directive in the body would not already surface.

### Redundancy — content already stated elsewhere

- **R4 — cross-section duplication.** The same atomic rule appears in ≥2 sections. → Flag the later occurrences.
- **R5 — duplicates a distributed item.** A locally-scoped finding (`scope` is `repo-shared`, `user-global`, or
  `user-repo`) covers a **topic** already owned by a distributed catalog item (`scope === "skillshare-shared"`) —
  matched against that item's `description`, not its name. → Recommend removing the local copy and using the distributed
  version instead.
- **R6 — tooling-enforced restatement.** The content restates behavior already enforced by a lint rule, a configured
  hook, or a formatter. → Flag as redundant with the tooling.
- **R7 — header-redundant routing.** Routing guidance that the managed-file header (`managedHeader`, Step 3) already
  conveys — check the body against that emitted text. → Flag.
- **R8 — cross-splice duplication.** The same fact appears in ≥2 splices feeding one surface. → Flag the duplicate.

### Verbosity — low-signal bytes

- **R9 — self-discoverable content.** A bullet states something the agent reliably **discovers or does on its own** —
  default tool behavior, self-evident facts, or conventions it would infer from the codebase without being told (e.g.
  "check `package.json`", "read the README", an obvious convention evident in the code). → Recommend deletion. (This is
  the verbosity-side mirror of the `keep` test's "not obvious / not default" criterion, Step 6a.)
- **R10 — rationale clauses.** Justification/rationale that does not change behavior ("because…", "deliberately…"). →
  Recommend trimming.
- **R11 — bullet-repeat.** More than three bullets restating a single directive. → Recommend collapsing to one.
- **R14 — compactable instruction prose.** An always-on section/sub-block keeps its directive but spends excess tokens on
  it — signals: negative framing ("don't…/never…") with no positive target, vague adjectives ("concise/precise/clearly")
  with no measurable constraint, shouting ("CRITICAL/MUST/ALWAYS"), rationale that doesn't change behavior, or one rule
  spread across several sentences. → A **`trim`** disposition: **compact affirmative rewrite per
  `references/writing-instructions.md`** (the rewrite standard this skill includes below), reported with estimated tokens
  saved and applied through the source-of-truth path, subject to the same do-no-harm re-analysis (Step 7).

### Flags / features — always-on cost with no value

- **R12 — enabled feature, empty splice.** An enabled instruction-contributing feature whose repo-local splice file is
  empty pays always-on cost with no repo-specific value. → Flag the feature.
- **R13 — unused-feature content.** An enabled feature injects content for technology or workflows the repo does not
  use. **Verify against the repository's actual stack FIRST** — this has low false-positive tolerance; only flag when
  the stack confirms the feature is unused.

### Conflicts — opposing directives that both render

- **R15 — conflicting directives.** Two directives command **incompatible/contradictory** behavior — within the body
  AND **across scopes** (e.g. a `skillshare-shared` base rule vs a `repo-shared`/`repo-local`/`user-*` splice rule),
  across sections, or across gated blocks. Because composed content is **additive, never overridden**, both render and
  the agent sees both. → Report each conflict's **two locations + their scopes**, the nature of the contradiction, and a
  **recommended resolution** (which directive should win, or escalate to the human when precedence is genuinely
  ambiguous). Never silently resolve it. **Distinct from redundancy** (R4/R5/R8 = the *same* rule stated twice; R15 =
  *opposing* rules).

> **The rewrite standard for R14** — every compact affirmative rewrite must obey these principles:

{% include "references/writing-instructions.md" ignore missing %}

## Step 6: Disposition table, then rank and group

### 6a — Per-block disposition (provable coverage)

**Before ranking**, produce a disposition for **every** section and sub-block the analyzer emits — one row per block,
**anchored to the analyzer's enumerated `subSections[]`** (not your recollection of the body). Each row carries a
verdict ∈ **`keep` / `trim` / `delete` / `relocate`** plus its **triggering rule id** (or a one-line reason for `keep`).
This makes coverage **provable, not aspirational**: a block you would otherwise silently dismiss becomes a visible
`keep` row with a stated reason, so no block is skipped without a trace.

- **`keep`** — earns its always-on cost by the **positive test** below; cite which criteria it meets in one line.
- **`trim`** — partially covered elsewhere (reduce to the unique residual) **or** R14-compactable (see Step 5).
- **`delete`** — fully covered / not worth keeping (Step 5 procedure).
- **`relocate`** — worth keeping but has no on-demand home yet (create one, then delete — Step 5 / Step 8).

**A `keep` is earned by a positive test, not by the absence of a delete-rule.** A block earns its always-on slot only
when **ALL** of: (1) it **changes behavior**; (2) **no reliable push trigger** (auto-firing skill/agent, the
OpenSpec-rules layer, or default agent behavior) would surface it at the moment it is needed; (3) it is **not obvious /
not default behavior**. Each `keep` row must state **which criteria it satisfies** ("changes behavior; no push home;
not default"), not "looked important". The canonical keepers are cross-cutting obligations with no single workflow home
("prefix branches with the JIRA id", "never edit managed files").

**Trigger reliability is a judgment, not a mechanical preference.** When a behavioral directive *could* relocate to a
push surface but that trigger is **not guaranteed to fire** — e.g. work that sometimes happens outside any OpenSpec
workflow — weigh the reliability and you **MAY keep** a one-line always-on directive as cheap insurance (citing trigger
unreliability) rather than mechanically relocating. This stops R16 from over-correcting into "relocate every behavioral
block".

The transient table is working output — it costs **zero** always-on tokens. The size-independent content rules (R3,
R6, R9, R10) apply to every row regardless of share; reducible small blocks roll up into the low-signal/reference tail
aggregate (Step 4).

### 6b — Rank and group

**Priority** = estimated **tokens saved** × **confidence** × **editability**.

- **Confidence:** **A = 1.0** (holds across all repos) · **B = 0.7** · **C = 0.4** (uncertain / heuristic).
- **Editability** is derived from each finding's `scope`: a finding is **locally editable = 1.0** when its `scope` is
  `repo-shared`, `user-global`, or `user-repo` (changeable from the current repo/user config), or when `scope` is
  `skillshare-shared` **and** this is the skillshare repo. A `skillshare-shared` finding in a **consumer** repo is
  **advisory = 0.5** (not editable here).

The grouping is **data-driven**: read each finding's source section/sub-section `scope` field (combined with repo mode),
rather than inferring it.

- **Locally editable** — `scope` is `repo-shared` / `user-global` / `user-repo` (changeable via flags/features in
  `repo.yml`, splice edits/dedupe, or custom skills), or `skillshare-shared` when running inside the skillshare repo.
- **Advisory (`skillshare-shared` in a consumer)** — originates in shared `base.md` or shared skills; not editable here,
  presented as advisory only. In the **skillshare** repo this same scope is itself locally editable (Step 7).

Present the **full** ranked findings list in **prose** (unbounded), each tagged with its `scope`, whether it is locally
editable or advisory, and the estimated tokens saved — including the low-signal/reference tail aggregate (Step 4).

Then gate application with **one bounded strategy question** via the AskUserQuestion tool — e.g. *apply all
high-confidence locally-editable fixes (default) / select a subset / none*. **Never map one option per finding:** the
tool caps at four options, so a per-finding menu would silently drop findings beyond the cap. If the user picks *select
a subset*, collect the subset in prose (by finding number). The number of findings must never be limited by the menu.

**Partition the gate.** The default *apply all* bucket contains **only** findings that are **high-confidence (A) ∧
locally editable ∧ low-blast-radius**. **Low-confidence (B/C)** findings and **high-blast-radius**
`skillshare-shared`/upstream findings (e.g. a behavioral rewrite that lands in **every** consuming repo) MUST be
**excluded** from *apply all* and require a **separate, explicit opt-in** — never one click into an all-repo rewrite.

## Step 7: Apply (repo-aware, behind confirmation)

Gate on the confirmation from Step 6, then apply each confirmed **locally-editable** finding through its source-of-truth
path:

- **Flag / feature lever (R12, R13, redundant gated content)** → flip the flag or feature in `.skillshare/repo.yml`.
- **Splice edit / dedupe (R4, R8, R9, R10, R11)** → edit or de-duplicate the relevant `.skillshare/instructions/*.md`
  splice.
- **Delete / relocate (R1, R2, R3, R16)** → follow the delete-vs-relocate procedure (Step 5): delete a **reference**
  block when an on-demand home covers it; relocate a **behavioral directive** to a push surface (the owning skill per
  R2, or `.skillshare/openspec-rules/<artifact>.md` per R16) rather than deleting it as docs-covered; else create the
  home (a `docs/` page, a skill via Step 8, or an OpenSpec-rule) then delete.
- **Use the distributed version (R5)** → remove the local copy; rely on the `@msys/skillshare`-distributed item.

**Repo-aware boundary:**

- **Consumer repo:** apply locally-editable fixes only (`scope` is `repo-shared` / `user-global` / `user-repo`);
  **never edit a managed file** (anything whose first lines say `Managed by @msys/skillshare`). `skillshare-shared`
  findings are presented as advisory and are NOT applied.
- **Skillshare repo:** on confirmation you MAY apply `skillshare-shared` findings to the shared `base.md` or shared
  skill source — this is the source of truth, and the fix propagates to every consumer on their next sync.

### Verify — split local vs upstream

`analyze` measures a **prospective** worktree body (re-rendered from current sources); the live managed file uses the
**released** templates until the next release + reinstall. So verification differs by scope:

- **LOCAL edit** (splice / `repo.yml` / custom skill — `repo-shared` / `user-global` / `user-repo`): re-run
  `skillshare analyze` and confirm (1) the body **shrank**, (2) **rule preservation — proven, not asserted**, and (3)
  **no new finding** was introduced (e.g. a redundant pointer — a do-no-harm re-scan). Report the savings as
  **MEASURED**. Then re-sync (`{{ runPrefix }} skillshare sync`, or global `skillshare sync` in the skillshare repo) to
  make the edit live.

  **(2) is a falsifiable directive diff, not "I didn't lose a rule":** inventory the **operative directives** (the
  imperative `do` / `never` / `always` / `use` rules) **before** and **after** the apply, and confirm
  **after-set = before-set − exactly the deletions the disposition table marked intended** (`delete`/`trim` rows). Any
  directive that disappears **without** a matching intended `delete`/`trim` is a **regression that BLOCKS the apply** —
  report the lost directive instead of confirming the change.
- **UPSTREAM edit** (`skillshare-shared` `base.md` / shared skill — only in the skillshare repo): verify by **source
  diff**, not by a live re-analyze. Report the savings as **PROJECTED** — "lands for all repos next release +
  reinstall" — **never** as a measured live reduction.

## Step 8: Relocation gap — scaffold a new skill

When a relocation finding (R1/R2/R3/R16) has **no matching skill** in the catalog map that owns the topic, offer to
**scaffold a new skill** via the `skillshare-create-skill` skill and move the content into it as part of applying the
fix. Do not reimplement skill creation — compose `skillshare-create-skill`.

---

## Guardrails

- **Don't sync before analyzing** — `analyze` re-renders independently; sync is a **post-apply** step that makes local
  edits live (global `skillshare` in the skillshare repo; `{{ runPrefix }} skillshare` in consumers).
- **Consume `skillshare analyze --json`; never recompute sizes or the catalog map by hand.** Report in **tokens**
  first. For content checks read the **source** splices and `docs/`, not the generated file.
- **Disposition table = provable coverage** — every analyzer-emitted block gets a `keep`/`trim`/`delete`/`relocate`
  verdict + rule id/reason **before** ranking, anchored to `subSections[]`. Share/severity ranks findings, it never
  filters which blocks are audited; report the low-signal tail aggregate.
- **Earn `keep` by a positive test** — a block keeps its always-on slot only when ALL hold: it changes behavior, no
  reliable push trigger would surface it, and it is not obvious/default; the row cites which criteria it meets. When a
  behavioral directive could relocate but the trigger isn't guaranteed to fire, you MAY keep a one-line directive as
  insurance rather than relocate.
- **Push vs pull decides delete vs relocate** — a `docs/` page is a **pull** resource: it justifies **deleting
  reference** content (the research task is the trigger), but **never** a behavioral directive. A behavioral directive
  leaves the surface only via a **push** trigger — relocate into the owning skill (R2) or the OpenSpec-rules layer
  (`.skillshare/openspec-rules/<artifact>.md`, R16), or recognize it as default behavior — else keep it. Partial
  coverage (or R14-compactable) → **trim** to the unique residual; never grow the surface with a per-section pointer.
- **Catalog-driven, never hardcoded** — R2/R5 match topics against catalog entries' `description` fields; never against
  item names and never a baked-in list.
- **R15 ≠ redundancy** — flag opposing directives (within the body and across scopes); both render because content is
  additive. Report both locations + scopes and a recommended resolution.
- **Never edit a managed file in a consumer repo** — route every fix to `repo.yml`, a splice file, or a custom skill.
- **Partition the gate** — *apply all* holds only high-confidence ∧ locally-editable ∧ low-blast-radius findings;
  low-confidence and high-blast-radius `skillshare-shared` findings need a separate opt-in. Confirm via one bounded
  strategy question (AskUserQuestion); the 4-option cap must never limit the findings.
- **Verify local vs upstream apart** — LOCAL edits report MEASURED savings, proven by a **before/after directive diff**
  (after = before − intended `delete`/`trim`; an unintended drop BLOCKS the apply) plus a do-no-harm re-scan; UPSTREAM
  edits report PROJECTED savings (source diff; lands next release + reinstall).
- **R13 verifies against the real stack first** — keep unused-feature false positives low.
- **Scope to the managed surface** — measure/edit only the skillshare-managed body; never sum sizes across tools (the
  per-tool count is blast-radius), and never edit co-resident always-on files (global `~/.claude/CLAUDE.md`, other
  tools' personal instructions) — surface them as a one-line unanalyzed advisory.
