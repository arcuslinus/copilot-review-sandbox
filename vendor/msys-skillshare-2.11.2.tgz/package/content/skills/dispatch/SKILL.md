---
name: dispatch
description: >
  Triage which post-implementation follow-up skills apply to the current change
  and run them unattended as background jobs. Use when the user says "dispatch",
  "/dispatch", "run the wrap-up dispatch", "run the review dispatch",
  "run wrap-up", "run review", "hand this off", or wants to trigger
  QA instructions, the post-merge checklist, docs-revise, commit/push/PR,
  implementation verification, or review-resolution as one batch after
  finishing implementation. Also triggers when a `tasks.md` final task or
  another skill instructs invoking `/dispatch <skillset>`.
license: MIT
compatibility: >
  Requires a `skillshare` CLI new enough to support `skillshare skillset <name> --json`
  (run `skillshare sync` to pick up the current release if the command is unrecognized).
metadata:
  author: meistersystems
  version: "1.0"
---

Triage the post-implementation follow-up work that applies to the current change, show the triage preview, then immediately run the scheduled members unattended — the preview is shown for visibility, not as a gate; the engine never waits for confirmation. A "skillset" (`wrap-up`, `review`, …) is a named group of member skills declared in each member's own frontmatter; this skill never hand-enumerates members — it always asks `{{ runPrefix }} skillshare skillset <name> --json` for the current, config-resolved table.

**Invocation:**
- `/dispatch <skillset>` — run the named skillset (e.g. `/dispatch wrap-up`)
- `/dispatch` — infer the skillset from context; if ambiguous, prompt with the declared skillsets

---

## Step 1: Resolve the skillset

If the invocation named a skillset, use it and announce it: "Using skillset: `<name>`."

**Validate `<name>` before it reaches any shell command.** It MUST match the registry's kebab-case grammar `^[a-z0-9]+(?:-[a-z0-9]+)*$` (lowercase letters and digits, single hyphens between). If it doesn't match, stop and report the invalid name — never interpolate an unvalidated name into the `skillshare skillset <name>` command in Step 2, since shell metacharacters in it could execute an unintended command (quoting alone does not prevent every expansion). A context-inferred name is always one of the declared skillsets and so already satisfies this.

Otherwise, infer from context when unambiguous — e.g. implementation just finished with no open PR review activity implies `wrap-up`; an open PR with review comments implies `review`. If it cannot be inferred:

```bash
{{ runPrefix }} skillshare skillset --list --json
```

Use the **AskUserQuestion tool** to present the declared skillsets (name + description) as options, with `wrap-up` marked as the default (the common post-implementation case). In auto/non-interactive contexts the default is selected automatically.

## Step 2: Get the member table from the CLI

Run exactly this — never enumerate, guess, or hard-code members yourself:

```bash
{{ runPrefix }} skillshare skillset <name> --json
```

- **If the command errors because `skillset` is not a recognized subcommand**: the installed `skillshare` CLI predates this feature. Report that plainly ("the installed skillshare CLI doesn't support `/dispatch` yet — update `@msys/skillshare` and run `skillshare sync`, then retry") and **stop without spawning anything**.
- **If the command errors for any other reason** (feature disabled, invalid member block, unknown skillset): surface the CLI's error message verbatim and stop without spawning anything.
- **On success**, parse the JSON: `{ name, description, members: [{ skill, when, phase, writes, runsOn, modelTier, source }] }`. This exact list is the only candidate pool for the rest of the run. `runsOn` (`main` | `subagent` | `any`) declares which execution lane a member is pinned to — see Step 5. `modelTier` (`sm` | `md` | `lg` | `inherit`) is the member's already-resolved effective model tier for a spawned sub-agent — see Step 5's tier→model map.

## Step 3: Single-pass triage

Read the current change's context once:

1. Resolve the change (from an argument, conversation context, or — if ambiguous — `openspec list --json` plus the **AskUserQuestion tool**, same convention as `openspec-verify-change`).
2. `openspec status --change "<name>" --json` for `changeRoot` and `artifactPaths`; read every existing artifact (proposal, design, tasks).
3. Read the working diff (`git diff main...HEAD` or equivalent) for behavior the artifacts don't capture.
4. If there is no OpenSpec change in scope (no `openspec/` root, or none found), fall back to the working diff and recent commit log alone — triage still runs, just against thinner context.

Evaluate every member's `when:` condition from Step 2 against this context **in one pass**. For each member, decide in/out and write a one-line reason grounded in the change (not a restatement of `when:`). Show the **full** result — scheduled and skipped — as the preview the engine prints right before it starts running (Step 4), split into two sections ordered by the sequence members will run in. The `Scheduled` table carries a `Wave` column — the user-facing spawn-order label: wave `1` is the `phase: work` members (spawned together), wave `2` is the `phase: publish` members (run after wave 1 completes) — plus `Member` and `Reason`. Order rows by wave. The `Skipped` list is triaged-out members with just `Member` and `Reason`. Do not surface `phase` or `writes` as their own columns — the wave number and ordering already carry the ordering, and `writes` governs scheduling only, not display:

```
Scheduled (3)
| Wave | Member                 | Reason                                          |
|:----:|------------------------|-------------------------------------------------|
|  1   | create-qa-instructions | change alters the login form's observable flow  |
|  1   | docs-revise            | change alters documented auth setup steps       |
|  2   | git-commit-push-pr     | working tree has changes and no PR exists yet   |

Skipped (1)
| Member                      | Reason                                   |
|-----------------------------|------------------------------------------|
| create-post-merge-checklist | no rollout step needs to run after merge |
```

Members triaged out (the `Skipped` list) never become spawn candidates.

**Evaluate `phase: publish` members against the tree as it WILL be after the work phase, not only as it is now.** A publish member whose `when:` depends on working-tree changes (e.g. `git-commit-push-pr`) must be scheduled when a scheduled wave-1 writer (`writes: true`, e.g. `docs-revise`) is expected to produce changes — even if the tree is clean at triage time. Triage stays single-pass; you simply account for the wave-1 writers' expected output when deciding publish membership. A publisher scheduled this way no-ops safely if the expected changes never materialize.

## Step 4: Show the preview, then start immediately

Print the Scheduled/Skipped split from Step 3 exactly as laid out above — the two tables are **required**; they are the user's visibility into what is about to run and why. Then **start running the scheduled members right away**.

- **Do not ask for confirmation.** No AskUserQuestion, no proceed/adjust/cancel prompt, no pause for approval — showing the tables is not a gate. Print them and move straight into Step 5 in the same turn.
- The scheduled set is exactly the triaged-in members from Step 3; the `Skipped` members never run. If the user wants a different selection they can interrupt and re-invoke — the engine never blocks waiting for that.
- Every scheduled member runs **unattended** for the rest of this dispatch under the autonomy contract: no member asks the user anything.

## Step 5: Run the scheduled members

Split the scheduled members into the **work phase** (`phase: work`) and the **publish phase** (`phase: publish`). Within the work phase, members with `writes: true` run **serialized** with respect to each other (never concurrently); non-writing members run in parallel with everything else in the phase. The publish phase starts **only after every work-phase member has finished** — this is the publish fence, so `git-commit-push-pr` always sees the tree after `docs-revise` and friends have written to it. Cap concurrency the way `docs-audit` does (a handful of members at once is normal; don't fan out beyond what the set realistically contains).

If a work-phase writer fails, still collect the rest of the work phase's results, but do not start the publish phase silently — surface the failure alongside the publish phase's default action (proceed with publish is the default when the failures are non-blocking reports; a failed writer blocks publish) as part of the final summary.

The execution mechanism is set by the `mode` setting (`features.skillsets.settings.mode`, default `subagents`) and the tool's capability — the same choice `coding-engineers` makes:

**Model tiers for this tool:** `sm` → `{{ model.sm }}`, `md` → `{{ model.md }}`, `lg` → `{{ model.lg }}`, `inherit` → `inherit` (a tier this tool doesn't define also resolves to `inherit`). This map only matters when actually spawning a sub-agent — `modelTier` is **moot** for `runsOn: main` members and for every member in `skills` mode: both run in the main session on its own model, so there's no per-spawn model to pick.

{%- if settings.skillsets.mode == "subagents" and target.supportsAgents %}
**Spawn scheduled members as background sub-agents**, following the phase/serialization rules above — with the main agent itself treated as an additional execution lane alongside the sub-agent lanes:

- **The main lane pulls only `runsOn: main`-pinned members.** A scheduled member declaring `runsOn: main` runs **inline on the main agent** — invoke its skill directly via the Skill tool in the main session, never spawn it as a sub-agent — concurrently with whatever sub-agents are spawned for the same wave. `runsOn: subagent` and `runsOn: any` (the default) are equivalent under this scheduling: both are spawned as sub-agents.
- **Scheduling is declarative, not auto-balancing.** When none of the scheduled members declare `runsOn: main`, nothing changes from today: every member is spawned as a sub-agent and the main agent orchestrates and waits. Never pull a `subagent`/`any` member onto the main lane just because the main lane is idle.
- **Writer serialization holds across lanes.** Within a wave, no two `writes: true` members run concurrently regardless of which lane they're on — a `runsOn: main` writer and a spawned sub-agent writer never overlap; if both are scheduled in the same wave, run them one after the other.
- **Spawn each sub-agent member on the model resolved from its effective `modelTier`.** Take the member's `modelTier` from the Step 2 table, look it up in the tier→model map above, and pass the resulting model to the Agent tool for that member. An effective `inherit` (or a tier this tool doesn't define, which also resolves to `inherit`) spawns the sub-agent on the parent/default model — pass no override.
- Everything else is identical for main-lane and sub-agent members: the autonomy contract, the change context, and the structured outcome report described below.

For each sub-agent-lane member, spawn the Agent tool with a prompt that contains, in full:

1. **The instruction to invoke the member's own skill via the Skill tool** — e.g. "Invoke the `docs-revise` skill via the Skill tool and follow it completely."
2. **The change context**: the change name and every artifact path read in Step 3 (proposal/design/tasks, and note that a diff is available via `git diff`).
3. **The autonomy contract**, embedded verbatim from the section below — do not restate or summarize it, include the full text.
4. **The instruction to end with a structured outcome report**: what ran, what was produced (files, links, Jira comments posted), which defaults were applied (and for which prompt), and any failures or hard-stops.

For a `runsOn: main` member, apply the same autonomy contract and outcome-report instruction directly in the main session — there is no spawn prompt to construct, and no model to resolve (`modelTier` has no effect on a main-lane member).

Wait for a phase to fully complete (respecting writer serialization, including across the main/sub-agent boundary) before starting the next phase.
{%- else %}
**Run the scheduled members inline, sequentially, in phase order** (work members first, publish last) — reached either because `mode: skills` was chosen or because this target has no sub-agent support (automatic fallback). For each member in turn: invoke its skill directly via the Skill tool in the main session, applying the same autonomy contract (embedded verbatim from the section below) and the same "end with a structured outcome report" instruction. Triage, the preview, phase ordering, and the contract semantics are unchanged; only the execution mechanism (inline instead of spawned) differs. `writes` no longer affects scheduling here (execution is already sequential), and `runsOn` is **moot** — there is no sub-agent lane to place a member off of, so every member (regardless of `runsOn`) runs the same way, inline in the main session. `modelTier` is moot for the same reason — there is no sub-agent to spawn, so the effective tier is never looked up and every member runs in the main session on its own model.
{%- endif %}

### Autonomy Contract

{% include "references/autonomy-contract.md" %}

## Step 6: Outcome summary

Once every spawned or inline member has finished (or hard-stopped), report a per-member summary: success/failure, key artifacts produced (PR URL, posted Jira comments, docs changed), defaults each member applied, and any hard-stops. If the publish phase was blocked by a failed work-phase writer, say so explicitly and name what still needs manual attention.

---

## Guardrails

- **Never hand-enumerate members** — the CLI's `--json` output is the only source of truth for who's in a skillset; a member frontmatter edit or `user.yml` override always takes effect on the next run, no caching.
- **No confirmation prompt** — Step 4 prints the Scheduled/Skipped preview and the run starts immediately; the tables must still be shown every time, but the engine never waits for approval and members never ask anything once spawned.
- **Respect the publish fence** — never start `phase: publish` members before every `phase: work` member has finished.
- **Serialize writers** — two `writes: true` members in the same phase never run concurrently, regardless of execution lane (a `runsOn: main` writer and a spawned sub-agent writer never overlap).
- **`runsOn: main` is a hard pin, never an auto-pull** — only members that declare it run on the main lane; when none do, spawn everything and let the main agent orchestrate, exactly as before this field existed.
- **CLI version mismatch stops the run** — an unrecognized `skillset` subcommand means the installed CLI predates this feature; report and stop, don't fall back to guessing members.
- **The contract is invocation-scoped** — it applies to every spawned/inline member because they're running as skillset members, independent of whether the main session itself is interactive.
