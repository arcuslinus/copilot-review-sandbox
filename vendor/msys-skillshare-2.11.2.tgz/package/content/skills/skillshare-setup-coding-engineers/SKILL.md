---
name: skillshare-setup-coding-engineers
description: >
  Bootstrap coding engineer definitions for a repository. Analyzes the repo structure,
  tech stack, and package layout, then proposes a set of engineer definitions and
  scaffolds each one. Use when the user says "setup engineers", "bootstrap engineers",
  "set up coding engineers", "analyze repo for engineers", or wants to create
  all engineer definitions at once. Requires the coding-engineers feature to be enabled.
---

Analyze this repository and set up coding engineer definitions.

**Steps**

1. **Check for existing engineers**

   Read `.skillshare/engineers/` — if engineer files already exist, list them and ask
   whether to propose additional engineers or skip existing domains.

2. **Analyze the repository structure**

   Scan the repo to understand:
   - Monorepo layout (apps/, packages/, libs/, infra/)
   - Tech stack per area (React, Node, CDK, database ORMs, etc.)
   - Directory patterns that map to distinct domains
   - Existing coding skills or instruction files for reference

3. **Propose engineers**

   Present a proposed list of engineers to the user using **AskUserQuestion** with multiSelect.
   Each proposal should include:
   - Suggested name (kebab-case, ending in `-engineer`)
   - Domain scope (which directories/packages)
   - Brief justification

   Common patterns:
   - `coding-backend-engineer` — API services, server logic
   - `coding-frontend-engineer` — React/Vue/Angular UI code
   - `coding-database-engineer` — ORM entities, migrations, queries
   - `coding-infra-engineer` — CDK/Terraform, deployment, CI/CD

   But adapt to the actual repo — not every repo needs all four, and some repos need
   different splits (e.g., `coding-ml-engineer`, `coding-etl-engineer`).

4. **Create the engineers directory if needed**

   Ensure `.skillshare/engineers/` exists before writing any files.

5. **Create each approved engineer**

   For each engineer the user approves, invoke the `skillshare-create-engineer` skill
   with the name, domain scope, and identified tech stack as context.

When wording each definition, follow:

{% include "references/writing-instructions.md" ignore missing %}

6. **Run sync**

   After all engineers are created, run `{{ runPrefix }} skillshare sync` to distribute
   them to all configured tools.

7. **Show summary**

   Display which engineers were created, which tools got agent definitions vs skill
   fallbacks, and suggest next steps (improve engineers over time with
   `skillshare-improve-engineer`).

**Guardrails**
- Always ask for user approval before creating engineers
- Never create engineers for domains that don't exist in the repo
- If the repo has existing coding skills (`.claude/skills/coding-*`), mention them and suggest migrating the content
- Keep proposed names consistent with the `-engineer` suffix convention
