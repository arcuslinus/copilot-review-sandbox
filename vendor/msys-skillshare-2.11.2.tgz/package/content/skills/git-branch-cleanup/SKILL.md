---
name: git-branch-cleanup
description: >
  Delete local branches that are stale — those marked `[gone]` (their upstream was
  deleted on the remote) or already merged into the default branch — removing a branch's
  worktree first when that is required to delete it. Use when the user says "clean up
  branches", "delete merged branches", "remove gone branches", "prune local branches",
  or "clean_gone". Never deletes the current branch or the default branch; lists what it
  will remove before removing and reports cleanly when nothing qualifies.
license: MIT
metadata:
  author: meistersystems
  version: "1.1"
---

# Git Branch Cleanup

Delete stale local branches: those whose upstream is `[gone]`, and those already merged
into the default branch. Preview before deleting; never touch protected branches.

## Step 1: Establish protected branches

Determine the two branches that must **never** be deleted:

- The **current branch**: `git branch --show-current`
- The **default branch** (e.g. `main`/`master`) — as a **local** branch name, not `origin/main`:
  ```bash
  git symbolic-ref --quiet --short refs/remotes/origin/HEAD | sed 's@^origin/@@'
  ```
  The `sed` strips the `origin/` prefix so the value matches local branch names used by
  the protection check and `git branch --merged <default>`. Fall back to `main`, then
  `master`, if that is unavailable.

## Step 2: Identify candidate branches

Refresh remote-tracking state and prune deleted upstreams first:

```bash
git fetch --prune
```

List branches with their tracking status and worktree markers:

```bash
git branch -vv
git worktree list
```

Build the candidate set from two sources, then **exclude the current branch and the
default branch**:

- **Gone branches** — branches whose tracking info shows `[gone]` (upstream deleted on the
  remote).
- **Merged branches** — branches already merged into the default branch:
  ```bash
  git branch --merged <default-branch>
  ```

A `+` prefix in `git branch -vv` means the branch is checked out in a worktree and cannot
be deleted until that worktree is removed (see Step 4).

## Step 3: Preview

List every branch that will be deleted (and note any worktree that must be removed first).
**If no branch qualifies, report "No stale branches to clean up" and stop** — remove
nothing.

## Step 4: Remove worktrees, then delete branches

For each candidate branch:

1. **If the branch has an associated worktree, remove that worktree first** so the branch
   can be deleted. Never remove the worktree you are currently in:
{%- if flags.worktreeScript %}

   Use this repo's worktree teardown, run **from the repository's main checkout** (the CLI
   refuses to run anywhere else) and passing the worktree directory's basename:
   ```bash
   {{ runPrefix }} worktree remove --name <worktree-dir-basename> --force
   ```
   It tears down the worktree's isolated resources before removing the checkout. Use it for
   every worktree, with no per-worktree resource detection — the teardown probes each
   resource and no-ops on the ones a worktree does not have. If the command fails, report
   its error and skip that branch; do **not** fall back to `git worktree remove --force`,
   which removes the checkout while leaking the resources.
{%- else %}
   ```bash
   git worktree remove --force <worktree-path>
   ```
{%- endif %}
2. Delete the branch:
   ```bash
   git branch -D <branch>
   ```

## Step 5: Report

Report which worktrees were removed and which branches were deleted.
