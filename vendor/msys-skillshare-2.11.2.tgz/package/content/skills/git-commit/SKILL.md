---
name: git-commit
description: >
  Stage the working changes and create a single git commit whose message follows
  this repo's resolved commit conventions (JIRA-ticket-prefixed, no AI attribution).
  Use when the user says "commit", "commit my changes", "make a commit", "git commit",
  "save my work", or otherwise wants the current changes committed. Inspects the
  working tree, stages, and creates exactly one commit; reports cleanly and makes no
  commit when the tree is already clean.
license: MIT
metadata:
  author: meistersystems
  version: "1.0"
---

# Git Commit

Stage the current working changes and create a single, convention-correct commit.

## Step 1: Inspect the working tree

Look at what has changed before deciding on a message:

```bash
git status
git diff             # unstaged changes
git diff --staged    # staged changes
git branch --show-current
git log --oneline -10
```

`git status` shows staged, unstaged, and untracked files; `git diff` and `git diff --staged`
together show the full content of unstaged and staged changes (this pair also works in a repo
with no commits yet, where `git diff HEAD` would fail); the branch name supplies the JIRA
ticket ID for the message; recent commits show the message style already in use.

## Step 2: Handle a clean working tree

If `git status` reports no staged, unstaged, or untracked changes, there is nothing to
commit. Report "Nothing to commit — the working tree is clean" and stop. Do **not** create
an empty commit and do **not** invent changes.

## Step 3: Stage and commit

If there are changes:

1. Stage the changes that belong in this commit. Prefer staging the specific files that
   make up one logical change over a blanket `git add -A` when the working tree mixes
   unrelated edits.
2. Create **one** commit with a message that follows the conventions below. Derive the
   JIRA ticket ID from the current branch name (e.g. branch `meis-1234-add-filter` →
   `MEIS-1234`). If the branch name carries no ticket ID, ask the user how to prefix the
   message rather than guessing.

### Commit message conventions

{% include "instructions/commit-conventions/format.md" %}

Keep the subject concise and imperative; add a body only when the change needs explanation.
Do not add any AI-attribution line (e.g. "Generated with …") to the message.

## Step 4: Report

Print the commit subject (and the staged files) so the user can see exactly what was
committed.
