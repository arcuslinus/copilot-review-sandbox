---
name: create-post-merge-checklist
description: >
  Derive the post-merge action items for an OpenSpec change and post them to the
  corresponding Jira ticket as a single managed comment with native checkboxes, grouped by
  category. Use when the user says "create post-merge checklist", "generate post-merge items",
  "what do we need to do after merge", "what runs after this merges", "post-merge actions",
  or runs the post-merge-checklist step of the OpenSpec workflow. Also triggers when the user
  provides a change name as an argument (e.g. `/create-post-merge-checklist aim-11-define-openspec-workflow`).
license: MIT
compatibility: Requires the openspec CLI and the Atlassian MCP (for posting to Jira).
metadata:
  author: meistersystems
  version: "1.1"
skillset:
  name: wrap-up
  when: >
    the change has rollout steps that can only run after merge — a migration, a deploy, a
    feature-flag flip, or a coordinated update to another repo's consumers
  phase: work
  writes: false
---

Derive the **post-merge action items** for an OpenSpec change and post them to the corresponding Jira ticket as a single, idempotent **managed comment** with native Jira checkboxes, grouped by category. A post-merge item is **change-specific** work that finishes THIS change's rollout, **needs a human after merge**, and **would otherwise be forgotten** — running a prod migration, flipping a prod feature flag, backfilling data, notifying a consumer of a breaking change, watching a specific new metric. **Most changes have no post-merge items, and that is the normal outcome** — the bar is high (see `references/post-merge-conventions.md` → "Default to empty"). Routine release/CI hygiene and anything verifiable before merge are NOT post-merge items.

{% if (settings.openspecEnhanced.jiraConfirmPrompt | default("prompt")) == "prompt" -%}
**Do NOT write to Jira without explicit approval.** Always show the drafted checklist, allow edits, and get user sign-off before any Jira write.
{%- else -%}
This skill drafts the checklist and posts it to Jira automatically, without a confirmation prompt. Set `features.openspec-enhanced.settings.jiraConfirmPrompt: prompt` to restore sign-off before posting.
{%- endif %}

This skill reads the default post-merge conventions in `references/post-merge-conventions.md`. Read that file before generating — it defines the two-boundary triage (what counts as a post-merge item), the source material, the output structure, and the quality bar.

---

## Information routing

{% include "instructions/workflow-routing.md" %}

**Your lane — Post-Merge Items.** Emit only post-merge-lane actions: work that finishes this change's rollout and is only possible once the merged code is live. When a candidate belongs to another lane — completable/verifiable before merge (a pre-merge task or PR verification) or a functional product check (QA Instructions) — surface it to the user during draft review and leave it out of the posted comment. Never absorb it to "rescue" it. This is the shared-model expression of the two-boundary triage below.

---

## Steps

### 1. Resolve the change name

If the user passed a change name as an argument, use it. Otherwise check whether it can be inferred from conversation context (a change just implemented or verified).

If it is missing or ambiguous, prompt for selection — do NOT guess or auto-select:

```bash
openspec list --json
```

Use the **AskUserQuestion tool** to let the user pick from the available changes. Mark changes with incomplete tasks as "(In Progress)".

### 2. Resolve the target Jira ticket from the branch

Read the current branch name and extract a `<PROJECT>-<number>` ticket key:

```bash
git rev-parse --abbrev-ref HEAD
```

Branch `aim-11-define-openspec-workflow` → ticket `AIM-11`. Uppercase the project segment. Find the `<letters>-<digits>` tokens anywhere in the branch name (so prefixed branches like `feature/aim-11-…` or `linus/aim-11-…` are supported — the prefix segment isn't such a token):

- **Exactly one** such token → use it as the ticket key.
- **Zero, or more than one** such token → use the **AskUserQuestion tool** to request the ticket key. **Never guess the ticket.**

### 3. Check the Atlassian MCP is available

Posting requires the Atlassian MCP (`getJiraIssue`, `addCommentToJiraIssue`).

**If Atlassian MCP tools are not available**: STOP before posting. Explain that the post-merge checklist was drafted but cannot be pushed to Jira because the Atlassian MCP is not configured, and prompt the user to configure it. Offer to display the drafted checklist so they can be pasted manually. **Do NOT fail the surrounding workflow** — this is graceful degradation, same as the `docs-*` skills. The OpenSpec workflow continues.

### 4. Read the change artifacts and diff

Load the change's source material:

```bash
openspec instructions apply --change "<name>" --json
```
> Run as-is — never `| head/grep/python/jq` or truncate. The `rules` are binding.

This returns the change directory and `contextFiles` (artifact ID → file paths). Read all available artifacts: **proposal**, **design**, **delta specs**, **tasks**. Also read the implementation diff (e.g. `git diff main...HEAD` scoped to the change) for rollout work the artifacts may not name.

**Use the proposal's impact flags as the primary place to hunt for candidates** — but a flag is a *candidate*, not an automatic item. The Impact section (DB migration, GraphQL schema change, infrastructure update, shared infrastructure) often points to a genuine post-merge action (run the prod migration, coordinate a breaking schema change with consumers), yet many flags yield nothing once you apply the inclusion bar. Then read the design's rollout/migration steps, the diff, and any tasks marked deferred. See `references/post-merge-conventions.md` → "Source material" and "Default to empty".

If only a subset of artifacts exists (e.g. tasks only, no proposal), still produce items from what is available and note which inputs were unavailable.

### 5. Triage each candidate (start from empty, raise the bar)

Begin with an **empty** checklist. Triage each candidate three ways — the conventions file states this in full:

- **Completable or verifiable before merge** → a **pre-merge task** (or in-branch if small); anything checkable in review is **PR verification**, recorded in the PR, NOT here.
- **Needed to finish THIS change's rollout but only possible after merge** → a **post-merge item** (this is what the checklist captures).
- **New, separate, or larger scope** → a **follow-up ticket**, NOT a post-merge item.

Only the middle category qualifies, and only when it also clears the inclusion bar: **change-specific**, **needs a human**, **genuinely post-merge**, **would otherwise be forgotten**. Never list standard release/CI hygiene ("confirm the release published", "CI is green", "package installs") or pre-merge verification ("verify it renders / the flag works"). When in doubt, leave it out — an empty checklist is the common, correct result.

### 6. Account for repo-specific post-merge guidance

The conventions you read in `references/post-merge-conventions.md` (step 4) already incorporate any repo-specific overrides: a consuming repo's committed `.skillshare/references/post-merge-conventions.md` is **spliced onto the end of the shipped defaults at sync time**. There is no separate file to read at runtime. The repo's guidance appears **after** the shipped defaults and **wins on conflict** (e.g. additional categories, mandatory environments); everything not overridden falls back to the shipped defaults.

### 7. Generate the grouped checklist

Group the triaged post-merge items under the canonical (default) set of category headings below, in this order, **omitting any category with no items**. A repo's spliced conventions may add categories; honor those too — this is the shipped default set, not a hard limit:

1. **Migration** — data/schema migrations to run or confirm
2. **Release** — publish/version steps that land after merge
3. **Deploy** — deploys to trigger or verify
4. **Monitoring** — what to watch, for how long, and the signal that means healthy
5. **Coordination** — handoffs, notifications, or sign-offs other people owe

Each item is phrased `action — when — done-when`: the action, its timing/trigger, and an explicit observable done-when. No vague "monitor things" — every item states how you know it is finished.

**Empty case:** when triage yields no genuine post-merge items, the checklist body is exactly `No post-merge items for this change.` — still post/update the managed comment so a reader can tell "none needed" from "step skipped".

### 8. {% if (settings.openspecEnhanced.jiraConfirmPrompt | default("prompt")) == "prompt" %}Draft, show, confirm (gate){% else %}Draft and post directly (no confirmation){% endif %}

{% if (settings.openspecEnhanced.jiraConfirmPrompt | default("prompt")) == "prompt" -%}
Show the full drafted checklist to the user. Use the **AskUserQuestion tool** to confirm: **Post to Jira (default)** / **Edit first** / **Cancel**. If the user requests changes, revise and re-show. **No Jira write happens until the user approves.**
{%- else -%}
Show the full drafted checklist to the user, then proceed directly to Step 9 and post it — do **not** ask for confirmation before posting. This applies to the empty case too: post the "No post-merge items for this change." state directly, with no confirmation prompt. This does not change the genuine-ambiguity prompts elsewhere in this skill (change selection, ticket-key resolution): those still fire regardless of this setting.
{%- endif %}

### 9. Post to Jira as a managed comment

Build the comment body as ADF and create-or-update the single managed comment keyed by the `skillshare:post-merge-checklist` marker (mechanism below).

---

## Jira managed-comment mechanism

The post-merge checklist lives in exactly **one** managed Jira comment per ticket, identified by an embedded marker token. This is the **same content-agnostic managed-comment mechanism** that `create-qa-instructions` uses — "a managed comment keyed by a marker token, built as ADF, created-or-updated-in-place". This skill reuses it verbatim with its **own marker token** (`skillshare:post-merge-checklist`) and its **own ADF body** (the grouped checklist). Do NOT define a new mechanism; the QA comment and the post-merge comment coexist on one ticket without collision because their markers differ.

### Build the body as ADF — shared chrome, never markdown checkboxes

Build the comment body as **ADF (Atlassian Document Format)** and call the MCP with `contentFormat: "adf"`. This comment shares its **visual chrome** with the QA managed comment so the two read as a matched set on a ticket:

- **Title** — an `h2` heading with a leading 📋 emoji reading **Post-merge checklist**.
- **Category headings** — each category (Migration, Release, Deploy, Monitoring, Coordination) is an `h3` heading with its items as `taskItem` nodes beneath it.
- **`rule` dividers** — a horizontal `rule` after the title block and one before the marker footer (mirroring the QA comment's dividers).
- each `taskItem` has `attrs: { localId: "<unique>", state: "TODO" }`
- the wrapping `taskList` has `attrs: { localId: "<unique>" }`

**Do NOT use markdown `- [ ]` checkboxes.** Markdown→ADF checkbox conversion is unreliable: identical markdown was observed to produce a plain `bulletList` in one place and a `taskList` in another within the same comment. Always hand-build the ADF `taskList` so checkboxes render natively and tickably.

**Render inline code with ADF `code` marks, never literal backtick characters.** Inside ADF, a backtick is shown verbatim — `` `postMergeChecklist` `` renders as the literal string with backticks, not monospace. For any code token (a flag name, file path, command, identifier), split the `taskItem` content into separate `text` nodes and apply `marks: [{ "type": "code" }]` to the code token. Example: the item "set the `postMergeChecklist` flag" becomes three text nodes — `"set the "`, then `"postMergeChecklist"` with a `code` mark, then `" flag"`. Plain prose stays a single unmarked text node.

For the empty case, the body is a single paragraph reading exactly `No post-merge items for this change.` followed by the marker footer — no taskList.

### Embed the marker

Every write MUST end with this exact footer line as the comment's final paragraph — it embeds the `skillshare:post-merge-checklist` marker that identifies and re-discovers the managed comment, and it is byte-identical on every run so idempotent updates produce no spurious diff:

```
skillshare:post-merge-checklist · generated by /create-post-merge-checklist via Skillshare · do not edit manually
```

Render it as a single trailing paragraph: the `skillshare:post-merge-checklist` token carries `code` marks, and the remainder (`· generated by /create-post-merge-checklist via Skillshare · do not edit manually`) carries an `em` mark (see the worked example). Do not reword it — the discovery scan matches on the `skillshare:post-merge-checklist` substring, and the fixed wording keeps re-run updates byte-stable.

### Idempotent create-or-update by marker discovery

1. Fetch the ticket's existing comments:

   ```
   getJiraIssue({ issueIdOrKey: "AIM-11", fields: ["comment"], responseContentFormat: "adf" })
   ```

2. Scan the comments for one whose body contains the `skillshare:post-merge-checklist` marker.

   - **If found** → call `addCommentToJiraIssue` with that comment's `commentId` to **update it in place**. (Verified: same id, `created` preserved, only `updated` bumped, no duplicate.)
   - **If not found** → call `addCommentToJiraIssue` **without** `commentId` to create a new one carrying the marker.

The ticket's post-merge managed-comment count stays at exactly one. Never create a second managed comment.

### Re-runs and deletion

Re-running **overwrites** the comment and **resets checkbox state** to `TODO` — this is intended: an update means the post-merge work must be re-evaluated. Transitioning to the empty `No post-merge items for this change.` state is also done by updating in place. The Atlassian MCP has **no delete-comment operation**; to supersede the checklist, update the managed comment in place — never attempt to delete.

---

## Worked example

### Mapping an impact flag to a post-merge item

Source proposal impact flag:

```
- **DB migration**: adds a `published_at` column to `documents`.
```

Generated post-merge item (under **Migration**):

> Confirm the `documents.published_at` migration applied on production — after the deploy completes — by querying that the column exists and existing rows backfilled to NULL.

The flag named the impact; the item states the action, its timing (after the deploy), and an explicit done-when (column exists, rows backfilled).

### ADF comment body

A managed comment with the shared chrome: an emoji `h2` title, a `rule`, a category `h3` heading with a `taskList`, a `rule`, and the marker footer.

```json
{
  "type": "doc",
  "version": 1,
  "content": [
    { "type": "heading", "attrs": { "level": 2 }, "content": [{ "type": "text", "text": "📋 Post-merge checklist" }] },
    { "type": "rule" },
    { "type": "heading", "attrs": { "level": 3 }, "content": [{ "type": "text", "text": "Migration" }] },
    {
      "type": "taskList",
      "attrs": { "localId": "pmc-migration" },
      "content": [
        { "type": "taskItem", "attrs": { "localId": "pmc-1", "state": "TODO" }, "content": [{ "type": "text", "text": "Confirm the " }, { "type": "text", "text": "documents.published_at", "marks": [{ "type": "code" }] }, { "type": "text", "text": " migration applied on production — after the deploy completes — by querying that the column exists and existing rows backfilled to " }, { "type": "text", "text": "NULL", "marks": [{ "type": "code" }] }, { "type": "text", "text": "." }] }
      ]
    },
    { "type": "rule" },
    { "type": "paragraph", "content": [{ "type": "text", "text": "skillshare:post-merge-checklist", "marks": [{ "type": "code" }] }, { "type": "text", "text": " · generated by /create-post-merge-checklist via Skillshare · do not edit manually", "marks": [{ "type": "em" }] }] }
  ]
}
```

The empty-case body keeps the title chrome but states the empty sentence in place of any categories:

```json
{
  "type": "doc",
  "version": 1,
  "content": [
    { "type": "heading", "attrs": { "level": 2 }, "content": [{ "type": "text", "text": "📋 Post-merge checklist" }] },
    { "type": "rule" },
    { "type": "paragraph", "content": [{ "type": "text", "text": "No post-merge items for this change." }] },
    { "type": "rule" },
    { "type": "paragraph", "content": [{ "type": "text", "text": "skillshare:post-merge-checklist", "marks": [{ "type": "code" }] }, { "type": "text", "text": " · generated by /create-post-merge-checklist via Skillshare · do not edit manually", "marks": [{ "type": "em" }] }] }
  ]
}
```

Post it with:

```
addCommentToJiraIssue({ issueIdOrKey: "AIM-11", contentFormat: "adf", body: <the doc above>, commentId: "<existing id if the marker was found, else omit>" })
```

---

## Guardrails

{% if (settings.openspecEnhanced.jiraConfirmPrompt | default("prompt")) == "prompt" -%}
- **Draft first, post second** — Never write to Jira before showing the draft and getting explicit approval.
{%- else -%}
- **Draft, then post automatically** — With `jiraConfirmPrompt: auto` (the default), show the draft and post it directly, with no confirmation prompt. Set `features.openspec-enhanced.settings.jiraConfirmPrompt: prompt` to restore confirm-before-post.
{%- endif %}
- **Never guess the ticket** — If the branch yields no unambiguous `<PROJECT>-<number>` key, ask via AskUserQuestion.
- **Degrade gracefully** — If the Atlassian MCP is unavailable, stop before posting, explain, prompt for setup, and do NOT fail the surrounding workflow.
- **Default to empty** — Start from no items and add one only when it is change-specific, needs a human after merge, can't be verified before merge, and would otherwise be forgotten. Empty is the common, correct result.
- **Never list hygiene or PR verification** — Routine release/CI checks ("the release published", "CI is green") and anything verifiable in review ("it renders", "the flag works") are not post-merge items; the latter goes in the PR.
- **Two-boundary triage** — Only items needed to finish this change's rollout that can't be done before merge belong here. Pre-merge work is a pre-merge task; new scope is a follow-up ticket.
- **Always post, even when empty** — When there are no items, post/update the comment to read exactly `No post-merge items for this change.` so "none needed" is distinguishable from "step skipped".
- **One managed comment** — Always discover-by-marker and update in place; never create a duplicate.
- **ADF checkboxes only** — Hand-build `taskList`/`taskItem` nodes; never rely on markdown `- [ ]` conversion.
- **Inline code uses `code` marks** — Render flag names, paths, and commands as `text` nodes with a `code` mark, never literal backtick characters (Jira shows backticks verbatim).
- **No delete** — There is no delete operation; supersede by updating the managed comment in place.
- **Repo guidance wins** — a repo's `.skillshare/references/post-merge-conventions.md` is spliced onto the shipped defaults at sync time and overrides them where they conflict.
- **No git operations** — The skill reads the diff but never commits, pushes, branches, or opens PRs.
