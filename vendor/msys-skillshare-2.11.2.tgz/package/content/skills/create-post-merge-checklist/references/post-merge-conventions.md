# Post-Merge Checklist Conventions

Default conventions for what makes a good post-merge checklist generated from an OpenSpec change. These are the **shipped defaults**. A repository MAY override or extend them with a committed **`.skillshare/references/post-merge-conventions.md`**, which is **spliced onto the end of these shipped defaults at sync time** (repo guidance is appended and wins on conflict; everything not overridden falls back to these defaults).

A post-merge checklist tracks **change-specific** work that finishes THIS change's rollout, requires a human action after the PR merges, and would otherwise be forgotten — running a one-off production migration, flipping a prod feature flag, backfilling data, notifying an external consumer of a breaking change, watching a specific new metric after deploy. The checklist records these; humans execute them.

**Most changes have zero post-merge items — empty is the normal, correct outcome.** The bar for adding an item is high (see "Default to empty" below). When in doubt, leave it out: an empty checklist is better than one padded with routine hygiene or work that belonged in the PR.

## What a post-merge item is — the two-boundary triage

Every candidate action triages exactly three ways. Only the middle case is a post-merge item:

1. **Completable or verifiable before merge → pre-merge task / PR verification.** If the work can be finished before the PR merges — a unit test, a local check, a config edit, a small directly-related fix — it is a pre-merge task, or if it is small, just do it in-branch. Crucially, **anything you can verify on the branch or in review** (the feature renders, the flag works, the generated output is correct) is **pre-merge verification** — record it in the PR description, **not** on the Jira checklist. "Verify X works" is almost always pre-merge verification, not a post-merge item. Listing pre-merge work as post-merge is the most common mistake.
2. **Needed to finish this change's rollout, but only possible after merge → post-merge item.** Verifying a migration applied to production, confirming a published package version, watching a metric after deploy — these depend on the merged code being live and cannot be done in-branch. This is the only category that belongs on the checklist.
3. **New, separate, or larger scope → follow-up ticket.** If the action introduces scope beyond completing this change's rollout — a new feature, a refactor the change merely exposed, a broader cleanup — it is a **follow-up ticket**, NOT a post-merge item. Never smuggle new scope onto the checklist; post-merge items only finish what this change already started.

Both exclusion boundaries matter: an item is not a post-merge item if it could have been a pre-merge task, and it is not a post-merge item if it really wants to be its own ticket.

## Default to empty — the inclusion bar

Start from an empty checklist and add an item only when it clears **every** test below. If any fails, drop it.

- **Change-specific** — the action exists *because of this change*. Generic steps that happen for any change are out.
- **Genuinely post-merge** — it cannot be done or verified before merge. If it can be checked on the branch or in review, it is PR verification, not a checklist item.
- **Needs a human** — it will not happen automatically. Work that CI, the release pipeline, or the deploy does on its own is not an item.
- **Would otherwise be forgotten** — without the checklist, this necessary action could slip. If it is obvious and unavoidable, it does not need tracking.

Never list these — they are not post-merge items:

- **Standard release/CI hygiene** — "confirm the release published", "check CI is green", "verify the package installs". These happen for every change and are already someone's routine; tracking them adds noise.
- **Pre-merge verification** — "verify it renders / the flag works / the output is correct". That is part of reviewing and verifying the PR; put it in the PR, not the ticket.
- **New or separate scope** — belongs in a follow-up ticket.

## Source material

Scan the change's artifacts and diff for **candidates**, then run each through the inclusion bar above — most candidates do not become items. Look here first:

<!-- prettier-ignore -->
| Source | Use |
| --- | --- |
| Proposal **Impact** flags | **Primary** hunting ground — DB migration, GraphQL schema change, infrastructure update, shared-infrastructure flags often imply a genuine post-merge action (run the prod migration, coordinate a breaking schema change with consumers). But a flag is a *candidate*, not an automatic item: keep it only if the action needs a human, can't be verified pre-merge, and isn't routine release hygiene |
| Design rollout / migration steps | Sequenced rollout, backfills, feature-flag flips, and ordering constraints that land after merge |
| Implementation diff | New CI/CD workflows, publish/version config, migration files, infra definitions — concrete artifacts whose effect is only observable post-merge |
| Tasks marked deferred | Tasks explicitly noted as "after merge" or deferred-by-necessity (not deferred-by-laziness, which is a pre-merge gap to fix) |

If an artifact is absent (e.g. no proposal, tasks only), derive items from what is available and note which inputs were unavailable.

## Canonical output structure

Items are grouped under a **canonical (default) set** of category headings, in this order — a repo's `.skillshare/references/post-merge-conventions.md` splice may extend it with additional categories; the set below is the shipped default, not a hard limit. **Omit any category with no items** — no empty-bucket placeholders:

<!-- prettier-ignore -->
| Category | Holds |
| --- | --- |
| **Migration** | Data/schema migrations to run or confirm applied |
| **Release** | Change-specific release actions that need a human after merge (e.g. a manual publish step, coordinating a breaking version with consumers). **Not** routine "confirm the release published" — that is hygiene the pipeline and release owner already cover |
| **Deploy** | Deploys to trigger or verify on each environment |
| **Monitoring** | What to watch, for how long, and the signal that means healthy |
| **Coordination** | Handoffs, notifications, or sign-offs other people owe |

Each item is phrased **`action — when — done-when`**:

- **action** — the concrete thing to do ("Confirm the `documents.published_at` migration applied on production")
- **when** — its timing or trigger ("after the production deploy completes")
- **done-when** — an explicit, observable signal that the item is finished ("the column exists and existing rows backfilled to NULL")

Render items as native Jira checkboxes (see SKILL.md for the ADF `taskList`/`taskItem` mechanism) so each can be ticked off as it completes.

## The empty case

When the triage yields no genuine post-merge items, the checklist body is exactly:

```
No post-merge items for this change.
```

Still post (or update) the managed comment — never omit it. The explicit statement lets a reader distinguish "none needed" from "the step was skipped".

## Quality bar

A good post-merge checklist is:

- **Concrete** — names the exact migration, environment, package, metric, or person; never "verify things work" or "check the deploy"
- **Independently verifiable** — someone other than the implementer can perform and confirm each item from the done-when alone, without reading the diff or asking the author
- **Scoped** — covers only what finishes this change's rollout; new scope is a follow-up ticket, pre-merge work is a pre-merge task
- **Honest about gaps** — when a needed artifact (e.g. the proposal) is absent, note that the items are derived from the available material and which inputs were unavailable
- **Complete in its done-whens** — every item states how you know it is finished; no item leaves "done" to interpretation

## Anti-patterns

- **Listing pre-merge work as post-merge** — anything completable before the PR merges is a pre-merge task or in-branch work, not a post-merge item
- **Listing PR verification as a post-merge item** — "verify the feature renders / the flag works / the output is correct" is checked in review and belongs in the PR, never on the Jira checklist
- **Listing standard release/CI hygiene** — "confirm the release published", "check CI is green", "verify the package installs" happen for every change and are already routine; they are noise, not items
- **Inventing filler** — padding the checklist with generic busywork ("smoke-test the app", "let the team know") that the change does not actually require. If there are no items, use the empty case
- **Smuggling new scope in as an item** — a new feature, refactor, or cleanup the change merely surfaced belongs in a follow-up ticket, never on this checklist
- **Vague "monitor things" with no done-when** — "watch the dashboards" is not an item; "watch the 5xx rate on the editor service for 30 min post-deploy; healthy = stays below the pre-deploy baseline" is
- **Empty-bucket placeholders** — omit categories with no items rather than rendering an empty heading

{% include "references/post-merge-conventions.md" ignore missing %}
