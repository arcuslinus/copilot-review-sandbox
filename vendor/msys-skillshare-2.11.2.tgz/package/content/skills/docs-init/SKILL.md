---
name: docs-init
description: >
  Bootstrap initial documentation for a repository. Scans the codebase
  comprehensively, identifies all documentable topics, drafts complete docs in
  parallel using sub-agents, and scaffolds the docs/ knowledge base including
  scope descriptor and README index. Use when the user says "initialize docs",
  "bootstrap documentation", "set up the knowledge base", "create initial docs",
  or when onboarding a new repository that has no docs/ directory yet. Also
  handles migration from legacy documentation sources (docs.old/, wiki/, etc.).
license: MIT
compatibility: Requires a git repository. Creates docs/ directory if it does not exist.
metadata:
  author: meistersystems
  version: "1.0"
---

Bootstrap the `docs/` knowledge base for a repository from scratch. Scan the entire codebase, identify all documentable topics, draft complete documentation in parallel, and create the scope descriptor and README index.

**Do NOT create documentation without explicit approval.** Always show the topic plan and get user sign-off before drafting, then show a review summary before writing files.

---

> **Not compatible with `/batch`.** This skill must not be run via `/batch`.
> Documentation changes are interdependent (cross-references, shared README, scope checks) and require
> coordinated output. If you are a sub-agent spawned by `/batch`, **stop immediately** and report back
> that this skill cannot be parallelized via `/batch`.

---

## Scope: `docs/` vs `openspec/`

This project separates **usage documentation** from **implementation specifications**:

<!-- prettier-ignore -->
| | `docs/` | `openspec/specs/` |
| --- | --- | --- |
| **Purpose** | How to use the system, general knowledge, feature docs | Implementation specs, design decisions, requirements, tasks |
| **Audience** | Developers using/operating the system | Developers building/changing the system |
| **Content** | Setup guides, architecture overviews, feature usage, troubleshooting | Requirements, design rationale, implementation plans, task lists |
| **Managed by** | These skills (`/docs-audit`, `/docs-revise`, `/docs-add`) | OpenSpec skills (`/openspec-*`) |

**This skill operates ONLY on `docs/`.** Never create or modify files in `openspec/`.

---

## Sub-agent strategy

This skill is parallelization-heavy — it scans a full codebase and drafts many docs simultaneously. Use the **Agent tool** (sub-agents) to parallelize discovery and drafting while the main agent coordinates.

**General principles:**

- Spawn at most **10 sub-agents simultaneously**. If there are more than 10 topics, batch them into groups.
- Sub-agents in discovery phases (Phase 2) **only read files and return structured JSON results**.
- Sub-agents in drafting phase (Phase 5) **only read files and return complete markdown content as structured results**. They never write to disk.
- **All file writes happen in the main agent** (Phase 7).
- Sub-agents **never perform git operations** (commit, push, branch, PR).
- The main agent orchestrates, presents results to the user, and makes decisions. Sub-agents do the heavy lifting.

**Model selection for sub-agents:** spawn sub-agents on a balanced-cost model rather than the top-tier model. The work — reading files, extracting repository structure, and returning either structured JSON (discovery sub-agents in Phase 2) or complete markdown drafts (drafting sub-agents in Phase 5) — does not require frontier reasoning, and parallelizing many sub-agents on the top tier burns budget without quality gain. When using Claude, prefer Sonnet over Opus; when using other AI agents, pick the equivalent balanced tier. The main (orchestrating) agent stays on whatever model the user invoked the skill with.

---

## Phase 1: Setup

### 1a. Check for migration sources

Use the **AskUserQuestion** tool to ask:

> Do you have existing documentation to migrate into the new docs/ structure?
>
> Examples: `docs.old/`, `wiki/`, Notion export, markdown files in other directories.

Options:
1. **No (default)** — proceed without migration sources.
2. **Yes** — ask the user to specify the path(s).

The default is **No**. If the user provides migration source paths, verify they exist. Note them for Phase 2.

### 1b. Check Atlassian MCP availability

Attempt to use the Atlassian MCP `search` tool (a no-op or minimal query). If it is unavailable (tool not found / not configured), call the **AskUserQuestion** tool with these options:

1. **Continue without cross-repo check (default)** — proceed without Confluence awareness. Note in your output that cross-repo deduplication was skipped because the Atlassian MCP is not configured.
2. **Stop and configure Atlassian MCP** — explain that the Atlassian MCP enables cross-repo documentation deduplication via Confluence search. This prevents creating docs that duplicate content already maintained in another repository's Confluence space. Stop execution so the user can configure it.

The default is **Continue without cross-repo check**. If selected, Phase 3 will be skipped entirely.

---

## Phase 2: Discovery (parallelized sub-agents)

### 2a. Scan repository structure

The main agent first gets an overview of the repo:

```bash
# Get directory structure
find . -type d -not -path './.git/*' -not -path './node_modules/*' -not -path './.next/*' -not -path './dist/*' | head -100

# Get top-level overview
ls -la

# Check for existing docs
ls docs/ 2>/dev/null || echo "No docs/ directory"
```

### 2b. Spawn discovery sub-agents

Split the repository into areas based on its structure (e.g., `apps/`, `libs/`, `src/`, infrastructure files, config). Spawn one sub-agent per area (max 10 simultaneous). Each sub-agent receives:

> Scan the following area of the repository and identify all topics that should be documented. For each topic, return a JSON array entry:
>
> ```json
> { "topic": "human-readable topic name", "type": "Feature|Architecture|Setup|Guide|Steering", "key_files": ["path/to/relevant/file.ts", "..."], "summary": "one-line description of what this topic covers" }
> ```
>
> **Types:**
> - **Feature** — a business-facing capability, integration, or user-visible feature
> - **Architecture** — system design, data flow, module relationships, infrastructure patterns
> - **Setup** — general development environment, tooling, onboarding (NOT feature-specific setup)
> - **Guide** — how-to procedures, troubleshooting, runbooks
> - **Steering** — product direction, tech strategy, team structure
>
> Focus on topics that developers would need documented. Skip trivial configs and boilerplate.
>
> Area to scan: [list of directories/files for this sub-agent]

### 2c. Scan migration sources (if applicable)

If migration sources were provided in Phase 1, spawn additional sub-agent(s) to scan them:

> Read the following legacy documentation files and identify topics that should be migrated to the new docs/ structure. For each file, return a JSON array entry:
>
> ```json
> { "topic": "human-readable topic name", "type": "Feature|Architecture|Setup|Guide|Steering", "source_path": "docs.old/path/to/file.md", "summary": "one-line description", "migrate": true }
> ```
>
> Migration source path: [path from Phase 1]

### 2d. Merge results

The main agent collects all sub-agent results and merges them into a unified topic list. Deduplicate topics that were discovered by multiple sub-agents (same topic from different areas). Merge migration topics with codebase topics where they overlap.

---

## Phase 3: Cross-repo awareness (main agent)

**Skip this phase entirely if Atlassian MCP is unavailable (user chose "continue without" in Phase 1).**

For each discovered topic, use the Atlassian MCP `search` tool (Rovo Search):

```
search({ query: "<topic description>" })
```

Rovo Search is semantic — it matches across all Confluence spaces and returns ranked results with space keys. **Only consider results from the shared `docs` space** (all technical documentation lives there). Ignore results from other spaces. For each topic, classify the `docs`-space results:

- **Duplicate** (same topic, same intent, owned by another repo) — flag the topic: _"Also documented in docs space under {repo}: '{page title}'"_. **Still include it in the plan** — if the code lives in this repo, the docs belong here too. The existing Confluence page may be misplaced.
- **Related** (overlapping topic, different angle, owned by another repo) — note as a **cross-reference candidate**. Collect the page title, Confluence page-ID URL, and owning repo name. These will be passed to sub-agents during Phase 5 drafting.
- **No relevant hits** — no flag needed.

Collect all "found elsewhere" results — these will inform the "Does not own" candidates for the scope descriptor in Phase 7. Collect all "related" results — these will be used for cross-repo references in Phase 5.

---

## Phase 4: Topic plan (main agent)

Present the complete plan to the user as a table:

```
## Documentation plan

<!-- prettier-ignore -->
| # | Topic | Type | Target Path | Note |
| --- | --- | --- | --- | --- |
| 1 | Auth middleware | Architecture | docs/architecture/auth.md | |
| 2 | SAP S/4HANA integration | Feature | docs/features/sap-s4hana/ | also in msys-pim space |
| 3 | Getting started | Setup | docs/setup/getting-started.md | migrate from docs.old/setup.md |
| 4 | Export pipeline | Feature | docs/features/export/ | |

{N} topics identified. Approve this plan, or reply with adjustments (remove topics, change placement, add topics).
```

**Placement rules** (follow `references/doc-conventions.md`):

<!-- prettier-ignore -->
| Topic type | Location |
| --- | --- |
| System design, data flow | `docs/architecture/{topic}.md` |
| User-facing feature | `docs/features/{feature-name}/overview.md` |
| Feature-specific setup | `docs/features/{feature-name}/setup.md` |
| How-to, runbook | `docs/guides/{topic}.md` |
| General dev setup | `docs/setup/{topic}.md` |
| Strategy, direction | `docs/steering/{topic}.md` |

For features, use **business feature names** (e.g., `sap-s4hana-integration`) not app/lib names (e.g., `msys-sap-client`).

**Filenames and directories MUST be kebab-case.** Every `{topic}` and `{feature-name}` placeholder in the table above is filled with lowercase ASCII letters and digits, with hyphens between words — no camelCase, snake_case, PascalCase, spaces, or uppercase letters. The only exception in `docs/` is `README.md`. See the **File Naming** section of `references/doc-conventions.md` for the full rule and examples.

Call the **AskUserQuestion** tool with these options:

1. **Approve all topics (default)** — proceed to drafting with the full topic list.
2. **Edit topic list** — let the user add, remove, or rename topics before drafting.
3. **Reject** — stop the workflow.

The default is **Approve all topics**. In autonomous/non-interactive modes the default is selected automatically.

---

## Phase 5: Drafting (parallelized sub-agents)

Batch approved topics into groups of max 10. Spawn one sub-agent per topic. Each sub-agent receives:

> Write complete documentation for the following topic. Read the source code files listed below to understand the subject thoroughly, then produce a complete markdown document.
>
> **Topic:** {topic name}
> **Type:** {Feature|Architecture|Setup|Guide|Steering}
> **Target path:** {docs/path/to/file.md}
> **Key source files to investigate:** {list from Phase 2}
> {If migration: **Migration source:** Read {source_path} for existing content to incorporate and improve upon.}
> {If cross-reference candidates from Phase 3: **Cross-repo references:** The following related pages were found in other Confluence spaces. Insert inline links where the topic is naturally mentioned, and add a "Related documentation" H2 section at the end listing all cross-repo references. Use page-level URLs only (no heading anchors). Format footer entries as: `- [Page Title](url) (\`repo-name\`) — brief description`
> {list of: page title, URL, repo name}}
>
> **Documentation conventions:**
> - Filenames and directories under `docs/` are kebab-case (lowercase + hyphens). The target path above is already kebab-case; preserve it. If the topic implies new sub-files, name them kebab-case too (e.g. `troubleshooting.md`, not `Troubleshooting.md`).
> - H1 title — clear, descriptive name
> - Overview paragraph — what it is and why it exists (1-3 sentences, directly after H1)
> - Body sections — organized by H2 headings
> - Be specific — use exact file paths, package names, and commands from the codebase
> - Include code examples — show real usage, not hypothetical snippets
> - Commands must be copy-pasteable
> - Cross-reference related docs using relative paths
> - No filler — every line should add value
> - Use mermaid for flow diagrams, plain text blocks for flat hierarchies
> - Use compact table format with `<!-- prettier-ignore -->` before each table
>
> {For Feature type: Create separate files if content is substantial: overview.md (always), architecture.md, setup.md, usage.md, troubleshooting.md. Return all files.}
>
> Return the complete markdown content for each file. Do NOT write any files to disk.

If there are more than 10 topics, run the first batch of 10, collect results, then run the next batch.

---

## Phase 6: Review (main agent)

**Before producing the summary**, scan every drafted file and verify each markdown table starts with `<!-- prettier-ignore -->` and uses compact (no column padding) format. Fix any non-compliant tables in the drafts before showing the user.

Present a concise summary table of all drafted documentation. Do NOT show full content by default.

```
## Draft documentation review

<!-- prettier-ignore -->
| # | File | Summary |
| --- | --- | --- |
| 1 | docs/architecture/auth.md | Auth middleware: JWT validation, RBAC, session management |
| 2 | docs/features/sap-s4hana/overview.md | SAP S/4HANA integration: sync pipeline, field mapping, error handling |
| 3 | docs/features/sap-s4hana/setup.md | SAP connection setup: credentials, env vars, test mode |
| 4 | docs/setup/getting-started.md | Dev environment: prerequisites, clone, install, run |
```

After showing the table, you **MUST** call the **AskUserQuestion** tool with the following options. Do not substitute a prose question, even if the choice feels binary — the options below are deliberate (defaults wired into auto/non-interactive modes).

1. **Apply all (default)** — write every drafted doc to disk without showing full content first.
2. **Show full content first** — display every drafted doc for inspection, then re-prompt.
3. **Apply specific docs only** — follow up with a per-item selection.

The default is **Apply all**. In autonomous/non-interactive modes the default is selected automatically.

---

## Phase 7: Write + scaffold (main agent)

### 7a. Write documentation files

Create the `docs/` directory structure and write all approved files to disk.

### 7b. Create `docs/README.md` scope descriptor

Build the scope descriptor based on what was documented and what was found in Confluence:

```markdown
# {Repository Name}

{1-2 paragraph description of what this repository is and what it does — derive from the codebase investigation in Phase 2.}

## Scope

**Owns:** {comma-separated list of domains/features for which docs were created}

**Does not own:** {comma-separated list of topics found in other Confluence spaces during Phase 3, with which repo owns them}
```

If Phase 3 was skipped (no MCP), omit the "Does not own" line or leave it empty with a note to fill in later.

Call the **AskUserQuestion** tool with options `Apply scope update (default)` / `Skip scope update` before writing the descriptor. The default is **Apply scope update**.

### 7c. Generate root `README.md` documentation index

Follow the procedure in `references/readme-maintenance.md` to generate or update the root `README.md` with a documentation index. This is a mechanical update — no additional approval needed.

### 7d. Format

Format all created files:

```bash
{{ formatCommand }} docs/ README.md
```

### 7e. Summary

Show a summary of everything that was created:

```
## Documentation initialized

**Files created:** {count}
**Scope descriptor:** docs/README.md
**Documentation index:** README.md (updated)

<!-- prettier-ignore -->
| Category | Files |
| --- | --- |
| Architecture | docs/architecture/auth.md, docs/architecture/data-flow.md |
| Features | docs/features/sap-s4hana/overview.md, docs/features/sap-s4hana/setup.md |
| Setup | docs/setup/getting-started.md |
| ... | ... |
```

---

## Guardrails

- **No git operations** — Never commit, push, create branches, or open pull requests. The skill's job ends at writing files to disk and formatting them. Git operations are the user's responsibility.
- **Not compatible with `/batch`** — see warning at top. This skill handles parallelization internally.
- **Sub-agent boundaries** — Sub-agents only read files and return structured results or drafted content. All file writes happen in the main agent (Phase 7). Sub-agents never write to disk or perform git operations.
- **Get approval twice** — the topic plan (Phase 4) and the scope descriptor (Phase 7b) both need explicit user sign-off. The review summary (Phase 6) gives the user a chance to inspect drafts before writing.
- **Complete docs only** — never create stubs, placeholders, or TODO-filled outlines. Every doc must be complete and useful.
- **Stay in scope** — only create files in `docs/` and update root `README.md`. Never create or modify files in `openspec/`.
- **Respect doc conventions** — follow the project's formatting standards (see `references/doc-conventions.md`), including kebab-case for all filenames and directories under `docs/` (only exception: `README.md`)
- **Run Formatter** — always format all files before finishing
- **Max 10 sub-agents** — never spawn more than 10 sub-agents simultaneously. Batch larger topic lists into groups.
