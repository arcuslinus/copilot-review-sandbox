---
name: git-worktree-cleanup
description: >
  Prune git worktrees that are no longer needed — those whose branch is gone or merged,
  and orphaned or stale trees (e.g. abandoned `.claude/worktrees/` entries) — independent
  of branch deletion. Use when the user says "clean up worktrees", "prune worktrees",
  "remove stale worktrees", or "clean up .claude/worktrees". Never removes the worktree
  you are currently in; lists what it will remove before acting and reports cleanly when
  nothing qualifies.
license: MIT
metadata:
  author: meistersystems
  version: "1.1"
---

# Git Worktree Cleanup

Prune worktrees that are no longer needed — independent of branch deletion. Preview before
removing; never remove the current worktree.

## Step 1: Establish the current worktree

The worktree you are working in must **never** be removed:

```bash
git rev-parse --show-toplevel
```

Also determine the default branch (e.g. `main`/`master`) for the merged check — as a
**local** branch name, not `origin/main`:

```bash
git symbolic-ref --quiet --short refs/remotes/origin/HEAD | sed 's@^origin/@@'
```

The `sed` strips the `origin/` prefix so the value matches the local branch names that
`git branch --merged <default>` and the comparisons expect. If the command prints nothing
(no `origin/HEAD` symbolic ref is set), fall back to `main`, then `master`.

## Step 2: Identify stale worktrees

Refresh state and clear administrative cruft for worktrees whose directories no longer
exist:

```bash
git fetch --prune
git worktree prune
git worktree list
git branch -vv
```

A worktree is a removal candidate when any of these hold (and it is **not** the current
worktree):

- Its branch is `[gone]` (upstream deleted on the remote), per `git branch -vv`.
- Its branch is already merged into the default branch (`git branch --merged <default>`).
- It is orphaned or stale — e.g. an abandoned `.claude/worktrees/` entry whose work is
  finished, or a tree `git worktree list` flags as `prunable`.

## Step 3: Preview

List every worktree that will be removed, with its path and branch. **If none qualify,
report "No stale worktrees to clean up" and stop** — remove nothing.

## Step 4: Remove
{% if flags.worktreeScript %}
Remove each stale worktree with this repo's worktree teardown, run **from the repository's
main checkout** (the CLI refuses to run anywhere else) and passing the worktree
directory's basename:

```bash
{{ runPrefix }} worktree remove --name <worktree-dir-basename> --force
```

This tears down the worktree's isolated resources before removing the checkout. Use it for
every worktree, with no per-worktree resource detection — the teardown probes each resource
and no-ops on the ones a worktree does not have.

If the command fails, report its error and skip that worktree. Do **not** fall back to
`git worktree remove --force`: that removes the checkout while leaking the resources.
{%- else %}
Remove each stale worktree:

```bash
git worktree remove --force <worktree-path>
```
{%- endif %}

Then prune any remaining administrative references:

```bash
git worktree prune
```

This skill removes worktrees only; it does not delete branches (use git-branch-cleanup, or
git-cleanup to do both).

## Step 5: Report

Report which worktrees were removed.
