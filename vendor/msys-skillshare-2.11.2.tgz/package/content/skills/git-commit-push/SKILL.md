---
name: git-commit-push
description: >
  Commit the working changes and push the branch to its remote, creating a
  ticket-prefixed branch first when starting from the default branch. Use when the
  user says "commit and push", "push my changes", "commit push", "git push", or wants
  their work committed and pushed in one step. Follows this repo's commit conventions
  and branch-name format; reports cleanly when there is nothing to commit.
license: MIT
metadata:
  author: meistersystems
  version: "1.1"
---

# Git Commit and Push

Commit the current working changes, then push the branch to its remote. When invoked on
the repository's default branch, create a feature branch first so work never lands
directly on the default branch.

## Step 1: Inspect the working tree and branch

```bash
git status
git diff             # unstaged changes
git diff --staged    # staged changes
git branch --show-current
git log --oneline -10
```

Determine the repository's default branch (e.g. `main` or `master`):

```bash
git symbolic-ref --quiet --short refs/remotes/origin/HEAD | sed 's@^origin/@@'
```

This strips the `origin/` prefix so you get the **local** branch name (`main`, not
`origin/main`) to compare against `git branch --show-current`. If that is unavailable,
fall back to the conventional default (`main`, then `master`).

## Step 2: Branch off the default branch when needed

**If the current branch is the default branch:** create a new feature branch before
committing. Name it per this repo's branch-name format — `<ticket-id>-description`,
always prefixed with the JIRA ticket ID (e.g. `meis-1234-add-filter`). Derive the ticket
from the change being made; if you cannot determine a ticket ID, ask the user for one
rather than committing to the default branch.

```bash
git switch -c <ticket-id>-description
```

**If the current branch is already a feature branch:** stay on it. Do not create a new
branch — commit and push on the existing branch.

## Step 3: Commit

Follow the git-commit procedure: stage the relevant changes and create a single commit.

If the working tree is clean, report "Nothing to commit — the working tree is clean" and
stop without pushing. Re-check the tree here rather than assuming anything from Step 2 —
creating a branch off the default branch does not by itself produce changes, so a clean
tree stays clean even when Step 2 created a branch.

### Commit message conventions

{% include "instructions/commit-conventions/format.md" %}

Do not add any AI-attribution line to the message.

## Step 4: Push

Push the branch to its remote, setting upstream on first push:

```bash
git push -u origin HEAD
```

Run this as-is — do not first check whether the branch exists on the remote (grepping
`git ls-remote` / `git branch -r`, inspecting upstream state). `git push -u origin HEAD` is
idempotent, so any such pre-check is redundant and error-prone: a case-sensitive lookup can
wrongly report an existing branch as missing and trigger a needless re-push.

If the push is rejected because the remote has diverged, report the rejection and let the
user decide how to reconcile (pull/rebase/merge) — do not force-push.

## Step 5: Refresh an existing PR's body (when it makes sense)

After pushing, check whether the branch already has an open pull request:

```bash
gh pr view --json number,body --jq '.number'   # prints nothing if there is no open PR
```

If an open PR exists **and** the commits you just pushed materially change what it does
(its scope, summary, or steps), update the body to reflect the branch's current state, then
print what you changed:

```bash
gh pr edit <number> --body "<updated summary>"
```

Skip this for trivial pushes (typo, formatting, small review tweaks) — only refresh when the
body would otherwise be stale or misleading. If there is no open PR, skip this step entirely
(this skill never creates one — use `git-commit-push-pr` for that). Updating the body is
autonomous (no separate confirmation); print the new body as you set it. When writing the
body, follow the **PR body guidance** in `git-commit-push-pr`: a concise what/why summary,
and a **Verification** section that lists only **technical pre-merge** checks — never tasks
to verify *after* the PR is merged, and never functional product-UI/QA scenarios (those are
QA Instructions, not PR-body content).

## Step 6: Report

Print the commit subject, confirm the branch was pushed (with its name), and note whether an
existing PR body was updated.
