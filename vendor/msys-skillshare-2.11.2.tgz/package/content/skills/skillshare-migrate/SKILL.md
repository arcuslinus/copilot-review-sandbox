---
name: skillshare-migrate
description: >
  Migrate a repository's @msys/skillshare setup from one config-schema version to
  a newer one (e.g. the 1.x committed config.yaml layout to the 2.0 config
  cascade, or a future 2 → 3 schema bump), including migrating a developer's
  personal user.yml. Use when the user says "migrate skillshare", "upgrade
  skillshare", "skillshare won't sync", "move to repo.yml", "migrate my user.yml",
  when skillshare sync or check reports a stale layout, or after bumping the
  @msys/skillshare dependency to a new major version. This skill is a
  version-agnostic orchestrator: it detects the repo's config-schema version,
  reads the version-specific playbook shipped inside the installed
  @msys/skillshare package (MIGRATION.md), plans the migration, confirms with the
  user, applies it, and verifies the result. It ships in the default-on
  skillshare-management feature set and is never auto-disabled — every future
  schema major reuses it.
license: MIT
compatibility: Requires Git and the @msys/skillshare package installed in node_modules.
---

# Skillshare Migrate

Orchestrate a supervised migration of this repo's skillshare setup to a newer
config-schema version. This skill carries **no** version-specific migration steps
— every transition-specific instruction lives in the `MIGRATION.md` document
shipped inside the installed `@msys/skillshare` package. Your job is to detect the
config-schema version of each surface, read that document, and execute the
appropriate section under user supervision.

This skill is **version-agnostic** and ships in the **default-on
`skillshare-management` feature set** (alongside `skillshare-create-skill` and
`skillshare-modify`), so it is available out of the box in every consuming repo.
Unlike the onboarding skill, it is **never auto-disabled** after a migration — a
migration never toggles the `skillshare-management` feature off or force-excludes
the skill, because every future config-schema major (2 → 3, 3 → 4, …) reuses it,
including migrations of a developer's personal `user.yml`. Never hardcode
transform rules here; they always live in `MIGRATION.md`.

**Do not guess migration steps.** If you cannot locate the packaged
`MIGRATION.md`, stop and report. The whole point of this skill is to defer the
version-specific knowledge to the packaged doc so the skill never goes stale.

---

## Step 1: Detect the config-schema version of each surface

Migration is driven by a `schemaVersion` integer, not by filenames. The CLI holds
the schema major it supports as a built-in constant (`CURRENT_SCHEMA_VERSION`,
currently `2`). Detect the **committed surface** three ways:

| Marker present | Classification | Committed schema major |
|---|---|---|
| neither `.skillshare/config.yaml` nor `.skillshare/repo.yml` | **uninitialized** | — |
| `.skillshare/config.yaml` and **no** `.skillshare/repo.yml` | **legacy** | implicit `1` (predates the field) |
| `.skillshare/repo.yml` present | **initialized** | its `schemaVersion` value |

Then inspect the **personal surface**: if `.skillshare/user.yml` is present and
carries active (non-comment) keys, read its `schemaVersion`. An absent or
entirely-commented `user.yml` is version-agnostic and contributes nothing.

Compare each surface's major to the CLI's `CURRENT_SCHEMA_VERSION`:

- **uninitialized** → tell the user this is not a migration and that
  `skillshare init` is the correct command. Stop.
- **both surfaces already current** (equal to the CLI major) → report that the
  repo is already current and stop. Do not perform a migration.
- **committed surface stale** (legacy layout, or `repo.yml` `schemaVersion` lower
  than the CLI major) → this is a **team migration**. Continue to Step 2 with the
  transition `<committed major> → <CLI major>` and the stale surface
  `repo.yml`/legacy.
- **only `user.yml` stale** (committed surface current, but `user.yml`'s
  `schemaVersion` is lower) → this is a **personal migration** of `user.yml`
  alone. Continue to Step 2 with the transition `<user major> → <CLI major>` and
  the stale surface `user.yml`; do **not** touch `repo.yml` or re-run any
  structural steps.
- **a surface newer than the CLI** (`schemaVersion` greater than the CLI major) →
  stop and report that the config was authored for a newer schema than this
  installed `@msys/skillshare` supports; instruct the user to upgrade the pinned
  dependency rather than migrating.

Carry the detected **transition** (e.g. `1 → 2`, `2 → 3`) and the **stale
surface(s)** into the next steps — Step 2 selects the `MIGRATION.md` section
matching that (transition × surface) pair.

---

## Step 2: Locate and read the packaged MIGRATION.md

The playbook ships inside the **installed** package, not as a hand-authored copy
in the repo. Resolve it from `node_modules`:

```
node_modules/@msys/skillshare/MIGRATION.md
```

In a workspace/monorepo it may be hoisted to the workspace root's
`node_modules/@msys/skillshare/MIGRATION.md`, or under a nested
`node_modules`. Resolve robustly — e.g.:

```bash
node -e "console.log(require.resolve('@msys/skillshare/MIGRATION.md'))" 2>/dev/null \
  || find . -path '*/node_modules/@msys/skillshare/MIGRATION.md' -not -path '*/node_modules/*/node_modules/*' | head -1
```

- **Found** → read the whole document, then read the section matching the detected
  **transition × stale surface** (e.g. the `1 → 2` section for a stale committed
  surface, or a `2 → 3` `user.yml` section for a stale personal layer). `MIGRATION.md`
  carries one section per (transition × surface). Build your plan strictly from
  that section. Note that `1 → 2` is the one **structural** transition (un-track,
  postinstall, gitignore, `config.yaml` → `repo.yml`); every later transition is a
  pure config-schema transform with no re-untracking.
- **Missing** → **stop and report**: the migration document could not be located
  in the installed `@msys/skillshare` package. Name the expected path
  (`node_modules/@msys/skillshare/MIGRATION.md`) and suggest the user install
  dependencies (so the package is present). Do **not** attempt a guessed
  migration.

---

## Step 3: Plan

Following the matching section of `MIGRATION.md`, compute the concrete changes
for **this** repo without modifying anything yet. What this entails depends on the
transition and stale surface:

- **Structural transition (`1 → 2`)** — read the current config and any manifest
  the doc references; run the doc's preconditions (the clean-working-tree check
  **excludes** this skill's own sync-placed `**/skills/skillshare-migrate/` dirs
  and other expected sync-placed/2.0-gitignored outputs — never flag those;
  manifest present); derive the transformed config built from the commented
  `content/defaults/repo.yml` template (`config.yaml` → `repo.yml`, with a fully
  enumerated `features:` block), the repo-local scaffolding to add (missing
  `.skillshare/{skills,agents,engineers,instructions,openspec-rules,targets}/` dirs with
  their `README.md`, plain-named `.skillshare/openspec-rules/<artifact>.md` splices, and a
  tracked `.skillshare/user.example.yml` — never a gitignored `user.yml`), the
  list of files to un-track, the bootstrap wiring, and the verification steps.
- **Config-schema transition (`2 → 3+`)** — read only the stale surface(s) the
  doc names (`repo.yml`, `user.yml`, or both) and derive the transformed config.
  Do **not** plan any un-tracking, postinstall, or gitignore wiring; outputs are
  already gitignored from the `1 → 2` migration.
- **Personal migration (`user.yml` alone)** — plan a transform of
  `.skillshare/user.yml` only. Do **not** read, plan, or touch `repo.yml` or any
  committed surface.

Honor every **decision point** the doc calls out. When the doc says to stop for a
user decision, stop and surface it.

---

## Step 4: Present the plan and confirm

Present the full plan to the user before changing anything. Show only the parts
the detected transition actually performs:

- The transformed config (always show it — `repo.yml`, `user.yml`, or both).
- For the structural `1 → 2` transition only: the repo-local scaffolding to add
  (missing `.skillshare/` subdirs with their `README.md`, populated
  `.skillshare/openspec-rules/<artifact>.md` splices, the tracked `user.example.yml`),
  exactly which files will be `git rm --cached` (un-tracked, not deleted), the
  `package.json` postinstall change, and the README pointer section.
- The verification steps that will run afterward.

Use the **AskUserQuestion** tool to confirm before applying:

| Option | Behavior |
|---|---|
| **Apply** (default) | Execute the migration as planned |
| **Cancel** | Make no changes to the repo |

**Apply nothing before explicit confirmation.** No file rewrites, no
`git rm --cached`, no postinstall edits. If the user declines, leave the repo
untouched.

---

## Step 5: Apply

After confirmation, execute the doc's steps in order. Respect every gate. The
structural steps below apply to the `1 → 2` transition **only** — a `2 → 3+`
config-schema transform rewrites the stale surface(s) and nothing else:

- Write `.skillshare/repo.yml` from the commented template with the repo's values
  and a fully enumerated `features:` block; remove `.skillshare/config.yaml`.
- Scaffold any missing repo-local dirs
  (`.skillshare/{skills,agents,engineers,instructions,openspec-rules,targets}/`) with their
  `README.md`, move 1.x rule additions into plain-named
  `.skillshare/openspec-rules/<artifact>.md` splices, and place the tracked
  `.skillshare/user.example.yml`. **Preserve existing files**; do **not** create a
  gitignored `.skillshare/user.yml`.
- Run `git rm --cached` on the paths the doc identifies — **never** delete the
  working-tree copies.
- Chain (do not overwrite) any existing `package.json` postinstall script.
- Add the README pointer section at an agent-judged, sensible location.

For a personal `user.yml` migration, rewrite `.skillshare/user.yml` only and leave
the committed surface untouched.

---

## Step 6: Verify

Per the doc's verification phase:

1. Run a final `{{ runPrefix }} skillshare sync` and confirm it completes without
   errors (on `1 → 2` this also materializes the gitignored outputs and the
   managed `.gitignore` block; on later transitions it simply re-renders from the
   migrated config).
2. Run `{{ runPrefix }} skillshare check --ci` and confirm it passes (the
   committed surface matches the committed config). For a personal `user.yml`
   migration the committed surface is unchanged, so `check --ci` should already be
   clean.
3. Surface the resulting `git diff` (and `git status`) so the user can review the
   migration (and, on `1 → 2`, the un-tracking and regeneration) before committing.

For the `1 → 2` transition, confirm the working-tree copies of un-tracked files
are still present.

---

## Guardrails

- **Defer to the packaged `MIGRATION.md` for every version-specific step.** This
  skill must remain version-agnostic — never hardcode transform rules here.
- **Run the structural steps (un-track, postinstall, gitignore) only on the
  `1 → 2` transition.** Later transitions are pure config-schema transforms.
- **Migrate only the stale surface(s).** A stale `user.yml` is a personal
  migration — never touch the committed `repo.yml` for it.
- **Never apply a destructive change before user confirmation** (file rewrites,
  `git rm --cached`, postinstall edits).
- **Never delete working-tree files** — un-tracking uses `git rm --cached` only.
- **Never commit** — surface the diff and let the user decide.
- **Stop on a missing migration doc** rather than guessing migration steps.
