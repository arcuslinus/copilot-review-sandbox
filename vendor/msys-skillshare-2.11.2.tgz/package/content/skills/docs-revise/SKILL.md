---
name: docs-revise
description: >
  Capture session changes and propose docs/ knowledge base updates — both updating
  existing documentation AND creating new docs for previously undocumented work.
  Use at the end of a session or when the user says "update the docs", "docs are
  out of date", "capture what we changed", "document this", or "write docs for
  what we built". Also triggers when a session introduced new modules, features,
  integrations, or patterns that have no corresponding documentation yet.
license: MIT
compatibility: Requires docs/ directory with markdown files and a git repository.
metadata:
  author: meistersystems
  version: "1.1"
skillset:
  name: wrap-up
  when: >
    the change plausibly affects documented behavior, architecture, setup, or guides in
    `docs/`
  phase: work
  writes: true
---

Review what changed in this session and propose updates to the `docs/` knowledge base — both **updating existing docs** that are now stale AND **creating new docs** for anything introduced that lacks documentation.

{% if (settings.autoDocs.docsConfirmPrompt | default("prompt")) == "prompt" -%}
**Do NOT make changes without explicit approval.** Always show proposed updates and get user sign-off before editing any file.
{%- else -%}
This skill shows proposed updates, then applies every proposed change automatically, without a confirmation prompt. Set `features.auto-docs.settings.docsConfirmPrompt: prompt` to restore approval before applying.
{%- endif %}

---

> **Not compatible with `/batch`.** This skill must not be run via `/batch`.
> Documentation changes are interdependent (cross-references, shared README, scope checks) and require
> coordinated output. If you are a sub-agent spawned by `/batch`, **stop immediately** and report back
> that this skill cannot be parallelized via `/batch`. For initializing documentation across an entire
> repository, use `/docs-init` instead.

---

## Scope: `docs/` vs `openspec/`

This project separates **usage documentation** from **implementation specifications**:

<!-- prettier-ignore -->
| | `docs/` | `openspec/specs/` |
| --- | --- | --- |
| **Purpose** | How to use the system, general knowledge, feature docs | Implementation specs, design decisions, requirements, tasks |
| **Audience** | Developers using/operating the system | Developers building/changing the system |
| **Content** | Setup guides, architecture overviews, feature usage, troubleshooting | Requirements, design rationale, implementation plans, task lists |
| **Managed by** | These skills (`/docs-audit`, `/docs-revise`) | OpenSpec skills (`/openspec-*`) |

**This skill operates ONLY on `docs/`.** Never read, audit, or modify files in `openspec/`.
If you encounter content in `docs/` that looks like implementation specs (requirements, design decisions, task lists), flag it as misplaced — it likely belongs in `openspec/specs/`.

---

## Step 1: Reflect on Session

Check what changed in the current session:

```bash
git diff --stat
git diff --name-only
```

If the working tree is clean, check recent commits:

```bash
git log --oneline -10
git diff --name-only HEAD~5..HEAD
```

Identify:

- **Modified modules** — which `apps/` and `libs/` packages were touched
- **Renamed files** — any file moves that docs might reference
- **Changed APIs** — modified GraphQL schema, tRPC routes, function signatures
- **Updated configs** — environment variables, Docker setup, build config
- **Migration changes** — new database migrations

Pay special attention to **net-new additions** — these are the most likely to have zero documentation:

- **New features** — new capabilities, endpoints, integrations, UI flows
- **New modules or packages** — new `apps/` or `libs/` entries
- **New dependencies or tools** — added packages, services, or dev tooling
- **New patterns** — architectural patterns, conventions, or techniques introduced for the first time
- **New infrastructure** — Docker services, CI pipelines, deployment targets, environment setup

---

## Step 2: Choose Documentation Scope

Before diving in, decide how broadly to document. Ask the user via the **AskUserQuestion** tool with these options:

1. **Comprehensive (default)** — Cover session changes **plus** anything you noticed was undocumented during the session — even if those areas weren't modified. This catches documentation gaps that surfaced while working.
2. **Session changes only** — Strictly document what the git diff shows. Nothing more.

The default is **Comprehensive**. In autonomous/non-interactive modes the default is selected automatically.

---

## Step 3: Identify Affected Docs

Search `docs/` for references to changed files, modules, and concepts:

```bash
# For each changed module/file, search docs for references
grep -r "module-name" docs/ --include="*.md"
grep -r "file-path" docs/ --include="*.md"
```

Build a mapping:

```
<!-- prettier-ignore -->
| Code Change | Affected Docs | Impact |
| --- | --- | --- |
| Renamed libs/foo → libs/bar | docs/architecture.md | Stale file path |
| New endpoint /api/xyz | docs/api/endpoints.md | Missing endpoint |
| Updated Docker config | docs/setup/local-dev.md | Outdated commands |
```

### Check for documentation gaps

For every net-new addition identified in Step 1, check whether documentation already exists. Search `docs/` for references to the new module, feature, or concept. If nothing is found, it belongs in the **New documentation** column.

If the user chose **Comprehensive** in Step 2 (the default), also include things you observed during the session that lack documentation — even if they weren't part of the diff. For example, if while working on a feature you noticed a sibling module has zero docs, include it here.

```
<!-- prettier-ignore -->
| New Addition | Existing Doc? | Action Needed |
| --- | --- | --- |
| New notifications feature | None | Create docs/features/notifications/overview.md |
| New /api/webhooks endpoint | None | Create docs/features/webhooks/overview.md + setup.md |
| New Redis caching layer | Mentioned briefly in architecture.md | Expand with dedicated section |
```

Think broadly — documentation gaps include:
- New modules or packages with no documentation at all
- New features with no user-facing explanation
- New integrations with no setup or usage guide
- New architectural patterns with no description in architecture docs
- New environment variables or config with no mention in setup docs
- New CLI commands, scripts, or dev tooling with no developer guide entry

---

## Step 4: Cross-repo awareness check (new docs only)

When Step 3 identifies **new documentation** to create (not updates to existing docs), verify the topics belong in this repository and aren't already documented elsewhere. Skip this step entirely if all proposed changes are updates to existing files.

### 4a. Check Atlassian MCP availability

Attempt to use the Atlassian MCP `search` tool. If it is unavailable (tool not found / not configured), call the **AskUserQuestion** tool with these options:

1. **Continue without cross-repo check (default)** — proceed with local-only behavior. Note in your output that cross-repo deduplication was skipped because the Atlassian MCP is not configured.
2. **Stop and configure Atlassian MCP** — explain that the Atlassian MCP enables cross-repo documentation deduplication via Confluence search, and stop execution so the user can configure it.

The default is **Continue without cross-repo check**. If selected, skip step 4b (Confluence search depends on the MCP) but still run step 4c — the repository scope check is local and does not depend on the MCP.

### 4b. Search Confluence for each new doc topic

For each new documentation page proposed in Step 3, use the Atlassian MCP `search` tool (Rovo Search):

```
search({ query: "<topic description>" })
```

**Only consider results from the shared `docs` space** (all technical documentation lives there). Ignore results from other spaces. Classify each `docs`-space result:

- **Duplicate** (same topic, same intent, owned by another repo) → inform the user and recommend linking instead of duplicating.
- **Related** (overlapping topic, different angle, owned by another repo) → note as a **cross-reference candidate**. Collect the page title, Confluence page-ID URL, and owning repo name. These will be offered as cross-repo links in Step 5.
- **Owned by the current repo** → call the **AskUserQuestion** tool with options `Update existing (default)` / `Create new`. The default is **Update existing**, which avoids duplication.
- **No relevant hits** → proceed with creating the new doc.

### 4c. Check repository scope

Read `docs/README.md` and look for the **Scope** section. For each new doc topic, check whether it falls within this repository's stated ownership:

- **"Does not own" list includes the topic's domain** → warn the user and recommend documenting in the correct repo.
- **No `docs/README.md` or no Scope section** → skip the scope check.

Remove any new doc proposals that the user decides should not be created here. Keep all updates to existing docs unchanged.

---

## Step 5: Draft Updates and New Docs

### Updates to existing docs

For each affected doc, draft specific edits:

- **One concept per change** — keep each edit focused
- **Match existing style** — follow the formatting conventions in `references/doc-conventions.md`
- **Use compact table format** with `<!-- prettier-ignore -->` before each table (applies to any table you add or replace)
- **Be precise** — use exact file paths, package names, and commands
- **Add, don't rewrite** — prefer targeted additions over rewrites unless the section is fundamentally wrong

**Cross-repo references for existing docs:** If Step 4 collected cross-reference candidates and an existing doc does not have a "Related documentation" section, offer to add one with relevant cross-repo links. Follow the conventions in `references/doc-conventions.md`.

### New documentation

For every documentation gap identified in Step 3, draft complete documentation — not just outlines. Read the source code to understand the new addition, then write docs that a developer could use without reading the code.

Each new doc should include:

- **File path** — place it in the appropriate `docs/` subdirectory (`architecture/`, `features/<name>/`, `guides/`, `setup/`, `steering/`). Feature docs go in `docs/features/<feature-name>/` with separate files (`overview.md`, `setup.md`, `architecture.md`, etc.). Feature-specific setup goes in the feature folder, not in `docs/setup/`. Use business feature names, not app/lib names. **Filenames and directories MUST be kebab-case** (lowercase + hyphens; no camelCase, snake_case, PascalCase, spaces, or uppercase letters). The only exception in `docs/` is `README.md`. See the **File Naming** section of `references/doc-conventions.md`.
- **Full content** — write the actual documentation, not a placeholder. Include:
  - What it is and why it exists
  - How to use it (with code examples or commands where applicable)
  - Configuration options and environment variables
  - How it relates to other parts of the system
  - Gotchas, limitations, or prerequisites
- **Use compact table format** with `<!-- prettier-ignore -->` before each table

When deciding between adding a section to an existing doc vs. creating a new doc:
- **Add a section** if the new addition is a small extension of an already-documented topic
- **Create a new doc** if the addition represents a distinct concept, module, or feature that would clutter an existing doc

**Cross-repo references for new docs:** If Step 4 collected cross-reference candidates for a new doc's topic, incorporate them into the draft — inline links where the topic is naturally mentioned, plus a "Related documentation" footer section as catch-all. Follow the conventions in `references/doc-conventions.md`.

---

## Step 6: Show Proposed Changes

**Before presenting the summary**, scan every proposed update and new doc and verify each markdown table starts with `<!-- prettier-ignore -->` and uses compact (no column padding) format. Fix any non-compliant tables in the drafts before showing the user.

Present a concise summary table of all proposed changes. Do NOT show full diffs by default — let the user request them.

```
## Proposed documentation updates

<!-- prettier-ignore -->
| # | File | Action | Summary |
| --- | --- | --- | --- |
| 1 | docs/features/auth/overview.md | Update | Add OAuth2 PKCE flow section, update token refresh sequence diagram |
| 2 | docs/setup/environment.md | Update | Add REDIS_URL to required env vars table |
| 3 | docs/features/export/overview.md | Create | New doc covering the CSV/XLSX export pipeline added this session |
```

**Action** column values: `Update`, `Create`, `Delete`, `Cross-ref` (for adding a "Related documentation" section to an existing doc).

If cross-repo references are proposed, include them as separate line items in the table so the user can approve or reject them individually.

{% if (settings.autoDocs.docsConfirmPrompt | default("prompt")) == "prompt" -%}
After showing the table, you **MUST** call the **AskUserQuestion** tool with the following options. Do not substitute a prose question, even if the choice feels binary — the options below are deliberate (defaults wired into auto/non-interactive modes).

1. **Apply all (default)** — apply every proposed change without showing full diffs first.
2. **Show diffs first** — display the full diff for every proposed change, then re-prompt.
3. **Apply specific items only** — follow up with a selection of which numbered items to apply.

The default is **Apply all**. In autonomous/non-interactive modes the default is selected automatically.
{%- else -%}
With `docsConfirmPrompt: auto` (the default), skip the interactive apply prompt entirely: apply every proposed change comprehensively — equivalent to choosing **Apply all** — without asking the user to confirm. (Autonomous/non-interactive execution already resolves to this same outcome regardless of this setting.)
{%- endif %}

---

## Step 7: Apply Changes

1. Edit the files selected in Step 6 — every proposed file when `docsConfirmPrompt` resolves to `auto` or the user chose **Apply all**; only the selected subset otherwise
2. Create the new files selected in Step 6, under the same rule
3. Format all modified files:
   ```bash
   {{ formatCommand }} <modified-files>
   ```
4. Show a summary of what was changed

---

## Step 8: Update scope descriptor and documentation index

After all approved changes are applied, follow the procedure in `references/readme-maintenance.md`:

1. **Check `docs/README.md` scope descriptor** — if the session introduced new domains or features, check whether the "Owns" list needs updating. If `docs/README.md` doesn't exist or has no Scope section, create one by investigating the codebase. When a scope update is proposed, call the **AskUserQuestion** tool with options `Apply scope update (default)` / `Skip scope update`. The default is **Apply scope update**.
2. **Regenerate root `README.md` documentation index** — auto-generated index of all doc files. No additional approval needed since it's a mechanical update.

---

## Guardrails

- **Scope-aware** — Respect the user's chosen scope: session changes only, or comprehensive (session changes + observed gaps). Don't audit everything (use `/docs-audit` for full audits)
{% if (settings.autoDocs.docsConfirmPrompt | default("prompt")) == "prompt" -%}
- **Get approval** — Every change needs explicit user sign-off
{%- else -%}
- **Apply automatically** — With `docsConfirmPrompt: auto` (the default), show the proposed changes and apply them directly, with no confirmation prompt. Set `features.auto-docs.settings.docsConfirmPrompt: prompt` to restore sign-off before applying.
{%- endif %}
- **Be specific** — When diffs or new-doc content are shown (the `Show diffs first` choice, or `docsConfirmPrompt: prompt`), show exact diffs for updates and full content for new docs
- **Stay in scope** — Only work with `docs/`. Never propose changes to files in `openspec/`. If code changes affect specs, tell the user to use the `/openspec-*` skills instead.
- **Document new things thoroughly** — New additions deserve complete documentation, not stubs. Read the source code and write docs that stand on their own.
- **Don't over-update** — Only propose changes where docs are actually affected by code changes. But DO propose new docs for anything that's genuinely undocumented.
- **Respect doc conventions** — follow the project's formatting standards (see `references/doc-conventions.md`), including kebab-case for all filenames and directories under `docs/` (only exception: `README.md`). When renaming or moving a doc as part of a revision, the new filename and any new parent directory MUST be kebab-case, even if the original was not.
- **Run Formatter** — Always format modified files before finishing
- **No git operations** — Never commit, push, create branches, or open pull requests. The skill's job ends at writing files to disk and formatting them. Git operations are the user's responsibility.
- **Sub-agent boundaries** — Sub-agents write files only when the skill explicitly directs them to. Sub-agents never perform git operations (commit, push, branch, PR). In all other phases, sub-agents only read files and return structured results.
