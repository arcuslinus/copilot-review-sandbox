---
name: git-commit-push-pr
description: >
  One-shot commit, push, and open a pull request via the GitHub CLI. Use when the user
  says "commit push and open a PR", "open a pull request", "commit push pr", "create a
  PR", or wants their changes committed, pushed, and a PR opened in a single step.
  Follows this repo's commit conventions for the commit and PR title, applies only
  already-existing repo labels discovered dynamically, and never blocks on a separate
  confirmation prompt — invoking the skill is the consent.
license: MIT
compatibility: Requires the GitHub CLI (gh) authenticated with repo access.
metadata:
  author: meistersystems
  version: "1.3"
skillset:
  name: wrap-up
  when: >
    there are working-tree changes to commit — or a scheduled work-phase (wave 1)
    writer such as docs-revise is expected to produce them — and there is a pull
    request to open or update. Schedule it whenever a wave-1 writer may create
    commits even if the tree is clean at triage time; it no-ops safely otherwise.
  phase: publish
  writes: true
---

# Git Commit, Push, and Open PR

Commit the working changes, push the branch, and open a pull request — in a single pass.

## Consent and transparency

Invoking this skill **is** the user's consent to commit, push, and open the PR. Do **not**
pause for a separate "are you sure?" confirmation before `gh pr create`. Instead, print the
plan **as you execute it** — the commit message, the PR title, the PR body, and the labels
you chose — so the user can see exactly what is happening.

## Step 1: Inspect the working tree and branch

```bash
git status
git diff             # unstaged changes
git diff --staged    # staged changes
git branch --show-current
git log --oneline -10
```

Determine the default branch as in git-commit-push. **If you are on the default branch,**
first create a ticket-prefixed feature branch (`<ticket-id>-description`, JIRA-ticket
prefixed) before committing — a PR cannot be opened from the default branch against itself.

## Step 2: Commit

Stage the relevant changes and create a single commit. Print the commit message.

If the working tree is clean (nothing to stage — e.g. this skill was scheduled by
`/dispatch` on the expectation that a work-phase writer would produce changes, but it
produced none), **skip the commit** rather than creating an empty one, and continue only
if there is still work: push when there are unpushed commits, open a PR when none exists.
If the tree is clean, there is nothing to push, and a PR already exists, there is nothing
to do — report the no-op and stop.

### Commit message conventions

{% include "instructions/commit-conventions/format.md" %}

Do not add any AI-attribution line to the commit message or the PR body.

## Step 3: Push

```bash
git push -u origin HEAD
```

Run this as-is — do not first check whether the branch exists on the remote (grepping
`git ls-remote` / `git branch -r`, inspecting upstream state). `git push -u origin HEAD` is
idempotent, so any such pre-check is redundant and error-prone: a case-sensitive lookup can
wrongly report an existing branch as missing and trigger a needless re-push.

If the push is rejected because the remote diverged, report it and stop — do not force-push.

## Step 4: Choose labels by dynamic discovery

Apply labels **only** by discovering what already exists in this repo. Never create a new
label, and never fail the PR over labels.

1. Discover the repo's existing labels:
   ```bash
   gh label list --json name,description
   ```
2. Infer the nature of the change from the diff, the branch name, and the JIRA ticket
   (e.g. a fix, a feature, docs, chore, refactor, dependency bump).
3. Select **only the intersection** of (labels that fit the change) and (labels that
   already exist in the repo). Pass each selected label to `gh pr create --label`.
4. **If discovery returns nothing, no existing label fits, or `gh label list` fails**
   (e.g. `gh` lacks label scope), open the PR with **no** labels. This is never a hard
   failure — a label-less PR is the correct fallback.

{% include "instructions/pr-labels.md" ignore missing %}

## Step 5: Decide draft vs ready for review

This repo's PR policy is **`{{ settings.gitCommands.prMode | default("smart") }}`**.

{% if settings.gitCommands.prMode == "always-draft" -%}
Open the PR as a **draft** (`gh pr create --draft`). Do not ask.
{%- elif settings.gitCommands.prMode == "always-ready" -%}
Open the PR **ready for review** (omit `--draft`). Do not ask.
{%- elif settings.gitCommands.prMode == "always-ask" -%}
Ask the user whether to open the PR as a **draft** or **ready for review**, defaulting to
**draft** — in Claude Code use the `AskUserQuestion` tool; in other tools, ask in your
normal way. Use `--draft` for draft, omit it for ready. (This is a parameter prompt, not a
consent gate — you still proceed to open the PR.)
{%- else -%}
Use the **smart** policy — open a draft silently while a change is in flight, otherwise ask:

1. Read the current branch's JIRA ticket from the prefix of `git branch --show-current`
   (e.g. `aim-29-add-filter` → `AIM-29`).
2. Check for an **active (unarchived)** OpenSpec change matching that ticket:
   ```bash
   openspec list --json
   ```
   Only active changes appear here; archived ones live in `openspec/changes/archive/` and
   do not. A change matches when its name carries the branch's ticket prefix.
   - **A matching active change exists** (work is in flight) → open the PR as a **draft**
     (`--draft`) **without asking**.
   - **Otherwise** — the change is already archived, nothing matches, or `openspec` is not
     installed/available → ask the user whether to open a **draft** or **ready for review**,
     defaulting to **draft** (in Claude Code via the `AskUserQuestion` tool, otherwise your
     normal prompt). Use `--draft` for draft, omit it for ready.
{%- endif %}

## Step 6: Open the PR

The PR **title** follows the same format as the commit subject (the conventions above).
Write a concise body summarizing the change. Apply only the labels selected in Step 4, and
add `--draft` only if Step 5 chose draft. Always pass `--assignee @me` so the PR is assigned
to its author on creation — `@me` is the authenticated user opening this same-repo PR and is
always a valid assignee, so this needs no fallback (unlike label discovery in Step 4).

### Information routing

{% include "instructions/workflow-routing.md" %}

**Your lane — PR body.** The PR body holds what changed + why, plus verification done **from the code, diff, branch, build, or tests** (technical, pre-merge). It does NOT hold functional product-UI scenarios a non-technical tester runs (QA Instructions lane) or actions only possible once merged and live (Post-Merge Items lane).

### PR body guidance

- Summarize **what changed and why**, at the altitude a reviewer needs.
- If you include a **Verification** section, list only **technical** checks performed
  **before** merge from the code, diff, branch, build, or tests. Do **NOT** include tasks
  that can only be checked **after** the PR is merged (those are Post-Merge Items), and do
  **NOT** include functional product-UI scenarios a non-technical tester runs (those are QA
  Instructions) — see the routing note above. Omit the section entirely when there is
  nothing pre-merge and technical to record.
- No `Co-Authored-By` or AI-attribution lines (per the commit conventions above).

```bash
gh pr create --title "<commit-subject-format>" --body "<summary>" --assignee @me --label <each-selected-label> [--draft]
```

Print the PR title, body, assignee, chosen labels, and whether it is a draft as you create it.

## Step 7: Report

Report the PR URL returned by `gh pr create`, and that the PR is assigned to you (`@me`).
