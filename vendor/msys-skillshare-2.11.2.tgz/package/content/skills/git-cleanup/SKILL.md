---
name: git-cleanup
description: >
  Run a full local git cleanup in one pass — prune stale worktrees, then delete stale
  local branches (gone or merged into the default branch). Use when the user says "clean
  up git", "git cleanup", "tidy up branches and worktrees", "clean up my local repo", or
  wants both worktree and branch cleanup at once. Previews what it will remove before
  acting, never touches the current worktree, current branch, or default branch, and
  reports cleanly when nothing qualifies.
license: MIT
metadata:
  author: meistersystems
  version: "1.0"
---

# Git Cleanup

Orchestrate a complete local cleanup in a single pass: first prune stale worktrees, then
delete stale local branches. Each phase previews what it will remove and reports a no-op
cleanly when nothing qualifies.

## Step 1: Worktree cleanup

Run the **git-worktree-cleanup** procedure: prune worktrees whose branch is gone or merged
and orphaned/stale `.claude/worktrees/` trees. Never remove the current worktree. Preview
the list before removing; report cleanly if none qualify.

Doing worktrees first frees any worktree that is holding a branch you will want to delete
in the next step.

## Step 2: Branch cleanup

Run the **git-branch-cleanup** procedure: delete local branches that are `[gone]` or
already merged into the default branch, removing a branch's worktree first if one still
holds it. Never delete the current branch or the default branch. Preview the list before
deleting; report cleanly if none qualify.

## Step 3: Report

Summarize the whole pass: the worktrees removed (Step 1) and the branches deleted (Step 2).
If neither phase removed anything, report that no cleanup was needed.
