---
name: openspec-apply-change
description: Implement tasks from an OpenSpec change. Use when the user wants to start implementing, continue implementation, or work through tasks.
license: MIT
compatibility: Requires openspec CLI.
metadata:
  author: openspec
  version: "1.1"
  generatedBy: "1.5.0"
---

> Run all `openspec` commands via `{{ runPrefix }} openspec`.

Implement tasks from an OpenSpec change.

**Store selection:** If the user names a store (a store is a standalone OpenSpec repo registered on this machine) or the work lives in one, run `openspec store list --json` to discover registered store ids, then pass `--store <id>` on the commands that read or write specs and changes (`new change`, `status`, `instructions`, `list`, `show`, `validate`, `archive`, `doctor`, `context`). Other commands do not take the flag. Hints printed by commands already carry the flag; keep it on follow-ups. Without a store, commands act on the nearest local `openspec/` root.

**Input**: Optionally specify a change name. If omitted, check if it can be inferred from conversation context. If vague or ambiguous you MUST prompt for available changes.

**Steps**

1. **Select the change**

   If a name is provided, use it. Otherwise:
   - Infer from conversation context if the user mentioned a change
   - Auto-select if only one active change exists
   - If ambiguous, run `openspec list --json` to get available changes and use the **AskUserQuestion tool** to let the user select

   Always announce: "Using change: <name>" and how to override (e.g., `/openspec-apply-change <other>`).

2. **Check status to understand the schema**

   ```bash
   openspec status --change "<name>" --json
   ```

   Parse the JSON to understand:
   - `schemaName`: The workflow being used (e.g., "spec-driven")
   - `planningHome`, `changeRoot`, and `actionContext`: planning scope and edit constraints
   - Which artifact contains the tasks (typically "tasks" for spec-driven, check status for others)

3. **Get apply instructions**

   ```bash
   openspec instructions apply --change "<name>" --json
   ```

   > Run as-is — never `| head/grep/python/jq` or truncate. The `rules` are binding.

   This returns:
   - `contextFiles`: artifact ID -> array of concrete file paths (varies by schema - could be proposal/specs/design/tasks or spec/tests/implementation/docs)
   - Progress (total, complete, remaining)
   - Task list with status
   - Dynamic instruction based on current state

   **Handle states:**
   - If `state: "blocked"` (missing artifacts): show message, suggest using openspec-continue-change
   - If `state: "all_done"`: congratulate, suggest archive
   - Otherwise: proceed to implementation

4. **Read context files**

   Read every file path listed under `contextFiles` from the apply instructions output.
   The files depend on the schema being used:
   - **spec-driven**: proposal, specs, design, tasks
   - Other schemas: follow the contextFiles from CLI output

5. **Show current progress**

   Display:
   - Schema being used
   - Progress: "N/M tasks complete"
   - Remaining tasks overview
   - Dynamic instruction from CLI

6. **Implement tasks (loop until done or blocked)**
   {%- if features.codingEngineers %}
   {%- if settings.codingEngineers.mode == "subagents" and target.supportsAgents %}

   Task sections are assigned to coding engineers via headings like `### <scope> (<engineer-name>)`.

   **You MUST delegate to the engineer agent — do NOT implement tasks directly.**

   For each task group (identified by a `###` heading with an engineer name in parentheses):
   - Parse the engineer name from the heading (e.g., `frontend-engineer` from `### apps/frontend (frontend-engineer)`)
   - **Spawn the Agent tool** with `subagent_type` set to `<engineer-name>-agent` (e.g., `frontend-engineer-agent`)
   - In the agent prompt, include: the task descriptions from this group, the relevant context from proposal/design/specs, and the instruction to mark tasks complete in the tasks file after each one
     {%- if flags.engineerReflection %}
   - Also instruct the agent to **end its report with a `## Definition Improvements` section**: concrete, grounded notes on where its own definition (`.skillshare/engineers/<engineer-name>.md`) was wrong, misleading, or missing something it had to discover during this work — or an explicit "none". Retain each agent's report so the reflection step can read these sections from context.
     {%- endif %}
   - Wait for the agent to complete before moving to the next task group
   - Verify the agent marked tasks complete; if not, mark them yourself

   For task groups WITHOUT an engineer in parentheses (e.g., verification steps):
   - Execute these tasks directly without delegation
   - Keep changes minimal and focused
   - Mark task complete: `- [ ]` → `- [x]`
     {%- else %}

   Task sections are assigned to coding engineers via headings like `### <scope> (<engineer-name>)`.

   For each task group (identified by a `###` heading with an engineer name in parentheses):
   - Parse the engineer name from the heading
   - **Load the corresponding skill** using the Skill tool (e.g., invoke skill `frontend-engineer`)
   - Apply the skill's instructions while executing the tasks in that group
   - Keep changes minimal and focused
   - Mark task complete: `- [ ]` → `- [x]`
     {%- if flags.engineerReflection %}
   - **Carry the per-engineer work context forward** (which engineer did what, where its definition helped or misled you) so the reflection step can self-reflect inline per engineer group at the end.
     {%- endif %}

   For task groups WITHOUT an engineer in parentheses:
   - Execute these tasks directly without loading a skill
   - Mark task complete: `- [ ]` → `- [x]`
     {%- endif %}
     {%- else %}

   For each pending task:
   - Show which task is being worked on
   - Make the code changes required
   - Keep changes minimal and focused
   - Mark task complete in the tasks file: `- [ ]` → `- [x]`
   - Continue to next task
     {%- endif %}

   **Pause if:**
   - Task is unclear → ask for clarification
   - Implementation reveals a design issue → suggest updating artifacts
   - Error or blocker encountered → report and wait for guidance
   - User interrupts
     {%- if features.codingEngineers and flags.engineerReflection %}

   **After the loop completes** (all assigned task groups done — **not** interleaved per task), invoke the `skillshare-engineers-reflect` skill **exactly once** to fold any grounded improvements back into the engineer definitions. Pass along the reflections collected during delegation (the agents' `## Definition Improvements` sections, or your carried-forward per-engineer work context).
   {%- endif %}

7. **On completion or pause, show status**

   Display:
   - Tasks completed this session
   - Overall progress: "N/M tasks complete"
   - If all done: suggest archive
   - If paused: explain why and wait for guidance

**Output During Implementation**

```
## Implementing: <change-name> (schema: <schema-name>)

Working on task 3/7: <task description>
[...implementation happening...]
✓ Task complete

Working on task 4/7: <task description>
[...implementation happening...]
✓ Task complete
```

**Output On Completion**

```
## Implementation Complete

**Change:** <change-name>
**Schema:** <schema-name>
**Progress:** 7/7 tasks complete ✓

### Completed This Session
- [x] Task 1
- [x] Task 2
...

All tasks complete! Ready to archive this change.
```

**Output On Pause (Issue Encountered)**

```
## Implementation Paused

**Change:** <change-name>
**Schema:** <schema-name>
**Progress:** 4/7 tasks complete

### Issue Encountered
<description of the issue>

**Options:**
1. <option 1>
2. <option 2>
3. Other approach

What would you like to do?
```

**Guardrails**

- Keep going through tasks until done or blocked
- Always read context files before starting (from the apply instructions output)
- If task is ambiguous, pause and ask before implementing
- If implementation reveals issues, pause and suggest artifact updates
- Keep code changes minimal and scoped to each task
- Update task checkbox immediately after completing each task
- Pause on errors, blockers, or unclear requirements - don't guess
- Use contextFiles from CLI output, don't assume specific file names

**Fluid Workflow Integration**

This skill supports the "actions on a change" model:

- **Can be invoked anytime**: Before all artifacts are done (if tasks exist), after partial implementation, interleaved with other actions
- **Allows artifact updates**: If implementation reveals design issues, suggest updating artifacts - not phase-locked, work fluidly
