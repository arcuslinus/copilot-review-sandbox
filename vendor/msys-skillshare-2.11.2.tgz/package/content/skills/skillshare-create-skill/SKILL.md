---
name: skillshare-create-skill
description: Create new skills, modify and improve existing skills, and measure skill performance — all through the Skillshare distribution pipeline. Use when users want to create a skill from scratch, edit or optimize an existing skill, run evals to test a skill, benchmark skill performance, or optimize a skill's description for better triggering accuracy. Also triggers when users mention "create a skill", "new skill", "improve this skill", or want skills available in all their AI coding assistants. Skills are written to the correct Skillshare-managed location and distributed to all configured AI tool directories via `skillshare sync`.
license: MIT
---

# Skillshare Skill Creator

Create, test, iterate, and distribute skills through the Skillshare distribution pipeline.

At a high level, the process goes like this:

- Decide what the skill should do and roughly how it should do it
- Choose the right destination (Skillshare manages where skills live)
- Write a draft of the skill
- Create a few test prompts and run them
- Help the user evaluate the results both qualitatively and quantitatively
- Rewrite the skill based on feedback
- Repeat until satisfied
- Distribute via `{{ runPrefix }} skillshare sync`

Your job is to figure out where the user is in this process and jump in to help them progress. Maybe they want to create a skill from scratch, maybe they already have a draft, maybe they just want to improve an existing skill. Be flexible.

**IMPORTANT:** Never create skills directly in `.claude/skills/` or other tool directories — those are managed by Skillshare and overwritten on sync. Always write to the source-of-truth location described below.

---

## Communicating with the user

Pay attention to context cues to understand how to phrase your communication. "evaluation" and "benchmark" are fine; for "JSON" and "assertion", see cues from the user before using them without explanation. Briefly explain terms if in doubt.

---

## Phase 1: Capture Intent

Start by understanding the user's intent. The current conversation might already contain a workflow the user wants to capture (e.g., they say "turn this into a skill"). If so, extract answers from the conversation history first — the tools used, the sequence of steps, corrections the user made, input/output formats observed. The user fills the gaps and confirms before proceeding.

1. What should this skill enable the AI agent to do?
2. When should this skill trigger? (what user phrases/contexts)
3. What's the expected output format?
4. Should we set up test cases? Skills with objectively verifiable outputs (file transforms, data extraction, code generation, fixed workflow steps) benefit from test cases. Skills with subjective outputs (writing style, art) often don't. Suggest the appropriate default, let the user decide.

Proactively ask about edge cases, input/output formats, example files, success criteria, and dependencies. Wait to write test prompts until this part is ironed out.

---
## Phase 2: Choose Scope

**Before writing anything, ask the user where the skill should live** — use the **AskUserQuestion tool** with the explicit options below (do not collapse to a prose prompt). The scope decides the destination directory and whether the skill is committed/shared or personal.

{% if repoName == "msys-skillshare" %}
This is the Skillshare repository itself, so **all four** scopes are available (default **Skillshare-Shared**):

| Option | Directory | Committed | Effect |
|---|---|---|---|
| **Skillshare-Shared** (default) | `content/skills/<name>/` | yes (package source) | Distributed to **all consuming repos** on their next sync. After creating, update `content/README.md` (skill table) and `content/skills/skillshare-onboard/SKILL.md` (discovery tables). |
| **Repo-Shared** | `.skillshare/skills/<name>/` | yes (this repo) | Team-shared in this repo only; synced to this repo's tool dirs |
| **User-Global** | `~/.skillshare/skills/<name>/` | no (home dir) | Personal; synced into **every** repo you work in |
| **User-Repo** | `.skillshare/skills/user/<name>/` | no (gitignored) | Personal; this repo only |
{% else %}
Three scopes are available (the **Skillshare-Shared** catalog scope only exists inside the `msys-skillshare` package repo). Default **Repo-Shared**:

| Option | Directory | Committed | Effect |
|---|---|---|---|
| **Repo-Shared** (default) | `.skillshare/skills/<name>/` | yes | Team-shared, committed; synced to every configured tool's skills dir for everyone on the repo |
| **User-Global** | `~/.skillshare/skills/<name>/` | no (home dir) | Personal; synced into **every** repo you work in |
| **User-Repo** | `.skillshare/skills/user/<name>/` | no (gitignored) | Personal; this repo only |
{% endif %}

The repo-shared and personal scopes are **synced by default — enabled by presence** (no config entry needed); **User-Global** and **User-Repo** content is **never committed**. `user` is a reserved subfolder name in `.skillshare/skills/`.

> **User-Global path on Windows.** `~` is the developer's home directory — it is **not** expanded by `cmd`/PowerShell, so create the skill at the real location: `%USERPROFILE%\.skillshare\skills\<name>\` in `cmd`, or `$HOME\.skillshare\skills\<name>\` in PowerShell (on macOS/Linux it's `~/.skillshare/skills/<name>/`). The skillshare CLI resolves this via `os.homedir()` on every OS, so once the file exists in the right place sync picks it up identically.

Before writing, validate:
- Name is kebab-case (`/^[a-z0-9]+(-[a-z0-9]+)*$/`)
- No skill with that name already exists at the target destination

---

## Phase 3: Write the Skill

### Skill Structure

```
skill-name/
├── SKILL.md          # Required: YAML frontmatter + markdown instructions
├── scripts/          # Optional: executable code for deterministic tasks
├── references/       # Optional: docs loaded into context as needed
└── assets/           # Optional: templates, icons, other output files
```

### SKILL.md Format

```yaml
---
name: skill-name
description: >
  What the skill does AND when to use it. This is the primary triggering
  mechanism. Be specific about trigger phrases and contexts.
license: MIT
---
# Skill Name

Instructions go here...
```

### Progressive Disclosure

Skills use a three-level loading system:
1. **Metadata** (name + description) — always in context (~100 words)
2. **SKILL.md body** — in context whenever skill triggers (<500 lines ideal)
3. **Bundled resources** — as needed (unlimited, scripts can execute without loading)

Keep SKILL.md under 500 lines; put detailed reference material in `references/` with clear pointers from SKILL.md about when to read them.

### Writing Principles

{% include "references/writing-instructions.md" ignore missing %}

Two further principles specific to distributed skills:

- **Generalize.** Write for the general case, not just test examples. Avoid overfitting.
- **Stay tool-agnostic.** Never reference specific AI tools by brand name in skill instructions or descriptions. Use "AI agent" or "the agent" instead. Skills are distributed across multiple AI tools and must read naturally in all of them.

### Description Writing

The description field determines whether the skill triggers. Include:

- What the skill does (core capability)
- Specific user phrases and contexts that should trigger it
- Adjacent scenarios that might be missed by a conservative trigger

Be a little "pushy" to combat under-triggering:

- Weak: "Create API documentation"
- Strong: "Create API documentation from source code. Use when the user mentions API docs, endpoint documentation, OpenAPI/Swagger generation, REST API reference, or wants to document their backend routes — even if they don't say 'documentation' explicitly."

---

## Phase 4: Test and Iterate

### Create Test Cases

Draft 2-3 realistic test prompts — the kind of thing a real user would actually say. Share them with the user for confirmation before running.

Save test cases to `evals/evals.json` in a workspace directory (sibling to the skill):

```json
{
  "skill_name": "example-skill",
  "evals": [
    {
      "id": 1,
      "prompt": "User's task prompt",
      "expected_output": "Description of expected result",
      "files": []
    }
  ]
}
```

### Run Tests

For each test case, spawn two subagents in the same turn — one with the skill, one without (baseline):

**With-skill run:**

```
Execute this task:
- Skill path: <path-to-skill>
- Task: <eval prompt>
- Input files: <eval files if any, or "none">
- Save outputs to: <workspace>/iteration-<N>/eval-<ID>/with_skill/outputs/
```

**Baseline run:** Same prompt, no skill, save to `without_skill/outputs/`.

### Evaluate

1. **Qualitative review** — show outputs to the user, get feedback on what works and what doesn't
2. **Quantitative assertions** (optional) — for objectively verifiable skills, draft assertions that can be checked programmatically. Good assertions have descriptive names and are objectively verifiable. Don't force assertions onto subjective outputs.
3. **Iterate** — improve the skill based on feedback, rerun tests, review, repeat

### Improvement Principles

When revising a skill based on feedback:

1. **Generalize from the feedback.** The skill will be used across many prompts, not just test cases. Don't make fiddly changes that only fix specific examples.
2. **Look for repeated work.** If all test runs independently wrote similar helper scripts, bundle that script in `scripts/`.
3. **Read the transcripts.** Look at what the model actually did, not just the final output.

---

## Phase 5: Distribute

After the skill is ready, distribute it to all configured AI tool directories.

Ask the user (using the **AskUserQuestion tool** with explicit options):

> Run `{{ runPrefix }} skillshare sync` now to distribute the skill to all configured tool directories?

| Option | Behavior |
|---|---|
| **Yes** (default) | Run `{{ runPrefix }} skillshare sync` immediately |
| **No** | Skip — remind the user to run `{{ runPrefix }} skillshare sync` later |

Skillshare sync handles everything: renders templates with variable substitution, injects the managed header, copies to every configured tool's skills directory, and updates the manifest.

---

## Guardrails

- **Never write skills directly to tool directories** (`.claude/skills/`, `.cursor/skills/`, etc.) — those are managed by Skillshare and overwritten on sync.
- **Never skip name validation** — duplicate names cause sync collisions.
- **Always use AskUserQuestion** for the destination and sync prompts with the exact options listed above.
- **Always distribute via `{{ runPrefix }} skillshare sync`** — never copy files manually between tool directories.
