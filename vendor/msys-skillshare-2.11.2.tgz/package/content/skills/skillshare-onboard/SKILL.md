---
name: skillshare-onboard
description: Migrate existing hand-written AI instruction files (CLAUDE.md, AGENTS.md, .cursorrules, copilot-instructions.md) into skillshare-managed templates. Use when onboarding a repository to @msys/skillshare for the first time.
license: MIT
---

Migrate this repository's existing hand-written instruction files into skillshare's managed template system.

## Scope

This skill handles **instruction file migration only**:

- Configure `variables`, `features`, and `tools` in `.skillshare/repo.yml`
- Run a baseline sync to see what skillshare provides out of the box
- Compare baseline output against old hand-written instruction files
- Migrate only the repo-specific content that isn't already covered

**Leave all other config at defaults** — do not add `skills` or `github-workflows` selection maps unless a feature genuinely
provides the wrong set. These are advanced overrides; the `features:` block handles most repos.

> **2.0 config model.** Configuration is a four-layer cascade: org defaults ship in the package's `global.yml`, the
> committed `.skillshare/repo.yml` holds this repo's deviations, the gitignored `~/.skillshare/user.yml` holds the
> developer's deviations across **every** repo, and the gitignored `.skillshare/user.yml` holds this repo's
> per-developer deviations (highest precedence). `repo.yml` carries **only deviations** — anything not set inherits
> from `global.yml`. Generated outputs (skills, instruction files, rules) are **gitignored** and regenerated
> per-machine; the committed generated outputs are `.github/workflows/skillshare-*.yml`, `.skillshare/README.md`,
> and — when `github-copilot` is committed-selected (the default) — `.github/copilot-instructions.md` (read
> server-side by GitHub's Copilot reviewer — committed by necessity).
>
> **Personal content layers (gitignored).** Beyond config, a developer can add personal *content* of every type
> without committing it: per repo under `.skillshare/<type>/user/` (repo-user) and across all repos under
> `~/.skillshare/<type>/` (global-user, plus `~/.skillshare/user.yml` config). Both are synced by default
> (enabled by presence) and never affect committed outputs or `check --ci`. Onboarding does not configure these —
> they are personal and out of scope here.

## Step 1: Read skillshare config and docs

Read these files to understand the available options:

- `.skillshare/repo.yml` — the committed repo layer (deviations + explicit variable fill-ins), with inline comments
- `.skillshare/user.yml` — the commented personal-deviation example (gitignored, this repo only)
- `~/.skillshare/user.yml` — optional global personal config + `~/.skillshare/<type>/` personal content that apply
  to every repo you sync (gitignored, out of scope for onboarding)
- `.skillshare/README.md` — full reference for the cascade, variables, features, tools, flags, and the two
  personal content layers (`.skillshare/<type>/user/` repo-user and `~/.skillshare/<type>/` global-user)

## Step 2: Discover existing instruction files

Search for hand-written instruction files that will be replaced by skillshare-managed versions:

| File                                   | Tool                      | Managed replacement                        |
|----------------------------------------|---------------------------|--------------------------------------------|
| `CLAUDE.md`                            | Claude Code               | Managed `CLAUDE.md`                        |
| `AGENTS.md`                            | Codex / Gemini / OpenCode / .agents | Managed `AGENTS.md`                        |
| `.cursorrules` or `.cursor/rules/*.md` | Cursor                    | Managed `.cursor/rules/skillshare/RULE.md` |
| `.github/copilot-instructions.md`      | GitHub Copilot            | Managed `.github/copilot-instructions.md`  |

Read all existing instruction files and keep their content for comparison in Step 5. Also check `.claude/settings.json`,
`.claude/commands/`, and other tool-specific config for additional context worth preserving.

## Step 3: Configure repo.yml

Configure the following sections in `.skillshare/repo.yml`. Do **not** add `skills` or `github-workflows` overrides — these are
derived from the enabled `features:` block. Leave the local splice files (`.skillshare/instructions/*.md`) empty for now
— they will be populated in Step 5 after seeing the baseline.

**Tools** — `tools` is a selection **array** with replace semantics; absent means all defined tools. Set it to only the
tools actually used. Check which tool directories exist:

- `.claude/` → `claude`
- `.codex/` → `codex`
- `.cursor/` → `cursor`
- `.gemini/` → `gemini`
- `.github/` → `github-copilot`
- `.opencode/` → `opencode`
- `.agents/` → `dot-agents`

```yaml
tools: [claude, cursor]
```

**Variables** — values for the `variables:` section. Variables are **explicit** — skillshare infers nothing from
`package.json`, the lockfile, or `.nvmrc`, so every value a template references must be set:

- `repoName` — repository name (also the Confluence root page title and label, e.g. labels `docs` + `ms-platform`)
- `packageManager` — npm/bun/pnpm/yarn
- `runPrefix` — command prefix (npx/bun/pnpm)
- `nodeVersion` — Node.js version for CI workflows (e.g. `"22"`)
- `formatCommand` — the repo's lint/format command
- `defaultBranch` — only set if the repo's default branch is not `main` (ships in `global.yml` as `"main"`)
- `commitFormat` — optional. Set to `"commitlint-jira-type"` only if the repo enforces the dwmt
  [commitlint-jira-type](https://github.com/dwmt/commitlint-jira-type) standard via husky (look for
  `@dwmt/commitlint-config-jira-type` in `package.json` or a `commitlint.config.{js,mjs}` extending it). Otherwise omit
  it (defaults to the standard `(<TICKET-ID>) description` format).

**Feature sets** — enable the feature sets that match the repo. A feature value is either a bare boolean or an override
object whose selection fields are `name: true|false` maps:

- `ts-coding-standards: true` — if the repo uses typescript (includes the Coding Standards block of the shared
  instructions)
- `review-triage: true` — if the repo uses GitHub PRs with automated reviewers (Copilot, code-quality bots, etc.) and
  wants skills to triage and resolve review comments
- `coding-engineers: true` — if the repo wants domain-specific coding engineers (backend, frontend, database, infra)
  that auto-apply during OpenSpec task execution. After enabling, run `skillshare-setup-coding-engineers` to bootstrap
  engineer definitions. Set `features.coding-engineers.settings.mode: skills` to force skill-only mode (no agent delegation).
- `ts7-lsp: true` — only if the workspace `typescript` version is **≥ 7** (check `package.json` / the lockfile; the
  plugin spawns `node_modules/.bin/tsc --lsp`, which exists only from TypeScript 7). It distributes the
  `typescript-lsp` Claude Code plugin (go-to-definition, find references, hover, workspace symbols, diagnostics) and
  contributes `lspNavigation: true`, which adds the LSP-first navigation guidance to the instruction files and
  activates the coding-engineer LSP snippets. Leave it off below TypeScript 7 — the language server then fails to
  attach with no visible error. A repo running a different language server can set `flags: { lspNavigation: true }`
  on its own, without this feature.
- `skillsets: true` — if the repo wants a single `/dispatch <skillset>` command to triage which post-implementation follow-up
  skills apply to the current change, show a preview of what will run, then start immediately (no confirmation prompt) and run
  them unattended as background sub-agents. Ships
  two skillsets: `wrap-up` (QA instructions, the post-merge checklist, docs-revise, commit/push/PR) and `review`
  (change verification, review-resolution). Off by default. See Step 6 for how it changes the final OpenSpec task.

Note: The `auto-docs` feature set also includes the `docs-research-agent` shared agent (from `content/agents/`), which
is automatically synced to agent-capable tools. No per-repo configuration is needed — enabling `auto-docs` is sufficient.

Note: The default-on `git-commands` feature set provides six on-demand `git-*` skills (`git-commit`, `git-commit-push`,
`git-commit-push-pr`, `git-branch-cleanup`, `git-worktree-cleanup`, `git-cleanup`) that carry this repo's commit/PR
conventions (templated via `commitFormat`) and branch/worktree cleanup procedures. They load only when git work happens,
so the always-on instruction surface no longer repeats the commit/PR format or the "confirm before committing" rule.
No per-repo configuration is needed; opt out with `features: { git-commands: false }` in `repo.yml` only if the repo declines the shared git skills. The `git-commit-push-pr` skill's draft/ready behavior is governed by the feature-scoped `prMode` setting (default `smart` — draft while an OpenSpec change for the branch's ticket is in flight, else ask; other values `always-ask`, `always-draft`, `always-ready`), overridable via `features: { git-commands: { settings: { prMode: … } } }`.

- Only toggle features that deviate from the org defaults in `global.yml` — leave the rest absent.
- Note: `skillshare-create-skill`, `skillshare-migrate`, `skillshare-modify`, and `skillshare-evaluate` are included
  **by default** via the `skillshare-management` feature, which is on by default — no feature toggle needed. Disabling
  that feature (`features: { skillshare-management: false }`) drops these skills.

Instruction content and OpenSpec rules are derived automatically from enabled features — do not configure them manually.
To suppress an individual bullet (e.g. the JIRA-prefix rule), set the corresponding positive flag to `false` in `flags:`
— see `.skillshare/README.md` → Flags for the full list.

**Flags** — flags have **positive names** and are on by default (each is declared with its default by the content that
consumes it; the closed set is the union of those declarations). `repo.yml` holds only **deviations**: set a flag to
`false` to suppress its content, or `true` to force it on. Analyze the repository to determine which base rule bullets
are irrelevant for this project type. Common profiles:

- **Infrastructure/CDK repos** (no application code, only IaC): set `appImpact: false`, `dataChanges: false`,
  `apiContracts: false`, `tddWorkflow: false`
- **Frontend-only repos** (no backend API or database code): set `dataChanges: false`
- **Full-stack / backend repos**: typically leave all flags at defaults (omit the `flags:` block)

```yaml
flags:
  appImpact: false
  tddWorkflow: false
```

See `.skillshare/README.md` → Flags for the full list of available flags and what each suppresses. A flag set here that
is not declared anywhere is a validation error.

**Hooks** — `hooks.postSync` defaults (in `global.yml`) to `{{ packageManager }} run format:fix`. Override it in
`repo.yml` only if this repo's formatter differs; set to `false` to disable. It runs automatically after sync.

## Step 4: Run baseline sync

Run `{{ runPrefix }} skillshare sync` with the local splice files still empty. This generates the baseline — everything
skillshare provides out of the box with the configured features. Review the output to verify no template errors.

Then read a rendered instruction file (e.g. `CLAUDE.md`) to see the baseline content. This is what skillshare already
provides — you will use it in the next step. (The instruction file is gitignored but present on disk after sync.)

## Step 5: Migrate only the gap

Compare the baseline rendered output from Step 4 against the old hand-written instruction files discovered in Step 2.
The goal is to keep the local splice files **minimal** — only add content that is truly repo-specific and not already
covered by the shared template.

**Mandatory check:** For EVERY bullet you are about to write into a local splice file, search the baseline rendered
output for the same concept (same meaning, not necessarily same words). If the baseline already covers it — even
partially — do not add it. This check applies to every line, not just the examples below.

Common content that is already covered by the shared template or skills (do NOT migrate):

- Commit message / PR conventions — already carried by the `git-*` skills (`git-commands` feature); branch-name format is in Project Context
- "Check package.json scripts" — already in Project Context
- "Use docs skills", "never edit docs/ directly" — already in the Documentation block (when `auto-docs` is enabled)
- Doc formatting conventions (mermaid diagrams, table format, heading case) — already in the docs skills' reference
  files
- "docs/ directory" references — already in the Documentation block
- "JIRA ticket ID from branch name" — already in the OpenSpec Workflow block (when `openspec-enhanced` is enabled)
- "Run the formatter before finishing" — already in the OpenSpec Workflow block
- "No `!` assertions", "no `any`" — already in Coding Standards (when `ts-coding-standards` is enabled)
- TDD workflow — already in the shared task rules
- "Invoke docs-revise after apply/verify" — belongs in OpenSpec task rules (`.skillshare/openspec-rules/tasks.md`), not in
  local instruction files

Populate the local splice files with only the remaining repo-specific content. When in doubt, put it in
`project-context.md` — it is the primary file for most repo-specific content. The scaffolded files contain example
comments showing what belongs in each.

1. **`.skillshare/instructions/project-context.md`** — what this project IS. Its purpose, business domain, high-level
   description. Examples: "Enterprise SaaS platform for X", "Turbo monorepo with 20+ apps", team structure.
2. **`.skillshare/instructions/technical-context.md`** — how the project is built. Tech stack, architecture, system
   topology, data flow, build/test commands. Rendered under Project Context in instruction files AND as the `context:`
   block in the generated `openspec/config.yaml`. Examples: frameworks, databases, infra, testing patterns, CI setup.
3. **`.skillshare/instructions/coding-standards.md`** — how to write code in this project. Repo-specific rules beyond
   what feature sets already provide. Examples: type-check commands, import conventions, naming patterns, framework-
   specific rules (e.g. "use Kysely, not raw SQL"), doc formatting conventions.

Each file is free-form markdown. You can use Nunjucks template variables: `{{ repoName }}`, `{{ packageManager }}`,
`{{ runPrefix }}`, `{{ formatCommand }}`. Leave any you don't need empty (or delete them — empty and absent render
identically).

## Step 6: Configure OpenSpec rules (optional)

If the repo uses OpenSpec (check for `openspec/config.yaml`):

OpenSpec rules and context are derived automatically from the `openspec-enhanced` feature set. You only need to
configure repo-specific additions.

1. Read the existing `openspec/config.yaml` to understand the current `context:` and `rules:` sections.
2. Repo-specific OpenSpec context should already be in `.skillshare/instructions/technical-context.md` from Step 5.
3. If any base rule bullets are irrelevant for this project (e.g. GraphQL rules in an infra repo), suppress them via
   positive flags set to `false` in `repo.yml` rather than overriding the rule template — see Step 3 for common profiles.
4. For repo-specific rule additions, edit the flat rule splice files scaffolded by `skillshare init`:
    - `.skillshare/openspec-rules/tasks.md` — additional task rules
    - `.skillshare/openspec-rules/proposal.md` — additional proposal rules
    - `.skillshare/openspec-rules/design.md` — additional design rules
    - `.skillshare/openspec-rules/specs.md` — additional spec rules
    - Each file contains YAML list items (lines starting with `- `); Nunjucks variables and flag conditionals are
      supported, and you may declare new flags in frontmatter.
    - No `repo.yml` changes are needed — custom rules are spliced into the composed per-artifact templates automatically.

> The 2.0 rules layout is **flat** — `.skillshare/openspec-rules/<artifact>.md`, no per-artifact sub-folders. There is no
> `rules:` config key; OpenSpec `config.yaml` generation is driven by the feature contributing an `openspec-rules` map.

5. **QA instructions (opt-in).** With `openspec-enhanced`, enabling the `qaInstructions` flag (off by default — set
   `flags: { qaInstructions: true }`) makes `tasks.md` render a final pre-merge task invoking the
   `create-qa-instructions` skill. The skill reads its shipped defaults from `references/qa-conventions.md`; to add repo-specific
   QA-generation guidance (mandatory environments, required scenario types, house format rules), create an optional
   `.skillshare/references/qa-conventions.md` — it is discovered by presence (no config entry) and is **spliced onto the end of**
   the shipped defaults at sync time, with repo guidance winning on conflict.

6. **Skillset dispatch engine (opt-in).** Enabling `features: { skillsets: true }` replaces the final `tasks.md`
   follow-up task(s) — QA instructions, the post-merge checklist, and the mandatory `docs-revise` invocation — with a
   single `(Mandatory, non-skippable) /dispatch wrap-up` task. The `dispatch` skill triages which of those (plus any
   repo-local members) actually apply to the change, shows a preview of the scheduled members, then starts immediately
   (no confirmation prompt) and runs the scheduled members unattended as background sub-agents. The `qaInstructions`/`postMergeChecklist` flags still exist and still default to `false`,
   but with `skillsets` enabled they act as static membership toggles for the corresponding `wrap-up` skillset member
   instead of rendering an individual task. A repo-local skill joins a skillset (e.g. ms-platform's `infra-changes`) by
   adding a `skillset:` block (`name`, `when`, optional `phase`/`writes`/`runsOn`/`modelTier`) to its own frontmatter — no `repo.yml` entry
   needed.

Skip this step if the repo does not use OpenSpec.

## Step 7: Bootstrap documentation (optional)

If the repo uses the `auto-docs` feature and needs initial documentation:

1. Run `{{ runPrefix }} skillshare sync` to distribute the docs skills (including `/docs-init`).
2. Tell the user to invoke `/docs-init` in a separate session to bootstrap the documentation. Do NOT run it yourself
   during onboarding — it is a heavyweight skill that scans the entire codebase, drafts all docs in parallel, and creates
   the `docs/README.md` scope descriptor and root `README.md` documentation index.

If the repo already has a populated `docs/` directory with a scope descriptor in `docs/README.md`, skip this step. The
ongoing docs skills (`/docs-add`, `/docs-revise`, `/docs-audit`) handle maintenance.

If the repo does not use `auto-docs`, skip this step entirely.

## Step 8: Wire the bootstrap

Generated outputs are gitignored, so each machine regenerates them on install via a postinstall hook. `skillshare init`
wires this automatically; verify (or add) it during onboarding:

1. **postinstall** — ensure `package.json` `scripts.postinstall` runs `skillshare sync --yes` (the `--yes` keeps it
   non-interactive during install), chained after any existing script with ` && ` (e.g.
   `"postinstall": "husky && skillshare sync --yes"`). Never overwrite an existing postinstall.
2. **README pointer** — add a short section to the repo's `README.md` (agent-judged placement, e.g. near "Development")
   explaining that AI instruction files, skills, and OpenSpec rules are skillshare-managed and gitignored (except the
   committed `.github/copilot-instructions.md`), and regenerate
   on `{{ packageManager }} install` (via postinstall) or by running `{{ runPrefix }} skillshare sync`. This is brief
   prose, not a managed block.

## Step 9: Run final sync

Run `{{ runPrefix }} skillshare sync` to regenerate all managed files with the local content included. Review the output
to verify:

- Instruction files contain the expected content
- Skills are synced to the correct tool directories
- Workflows are synced to `.github/workflows/skillshare-{name}.yml` (the `skillshare-` filename prefix)
- The managed `.gitignore` block lists the per-tool ignore patterns
- No template errors

### AWS auth for Confluence workflows

If the `docs-to-confluence` or `openspec-to-confluence` workflows are included (default), the consumer repo needs:

1. An `npm:login` script in `package.json` (typically
   `aws codeartifact login --namespace=@msys --tool npm --repository msys-npm --domain msys`).
2. The org-level GitHub Actions Variable `SKILLSHARE_AWS_ROLE_ARN` to be set (one-time, managed centrally — see
   `.skillshare/README.md` "AWS Auth (CodeArtifact)").

If this repo doesn't use AWS CodeArtifact, disable the `auto-docs` and `openspec-enhanced` features (which include the
Confluence workflows), or use a per-feature override to exclude just the workflows:

```yaml
# Option 1: disable the features entirely
features:
  auto-docs: false
  openspec-enhanced: false

# Option 2: keep features but exclude individual workflows via name→bool maps
features:
  openspec-enhanced:
    enabled: true
    github-workflows:
      openspec-to-confluence: false
  auto-docs:
    enabled: true
    github-workflows:
      docs-to-confluence: false
```

## Step 10: Verify with git diff

Run `git diff` and `git status` to review all changes. Verify:

1. **`.skillshare/repo.yml`** — has the correct `tools`, `variables`, `features`, and any flag deviations.
2. **`.skillshare/instructions/*.md`** — contain only repo-specific content not already covered by the shared template.
   These files should be minimal.
3. **`.gitignore`** — contains the managed skillshare block (the per-tool coarse ignore patterns and fixed paths). The
   generated instruction files, skills, and rules are gitignored and will NOT appear as committed changes — except
   `.github/copilot-instructions.md`, which is committed by necessity (GitHub's Copilot reviewer reads it server-side)
   WHEN `github-copilot` is part of the committed `tools` selection (an omitted `tools` key — the default — selects all
   tools; a repo that excludes the tool keeps the file gitignored).
4. **Committed generated outputs** — `.github/workflows/skillshare-*.yml`, `.skillshare/README.md`, and (when
   `github-copilot` is committed-selected) `.github/copilot-instructions.md` — plus the sync-rewritten committed
   companions: the lockfile `.skillshare/manifest.json` and the `.gitattributes` managed block. Verify and commit
   all of them together.
5. **`package.json`** — the postinstall change; **`README.md`** — the pointer section.

The rendered instruction files and skill files are present on disk (regenerated per-machine) but gitignored — do not
expect them in `git diff` (exception: `.github/copilot-instructions.md`, which is committed and does appear when `github-copilot` is committed-selected). If a managed instruction file is missing expected content, adjust the relevant
`.skillshare/instructions/*.md` file or `repo.yml` and run `{{ runPrefix }} skillshare sync` again.

## Step 11: Clean up

After verifying the sync:

- Delete old hand-written instruction files that are now managed and gitignored (e.g. the original `CLAUDE.md` is
  replaced by the managed, gitignored version). Un-track any that were committed with `git rm --cached <file>`.
- Disable the onboarding skill: set `onboarding-skill: false` in `features:`, then run `{{ runPrefix }} skillshare sync`
  again.
- Verify with `{{ runPrefix }} skillshare check`.

## Important

- **Do NOT edit managed files directly** — they are overwritten on every `{{ runPrefix }} skillshare sync` and are
  gitignored.
- To customize: edit `.skillshare/repo.yml` (committed deviations), `.skillshare/user.yml` (personal deviations, this
  repo), `~/.skillshare/user.yml` (personal deviations, every repo), the `.skillshare/instructions/*.md` splice files,
  or the `.skillshare/openspec-rules/<artifact>.md` splice files.
- For personal **content** that should sync but never commit: drop it under `.skillshare/<type>/user/` (this repo) or
  `~/.skillshare/<type>/` (every repo) — enabled by presence, gitignored, invisible to `check --ci`.
- Run `{{ runPrefix }} skillshare check` to detect drift; `skillshare check --ci` verifies the committed surface.
