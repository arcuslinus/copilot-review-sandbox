---
name: skillshare-create-engineer
description: >
  Create a single coding engineer definition. Interactively scaffolds a
  .skillshare/engineers/<name>.md file by reading source code, identifying patterns,
  and generating a domain manual. Use when the user says "create engineer",
  "add an engineer", "new engineer", "scaffold engineer", or wants to add a specific
  coding engineer to the project. Requires the coding-engineers feature to be enabled.
---

Create a coding engineer definition for a specific domain.

**Input**: Optionally provide a name (e.g., `coding-backend-engineer`). If omitted, ask.

**Steps**

1. **Get the engineer name**

   If not provided, ask the user for:
   - The engineer name (suggest kebab-case with `-engineer` suffix)
   - The domain scope (which directories, packages, or layers)

   Validate:
   - Name is kebab-case (`/^[a-z0-9]+(-[a-z0-9]+)*$/`)
   - Name ends with `-engineer`
   - No existing engineer or skill has the same name

2. **Read source code to understand the domain**

   Based on the domain scope, read representative files to identify:
   - **Tech stack**: frameworks, libraries, runtimes in use
   - **Project structure**: directory layout and key files
   - **Coding patterns**: naming conventions, error handling, module structure
   - **Common operations**: what developers do most often in this domain
   - **Verification steps**: how to check code works (tests, typecheck, build)

   Read at least 3-5 representative source files to get a realistic picture.

3. **Generate the engineer definition**

   Write `.skillshare/engineers/<name>.md` with:

   **Frontmatter:**
   ```yaml
   ---
   description: >
     <One-line description of domain and trigger conditions.
      Include file patterns that trigger this engineer.>
   agent:
     tools:
       - Read
       - Edit
       - Write
       - Bash
       - Grep
       - Glob
       - "{% raw %}{% if flags.lspNavigation %}LSP{% else %}Glob{% endif %}{% endraw %}"
     instructions: |
       <2-3 line persona preamble. State the role and key behavioral rules.>
       {% raw %}{% include "references/lsp-navigation.md" %}{% endraw %}
   ---
   ```

   `tools`, `model`, and `instructions` have special semantics. Any other key inside the `agent:` block
   (e.g. `skills: [my-skill]`) passes through verbatim to agent-capable tools — not validated. Top-level
   frontmatter (`description`) stays closed. Omit `model`; the tier comes from `features.coding-engineers.settings.modelTier`.

   Keep both LSP snippets verbatim — they stay inert until the `lspNavigation` flag is on (contributed by the
   `ts7-lsp` feature). The tools entry renders `LSP` with the flag on and a duplicate `Glob` with it off, because
   frontmatter is YAML-parsed before rendering and the list line cannot be removed; the include renders to nothing
   when the flag is off or the target is not Claude.

   **Body (domain manual):**
   - `## Stack` — frameworks, libraries, runtime
   - `## Project structure` — directory tree with descriptions
   - `## Conventions` — naming, patterns, rules to follow
   - `## Adding a new <thing>` — step-by-step recipes for common operations (generate from existing code patterns)
   - `## Verification` — commands to run (typecheck, test, build)

   Make the content deep and specific — include real project structure trees, actual code examples from the repo, step-by-step recipes for common operations, and concrete verification commands.

When wording the definition, follow:

{% include "references/writing-instructions.md" ignore missing %}

4. **Show a summary to the user**

   Do NOT dump the full file content into the chat. Instead, present a concise summary:
   - Engineer name and description
   - Sections included (e.g., Stack, Project structure, Conventions, Recipes, Verification)
   - Key conventions captured (bullet list)
   - Recipes generated (list of "Adding a new X" sections)
   - Agent config (tools list)

   Ask for feedback — the user might want to add conventions, remove sections, or adjust scope.
   If they want to see a specific section in detail, show just that section on request.

5. **Write the file and sync**

   Write to `.skillshare/engineers/<name>.md` and run `{{ runPrefix }} skillshare sync`.
   Report which output files were generated per tool.

**Guardrails**
- Always read actual source code — never generate generic placeholder content
- Include real code examples from the repo, not made-up patterns
- Keep the domain manual focused and practical — step-by-step recipes are more valuable than abstract principles
- The description field must be specific enough for auto-triggering (mention file paths, package names)
- Show the draft to the user before writing — they know their codebase best
