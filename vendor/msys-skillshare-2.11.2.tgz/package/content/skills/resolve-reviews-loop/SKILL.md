---
name: resolve-reviews-loop
description: >
  Autonomous loop that resolves PR review comments until the PR is clean.
  Invokes resolve-reviews in auto mode, commits and pushes fixes, explicitly
  re-requests a Copilot review and awaits it, and repeats until no unresolved
  threads remain and the pull request's review requirement is satisfied — or
  hands the pull request to a human when the threads run out while the
  requirement does not. Use when
  the user says "resolve reviews loop", "keep resolving reviews",
  "auto-resolve reviews", "resolve reviews until clean", "fix reviews in a loop",
  "run resolve-reviews repeatedly", or wants to leave review resolution running
  unattended. Also triggers when the user wants continuous, fire-and-forget
  review triage across multiple push/review cycles on a PR.
license: MIT
compatibility: >
  Requires GitHub CLI (gh) >= 2.88.0 authenticated with repo access and the
  resolve-reviews skill. Re-requesting a bot reviewer (Copilot) via the GraphQL
  botIds field requires a personal access token with PR write scope; GitHub-App
  or org-app tokens may not surface this capability and the re-request will error.
metadata:
  author: meistersystems
  version: "1.6"
skillset:
  name: review
  when: >
    an open pull request exists for the change with unresolved review comments
  phase: work
  writes: true
  runsOn: main
---

# Resolve Reviews Loop

Autonomous loop: triage → fix → commit → push → re-request review → wait for re-review → repeat until clean.

**Invocation:**
- `/resolve-reviews-loop` — auto-detect PR from current branch
- `/resolve-reviews-loop <PR# | PR-URL>` — specify the PR; a full URL is unambiguous, a bare number resolves against the checkout's default repository

---

## Step 1: Setup

1. Verify `gh` CLI is available and authenticated (same checks as resolve-reviews).

2. Detect the current PR **and capture its URL in the same call** — the URL is what identifies the repository from here on, so it must come from the call that resolved the PR, not from a second lookup:
   ```bash
   # Auto-detect from the current branch (the unambiguous path):
   PR_JSON=$(gh pr view --json number,url,title,headRefName,baseRefName) || { echo "ERROR: no PR for this branch"; exit 1; }

   # Or, when an argument was given — a number, a full URL, or a branch name.
   # A full URL is the only form that is unambiguous across repositories:
   PR_JSON=$(gh pr view "<ARG>" --json number,url,title,headRefName,baseRefName) || { echo "ERROR: PR not found"; exit 1; }
   ```
   If no PR is found, error and exit.

   **A bare PR number is the one ambiguous input.** `gh pr view 123` resolves `123` against the checkout's default repository, so in a fork checkout it can select a *different* pull request that happens to share the number. Auto-detection from the branch does not have this problem, and neither does a full URL. `gh pr view` accepts only a number, a URL, or a branch name — there is no `owner/repo#N` form, and passing one is read as a branch name and fails — so a full URL is how a caller names a pull request in another repository. When a bare number is passed, say which pull request was resolved (`url`) before starting, so a wrong match is visible immediately rather than after the loop has pushed to it.

3. Derive the repository **from the URL captured in step 2** — never from `gh repo view`:
   ```bash
   PR_NUMBER=$(jq -r '.number' <<<"$PR_JSON")
   PR_URL=$(jq -r '.url' <<<"$PR_JSON")
   PR_BASE=$(jq -r '.baseRefName' <<<"$PR_JSON")   # starting value; each pass re-reads it
   [ -n "$PR_URL" ] && [ "$PR_URL" != "null" ] || { echo "ERROR: empty PR url"; exit 1; }

   PR_REST="${PR_URL#*://}"
   PR_HOST="${PR_REST%%/*}"                       # github.com ODER die GHE-Instanz
   PR_SLUG="${PR_REST#*/}"; PR_SLUG="${PR_SLUG%/pull/*}"   # owner/name
   OWNER="${PR_SLUG%%/*}"
   REPO="${PR_SLUG##*/}"
   BASE_REPO="https://$PR_HOST/$PR_SLUG.git"
   ```
   Host and path are taken **generically** from the URL, not by stripping a fixed `https://github.com/` prefix. On a GitHub Enterprise instance that fixed strip leaves the scheme and host inside the slug, so every API call names a nonsensical repository, and `BASE_REPO` would force the fetch onto `github.com` — a different repository, or none. `gh` itself follows the URL's host; the derivation must too.

   `gh repo view` returns the *checkout's* repository, which in a fork workflow is the contributor's fork — so `repos/{owner}/{repo}/pulls/{pr_number}/...` would query the fork, where the same number is an unrelated pull request or none at all, and `refs/pull/<N>/head` does not exist. The pull request's own URL names its base repository unambiguously, and **every** later step reuses it rather than re-deriving it: `--repo "$PR_HOST/$PR_SLUG"` on each `gh pr` call, `repos/$PR_SLUG/pulls/$PR_NUMBER/...` on each API call, `git fetch "$BASE_REPO"`, and `PR_URL` forwarded to `resolve-reviews` in Step 2a — which otherwise derives its own repository from the checkout.

4. **Verify the checkout belongs to this pull request** — before anything is read, changed, or pushed:
   The question is not "does this checkout know the repository" but **"would my `git push` land exactly on this pull request's head"**. That is narrower, and only the narrow question protects anything.

   ```bash
   PR_JSON=$(gh pr view "$PR_NUMBER" --repo "$PR_HOST/$PR_SLUG" \
     --json headRefName,headRefOid,headRepository) || { echo "ERROR: PR-Lookup fehlgeschlagen"; exit 1; }
   PR_HEAD_REF=$(jq -r '.headRefName'                  <<<"$PR_JSON")
   PR_HEAD_OID=$(jq -r '.headRefOid'                   <<<"$PR_JSON")
   PR_HEAD_REPO=$(jq -r '.headRepository.nameWithOwner' <<<"$PR_JSON")
   PR_HEAD_TARGET="$PR_HOST/$PR_HEAD_REPO"        # PR_HOST stammt aus Step 1

   # Remote URL -> "host/owner/repo", with the host resolved through the SSH
   # config. Scheme and scp forms are parsed SEPARATELY, see below the block.
   target_of() {
     u=$1; is_ssh=0
     case "$u" in
       ssh://*|git+ssh://*)          # ssh://user@host[:port]/owner/repo
         is_ssh=1
         rest=${u#*://}; rest=${rest#*@}
         hostport=${rest%%/*}
         host=${hostport%%:*}; port=${hostport#"$host"}; port=${port#:}
         path=${rest#*/} ;;
       *://*)                        # https://host[:port]/owner/repo - NOT SSH
         rest=${u#*://}; rest=${rest#*@}
         hostport=${rest%%/*}
         host=${hostport%%:*}; port=${hostport#"$host"}; port=${port#:}
         path=${rest#*/} ;;
       *:*)                          # user@host:owner/repo (scp, always SSH, never a port)
         is_ssh=1
         rest=${u#*@}
         host=${rest%%:*}; port=
         path=${rest#*:} ;;
       *) host=""; port=; path=$u ;; # local path
     esac
     path=${path%.git}; path=${path%/}
     # Alias resolution ONLY for SSH transports, see below the block.
     if [ "$is_ssh" = 1 ]; then
       # ONE lookup, on the alias AS WRITTEN, and both fields taken from it.
       # Resolving the hostname first and then asking the resolved name for the
       # port loses any Port the alias sets: `Host x / HostName github.com /
       # Port 2222` would be queried as `github.com`, answer 22, and normalise
       # to the default-port host - a different SSH service accepted as this one.
       ssh_cfg=$(ssh -G "$host" 2>/dev/null)
       real=$(awk '/^hostname /{print $2; exit}' <<<"$ssh_cfg")
       [ -z "$port" ] && port=$(awk '/^port /{print $2; exit}' <<<"$ssh_cfg")
       host=${real:-$host}
       [ "$port" = 22 ] && port=
     else
       [ "$port" = 443 ] && port=
     fi
     printf '%s%s/%s\n' "$host" "${port:+:$port}" "$path"
   }

   # (a) Where would `git push` actually go?
   PUSH_TARGET=$(git rev-parse --abbrev-ref --symbolic-full-name '@{push}') || {
     echo "STOP: this branch has no push target"; exit 1; }
   PUSH_REMOTE="${PUSH_TARGET%%/*}"
   PUSH_BRANCH="${PUSH_TARGET#*/}"

   # (b) EVERY push URL of this remote must be exactly the PR's HEAD repo.
   #     `--all`, because a remote may carry several push URLs and `git push`
   #     writes to each one; exact and WITH HOST, see below the block.
   PUSH_URLS=$(git remote get-url --push --all "$PUSH_REMOTE") || {
     echo "ERROR: could not read the push URLs"; exit 1; }
   [ -n "$PUSH_URLS" ] || { echo "ERROR: keine Push-URL fuer '$PUSH_REMOTE'"; exit 1; }
   while IFS= read -r url; do
     [ "$(target_of "$url")" = "$PR_HEAD_TARGET" ] || {
       echo "STOP: '$PUSH_REMOTE' pushes to '$url', the PR lives on '$PR_HEAD_TARGET'"; exit 1; }
   done <<<"$PUSH_URLS"

   [ "$PUSH_BRANCH" = "$PR_HEAD_REF" ] || {
     echo "STOP: push would go to '$PUSH_BRANCH', the PR is on '$PR_HEAD_REF'"; exit 1; }

   # (c) And the worktree must BE AT the PR's head - not merely know it. A
   #     previously fetched head of another PR stays in the object database
   #     while HEAD and the working files are something else entirely.
   HEAD_OID=$(git rev-parse HEAD) || { echo "ERROR: could not read HEAD"; exit 1; }
   [ "$HEAD_OID" = "$PR_HEAD_OID" ] || {
     echo "STOP: checkout is at $HEAD_OID, the PR is at $PR_HEAD_OID"; exit 1; }
   ```
   The selector and the working tree are two independent things: a full URL can name **any** pull request. Unchecked, the loop would triage that pull request's threads, apply the fixes to *this* worktree's files, and push them with an unscoped `git push` to *its* target.

   No single one of these conditions is sufficient, and the obvious shortcuts all look like protection without being it:

   - **`PR_SLUG` among the remotes** is not enough. That is the *base* repository, shared by every fork pull request — a normal fork checkout has it by construction.
   - **The branch name alone** is not enough. `headRefName` is not unique across forks; two contributors can carry the same branch name.
   - **A substring match on the push URL** is not enough. `owner/repo-backup.git` contains `owner/repo` and would pass as a hit. Hence normalise and compare for equality.
   - **`owner/repo` without the host** is not enough. `git@attacker.example:owner/repo.git` and `git@github.com:owner/repo.git` yield the same slug — the check would be satisfied while the push lands on a foreign server. The comparison is therefore `host/owner/repo`, the pull request's host coming from its own URL.
   - **Discarding the port** is not enough. `ssh://git@github.com:2222/owner/repo.git` would otherwise normalise to the same target as the regular SSH service — a different service on the same machine passing as identical. The port is part of the identity; only the default port (22 for SSH, 443 for HTTPS) is dropped, so that `ssh://host/…` and `ssh://host:22/…` stay equal.
   - **A heuristic on the colon** is not enough. Turning it into a slash by pattern, except when a digit follows, gets two valid forms wrong: `git@github.com:123owner/repo.git` is a legitimate scp path whose owner begins with a digit, and `ssh://git@github.com:22/owner/repo.git` carries a real port. Both would be rejected although they name the right repository. Hence `case` on `*://*` against `*:*`: in the scheme form a colon in the host is **always** a port, in the scp form **never**.
   - **The raw hostname**, conversely, is not enough either. An SSH alias such as `git@github-work:owner/repo.git` is a perfectly legitimate setup pointing at the same server; `ssh -G` resolves it through the SSH config before comparing. If that fails, the raw value is used — erring strict rather than lax.
   - **And the alias must be resolved in a single lookup.** Asking `ssh -G` for the hostname, overwriting the host with the answer, and then asking `ssh -G` again for the port queries the *resolved* name — which knows nothing of the alias's `Port`. `Host github-work / HostName github.com / Port 2222` would answer `22` on the second call, the port would be dropped as the default, and the URL would normalise to the same target as the regular SSH service. Verified with a temporary SSH config: the two-lookup form yields `github.com`, the single-lookup form `github.com:2222`.
   - **But alias resolution must apply to SSH transports only.** Applying it to every URL inverts the check: an SSH config entry `Host attacker.example` / `HostName github.com` would let `https://attacker.example/owner/repo.git` normalise to `github.com/owner/repo` and pass — while `git push` over HTTPS goes to `attacker.example` unchanged. The SSH config governs `ssh`, not HTTPS; a foreign URL would be laundered into an accepted one.
   - **A single push URL** is not enough. A remote may carry several and `git push` writes to each — checking the first and letting the second through is not protection.
   - **The mere presence of the head object** is not enough. `git cat-file -e` succeeds for any commit ever fetched; an earlier pull request's head stays in the object database while `HEAD` and the working files are something else. Hence equality with the checked-out `HEAD`, not presence.
   - Hence `@{push}`: that is literally where Step 2e will write, and it must match the pull request's repository *and* branch.

   On any failure: **stop and ask the user.** Do not check out or re-point remotes yourself — which branch sits in the working tree and where it pushes is their decision, not the loop's.

5. Fix the reviewer identity that every review query filters against:
   ```bash
   COPILOT_LOGINS='["copilot-pull-request-reviewer[bot]","github-copilot[bot]","copilot[bot]"]'
   ```
   The snippets below write `$COPILOT_LOGINS` for readability, but **substitute the list into the jq expression** when you run them — `gh api --jq` takes no `--arg`/`--argjson`, and passing one makes `gh` read the values as positional arguments and fail with `accepts 1 arg(s), received 4`. Inlined, the membership test reads `IN("copilot-pull-request-reviewer[bot]","github-copilot[bot]","copilot[bot]")`. The queries require `.user.type == "Bot"` **and** exact equality against this list.

   A substring test on `copilot` would be too broad: an account or app named `acme-copilot-helper` passes it, and a review from there on the pushed SHA would satisfy the wait or — with zero threads — pass the clean-exit check, although the requested GitHub Copilot review never arrived. This loop's entire coverage claim rests on **who** reviewed; the identity therefore has to be exact.

6. Extract the JIRA ticket ID from the current branch name for commit messages:
   ```bash
   git branch --show-current
   ```
   Parse the ticket ID prefix:
   - `aim-9-resolve-reviews-skill` → `AIM-9`
   - `meis-12179-some-feature` → `MEIS-12179`
   - Pattern: first segment(s) matching `<letters>-<digits>`, uppercased
   - If no ticket ID found → use `review-triage` as fallback

7. Initialize tracking state:
   - `iteration = 0`
   - `totalFixed = 0`
   - `totalIgnored = 0`
   - `fileHistory = {}` (maps file path → list of iteration numbers where it was modified)

Confirm with the user before starting: "This will automatically commit and push fixes each iteration. The user invoked this skill, so autonomous commits are expected. Starting the loop."

Report: "Starting resolve-reviews loop for PR #N (<title>). Ticket: <TICKET-ID>"

---

## Step 2: Iteration Loop

### Reading state: every read is guarded

This rule governs **every** `gh` read in the loop, and the steps below assume it rather than restating it. A `gh` command that fails still leaves the surrounding pipeline healthy — `awk`, `sort` and `tail` all succeed on empty input, and a failed `gh pr view` assigns an empty string — so an unguarded read is indistinguishable from a *meaningful* value: "no review covers this head", "no reviews exist", "cold start".

Each of those readings selects a branch that writes: fast-forwarding the checkout, overwriting `LAST_COPILOT_REVIEW_ID`, requesting a review, or terminating the loop. **A failed read must never select a branch.** So, for every read whose result feeds a decision:

- Put `set -o pipefail` on any pipeline whose first stage is `gh`.
- **A non-zero exit is always fatal** — report the error and exit the loop, per the same "do not retry silently" rule as the other error paths. Never fall through to a decision.
- **An empty result from a command that *succeeded* is a different thing**, and whether it is meaningful depends on the site:
  - Review queries: empty is a **defined value**. No review covers this head; no reviews exist yet (`0`, cold start); the requested review has not arrived. Act on it.
  - `gh pr view --json headRefOid` / `--json url`: empty is **not** a defined value. An open PR always has both, so an empty answer means something is wrong — treat it as a failure and abort.

The distinction is load-bearing in both directions: conflating them either aborts the loop on every never-reviewed head, or lets a broken read select a branch that writes.

For each iteration:

### 2a. Invoke resolve-reviews

Increment the iteration counter, then invoke the resolve-reviews skill in auto mode, forwarding the PR **URL**:

```
/resolve-reviews auto <PR_URL>
```

Use the Skill tool to invoke it with the **`PR_URL` captured in Step 1**, not the bare number. `resolve-reviews` resolves its argument itself, and a bare number would send it back to the checkout's repository — the fork, in a fork workflow — where it would triage a different pull request than the one this loop is pushing to. Capture its summary output.

### 2b. Check termination

If resolve-reviews reports "No unresolved review threads found", do **not** exit yet — run the **clean-exit check** (Step 2j). Zero unresolved threads is necessary but not sufficient: on a first iteration it can simply mean nobody has reviewed the branch at all.

### 2c. Parse results

From the resolve-reviews summary, extract:
- Number of threads fixed
- Number of threads ignored
- Files modified

Update running totals (`totalFixed`, `totalIgnored`).

### 2d. Track stagnation

For each file that was modified by fixes this iteration (from `git diff --name-only`), record it in `fileHistory`. If any file appears in 3 consecutive iterations, flag it:

> "Warning: `<file>` has been flagged in 3 consecutive iterations — possible ping-pong. Consider reviewing manually."

### 2e. Commit and push (if files changed)

Check for changes:
```bash
CHANGED=$(git status --porcelain) || { echo "ERROR: could not read the working tree state"; exit 1; }
```
Assigned and guarded, not run bare: if the command fails **after** fixes have been applied, its empty output would be indistinguishable from "no files changed" — the loop would skip the commit and push and carry on with exactly the conflation this section forbids.

If files were modified (`$CHANGED` non-empty):
1. Snapshot the latest Copilot review ID **before** the re-request in Step 2f (used in Step 2i to detect when Copilot has posted a new review after the request). Capturing it here — before commit, push, and the re-request — ensures any review the request produces is detected:
   ```bash
   set -o pipefail
   LAST_COPILOT_REVIEW_ID=$(gh api --hostname "$PR_HOST" --paginate "repos/$PR_SLUG/pulls/$PR_NUMBER/reviews" \
     --jq '.[] | select(.user.type == "Bot" and (.user.login | ascii_downcase | IN($COPILOT_LOGINS[]))) | .id' | sort -n | tail -1) || {
       echo "ERROR: reviews query failed"; exit 1; }
   LAST_COPILOT_REVIEW_ID=${LAST_COPILOT_REVIEW_ID:-0}
   ```
   The default is its own line, not merely a promise in the prose: without it the variable stays empty on a pull request with no Copilot reviews, and neither the `== 0` branch in Step 2f nor the numeric comparison in the poll would ever receive the promised cold-start value.

   The guard matters especially here: an unguarded failure yields the empty string, which defaults to `0` and is indistinguishable from **cold start**. On a PR that already has reviews, Step 2f would then take the `--add-reviewer` branch, which no-ops, and the wait would time out having requested nothing.
   `--paginate` is required so all pages of reviews are fetched — GitHub returns reviews oldest-first, so the newest id is on the last page. `gh`'s built-in `--jq` runs per page, so it emits the matching review ids across **all** pages; `sort -n | tail -1` then reduces them to the single global maximum. Do **not** combine `--slurp` with `--jq` — `gh` rejects that pairing (`the --slurp option is not supported with --jq or --template`) — and a non-paginated fetch would see only the first 30 (oldest) reviews and miss the newest id, leaving the Step 2i poll unable to detect the re-review. Das Ergebnis liegt als `LAST_COPILOT_REVIEW_ID` vor, per Zeile oben auf `0` vorbelegt. If no Copilot reviews exist yet, this is `0` — this value also discriminates cold start vs re-trigger in Step 2f.
2. Stage the changed files (specific files, not `git add -A`)
3. Commit:
   ```bash
   git commit -m "(<TICKET>) resolve review feedback — iteration N"
   ```
4. Push — **exactly one push per iteration**, containing all of that round's fixes:
   ```bash
   git push
   ```
   Never push intermediate commits individually, and do not push until every fix of the round is committed. Every push to a PR branch triggers a full Copilot re-review and consumes review quota, so per-commit pushes multiply review rounds without adding information.
5. Capture the SHA this iteration pushed, immediately after the push succeeds:
   ```bash
   PUSHED_SHA=$(git rev-parse HEAD) || { echo "ERROR: could not read HEAD after the push"; exit 1; }
   [ -n "$PUSHED_SHA" ] || { echo "ERROR: empty HEAD after the push"; exit 1; }
   ```
   The guard is especially expensive to lose here: an empty `PUSHED_SHA` makes the poll's `awk` filter match nothing, and the wait runs its full 30 minutes into the timeout instead of reporting the read failure at once.

   Retain it as the shell variable `PUSHED_SHA`, alongside `LAST_COPILOT_REVIEW_ID`. **Every name in this skill is the shell variable the commands actually read** — the poll filters on `$PUSHED_SHA` and the re-request branches on `$LAST_COPILOT_REVIEW_ID`, so a step that sets some other spelling sets nothing at all. Step 2i runs in the background and MUST compare against this retained value — re-reading `git rev-parse HEAD` inside the poll would follow any local commit made while the monitor is running, after which the requested review can never match and the loop times out.

If no files changed (only IGNORE items resolved), skip commit/push.

### 2f. Re-request a Copilot review

**Skip this step if no commit/push was made in step 2e** (e.g., IGNORE-only iterations) — there is no new push to re-review, so proceed directly to Step 2g. **Exception:** when Step 2j sends you here for an uncovered head, re-request unconditionally. That path has no Step 2e push by definition, and the missing review is the reason it is asking.

Copilot does not reliably re-review on its own after a push, so the loop explicitly requests a fresh review. Use the `LAST_COPILOT_REVIEW_ID` snapshot from Step 2e to pick the mechanism:

**Cold start** (`LAST_COPILOT_REVIEW_ID == 0` — Copilot is not yet a reviewer). Add Copilot as a reviewer; this is idempotent and triggers the first review:
```bash
gh pr edit "$PR_NUMBER" --repo "$PR_HOST/$PR_SLUG" --add-reviewer "@copilot"
```

**Re-trigger** (`LAST_COPILOT_REVIEW_ID > 0` — Copilot has already submitted a review, so `--add-reviewer` would no-op). Issue the GraphQL `requestReviews` mutation with `botIds`, which re-requests even after the bot has already reviewed. Resolve both node ids dynamically — **do not hardcode the bot node id**:

1. Get the PR node id:
   ```bash
   PR_NODE_ID=$(gh pr view "$PR_NUMBER" --repo "$PR_HOST/$PR_SLUG" --json id --jq '.id') || { echo "ERROR: could not read the PR node id"; exit 1; }
   [ -n "$PR_NODE_ID" ] || { echo "ERROR: empty PR node id"; exit 1; }
   ```
2. Resolve the Copilot bot node id dynamically. This branch only runs when `LAST_COPILOT_REVIEW_ID > 0`, so a Copilot review already exists — its author node id **is** the Copilot reviewer bot's GraphQL id and can be passed straight to `botIds`. The REST reviews endpoint exposes it as `user.node_id`:
   ```bash
   set -o pipefail
   COPILOT_BOT_NODE_ID=$(gh api --hostname "$PR_HOST" --paginate "repos/$PR_SLUG/pulls/$PR_NUMBER/reviews" \
     --jq '.[] | select(.user.type == "Bot" and (.user.login | ascii_downcase | IN($COPILOT_LOGINS[]))) | "\(.id) \(.user.node_id)"' \
     | sort -n | tail -1 | cut -d' ' -f2) || {
       echo "ERROR: reviews query failed"; exit 1; }
   ```
   `--paginate` with a per-review emission and a global `sort -n | tail -1`, exactly like the Step 2e snapshot — and for the same reason. A single-page lookup with `max_by` reduces only the first 30 reviews, so on a PR whose Copilot reviews begin after that point it succeeds with an empty result and the loop wrongly reports that Copilot review is unavailable. That matters here precisely because this branch only runs when `LAST_COPILOT_REVIEW_ID > 0`, a value derived from *all* pages.

   The guard distinguishes the two empty results the read-guard rule separates: a **failed** query aborts, while a **successful** query returning empty means Copilot review is not enabled here — which is the re-request failure handled below.
   Derive the id from the existing review rather than a login lookup: GitHub's GraphQL has no `bot(login:)` query and `user(login:)` does not resolve bot accounts, so a login-based lookup would return nothing. If `COPILOT_BOT_NODE_ID` comes back empty (Copilot review not enabled for this repo/account), treat it as a re-request failure (see below).
3. Issue the mutation:
   ```bash
   gh api --hostname "$PR_HOST" graphql -f query='
     mutation($prId: ID!, $botId: ID!) {
       requestReviews(input: { pullRequestId: $prId, botIds: [$botId] }) {
         pullRequest { id }
       }
     }' -f prId="$PR_NODE_ID" -f botId="$COPILOT_BOT_NODE_ID"
   ```

**On re-request failure** (any of the above errors — e.g. HTTP 403/422, an empty bot node id, or PR review disabled): report the error and **exit the loop**. Do not retry silently and do not advance to the next iteration. Note the likely cause in the message:

> "Re-request of Copilot review failed (HTTP `<status>`). Re-requesting a bot reviewer via `botIds` requires a `gh` auth token with PR write scope — a personal access token. GitHub-App or org-app tokens may not surface this capability. Check the PR manually."

This matches the skill's existing "do not retry silently" edge cases (push fails, resolve-reviews fails).

### 2g. Notify user

Output a progress notification:

```
Iteration N done: X fixed, Y ignored. Pushed, re-requested review, waiting for re-review...
```

Or if no push was needed:

```
Iteration N done: 0 fixed, Y ignored (no code changes). No re-request needed — proceeding to next iteration.
```

### 2h. Checkpoint (every 5th iteration)

At iterations 5, 10, 15, etc., pause and use the **AskUserQuestion tool**:

| Option | Description |
|--------|-------------|
| **Continue for 5 more iterations** (default) | Resume the loop, next checkpoint at iteration N+5 |
| Stop here | Output final summary and exit |
| Let me review manually | Output final summary and exit |

If the user chooses to stop, go to Step 3.

### 2i. Wait for the requested review to be posted (non-blocking)

**Skip this step if no commit/push was made in step 2e** (e.g., IGNORE-only iterations) — there was no re-request, so proceed directly to the next iteration. **Exception:** when Step 2j sends you here for an uncovered head, wait unconditionally. That path re-requested a review without a push, and skipping the wait would run the next iteration before the review it just asked for arrives.

**This step MUST run in the background.** Launch a single background process that polls every 30 seconds and emits a line to stdout when the review arrives or when an error/timeout occurs. Do NOT write a synchronous `while`/`until` loop in the foreground — that blocks the agent from responding to user input for up to 30 minutes.

Because the re-request in Step 2f guarantees a review was asked for, the only meaningful wait is "has the requested review been posted?". Poll for a new Copilot review id under a single 30-minute timeout from the time of the re-request.

- **Query to run each poll cycle** (paginated, restricted to `PUSHED_SHA` **before** the reducer):
  ```bash
  set -o pipefail
  gh api --hostname "$PR_HOST" --paginate "repos/$PR_SLUG/pulls/$PR_NUMBER/reviews" \
    --jq '.[] | select(.user.type == "Bot" and (.user.login | ascii_downcase | IN($COPILOT_LOGINS[]))) | "\(.id) \(.commit_id)"' \
    | awk -v sha="$PUSHED_SHA" '$2 == sha { print $1 }' | sort -n | tail -1
  ```
  `pipefail` is required for the "API error" rule below to be implementable at all: `awk`, `sort` and `tail` all succeed on empty input, so without it a failed `gh api` is silently indistinguishable from "the review has not arrived yet" and the poll waits out its full 30 minutes instead of reporting the error.
  The `awk` filter is load-bearing and MUST come before `sort -n | tail -1`. Reviews do not complete in request order: a valid review of `PUSHED_SHA` can be followed by a higher-id review of an older commit that was still in flight. Reducing to the global maximum first would let that later review mask the valid one on every poll cycle, and the loop would time out despite having the coverage it asked for. Filtering first makes the result "the newest Copilot review **that covers the pushed SHA**", which cannot be masked. `--paginate` with `gh`'s built-in `--jq` emits one line per matching review across all pages; without it the newest reviews on the last page would be invisible. Do **not** add `--slurp` — `gh` rejects `--slurp` together with `--jq`. An empty result defaults to `0`.
- **Done when:** the result > `LAST_COPILOT_REVIEW_ID` (captured in Step 2e before the re-request) — by construction it already covers `PUSHED_SHA`
- **Keep waiting when:** the result is `0` or == `LAST_COPILOT_REVIEW_ID`. Reviews for other commits never advance this value, however new or numerous they are.

The `commit_id` condition is what keeps the loop from declaring a PR clean over unreviewed code. A review is evidence about exactly the SHA it names; treating "some newer review exists" as coverage means the loop can report a PR clean over code no reviewer has looked at.

When done, the background process should emit a line like:
`REVIEW_POSTED: New Copilot review detected (id: <new_id>, commit: <short_sha>)`

Then hand the result to the **clean-exit check** (Step 2j) — **both outcomes, not just the clean one**. The gate re-reads the threads itself, so nothing is lost by deferring, and routing only the zero-thread result there would leave the findings path unsynchronized: if this iteration pushed A, someone else pushed B during the wait, and the requested review of A arrives with findings, jumping straight to Step 2a would triage A's findings against a checkout still on A while the PR is on B — stale files, and a push that is then rejected as non-fast-forward.

#### Timeout and errors

The background process must also emit on failure so the agent is notified:
- **Timeout**: If no new Copilot review appears within 30 minutes of the re-request, emit `TIMEOUT: 30 minutes elapsed` and exit. The agent should then go to Step 3 with a warning.
- **API error**: If a query fails (network error, auth failure, rate limit), emit `ERROR: <details>` and exit. The agent should report the error and go to Step 3. Do not retry silently.

---

### 2j. Clean-exit check

**Every** path out of the triage reaches this check — the Step 2b early exit and **both** outcomes of the Step 2i wait, findings or not. Step 2i no longer decides anything itself. A single gate is deliberate: the loop has several ways to conclude "nothing more to do here", and each one on its own can be true of a commit nobody has reviewed, or true of a commit the branch has since moved off.

Zero unresolved threads means the *reviewed commit* is clean, not that the *branch* is. Two ways that diverge:

- **Nobody reviewed the branch yet.** A first iteration, or the iteration after an IGNORE-only round, can legitimately find zero threads because no review has been produced at all.
- **The branch moved.** The Step 2i wait runs in the background, so another worktree, another agent, or a teammate can push while it is in progress. A late review of `PUSHED_SHA` then satisfies the wait legitimately, while the PR already points at a newer commit.

Run the check as a **retry loop over passes**. **You** carry out the control flow, not a shell loop — the steps below are instructions with embedded commands, not a script. Keep two values for it:

| State | Meaning |
|---|---|
| `RESTARTS` | how many passes restarted in a row, initially `0` |
| `CAUSE` | the reason for the last restart (`fetch-failed`, `remote-moved`) |

And apply these three rules:

- **Restart** — a step reports `RESTART: <cause>`: record `CAUSE`, increment `RESTARTS`, begin the pass again from step 1. Both signals leave their block with `exit 1`, so that a failed fetch is not followed by a merge anyway; they are told apart by the message, not by the exit status.
- **Abandon** — `RESTARTS` reaches 3: go to Step 3 with a warning, reporting `ABANDON: <CAUSE>, three times in a row`.
- **Stop** — a step reports `STOP: <cause>`: end the loop and ask the user.

Earlier attempts to present this as executable shell failed three times — with undefined helpers, with `continue` outside any loop, with a body of comments that spins forever. The reason is structural: the five steps are prose with embedded commands and do not fold into a function body. The **individual commands** below are and remain executable; the control flow around them is not, and no longer pretends to be.


Every fact the check uses is stale the moment it is read, so a pass snapshots the branch state, synchronizes to it, evaluates, and then confirms nothing moved underneath. Any observed change restarts the pass. Abandon after 3 consecutive restarts and go to Step 3 with a warning — but **record why each restart happened and report that cause**, because the two are not the same situation: repeated `remote-moved` restarts mean the branch is being pushed to faster than the check can observe it, while repeated `fetch-failed` restarts mean the network or the remote is unhealthy. Reporting churn for what were actually three failed fetches sends the reader looking in the wrong place.

**Each pass:**

1. **Snapshot the branch state.**
   ```bash
   HEAD_AND_BASE=$(gh pr view "$PR_NUMBER" --repo "$PR_HOST/$PR_SLUG" \
     --json headRefOid,baseRefName --jq '"\(.headRefOid) \(.baseRefName)"') || {
       echo "ERROR: could not read the PR head"; exit 1; }
   REMOTE_HEAD="${HEAD_AND_BASE%% *}"
   REMOTE_BASE="${HEAD_AND_BASE#* }"
   [ -n "$REMOTE_HEAD" ] && [ -n "$REMOTE_BASE" ] || { echo "ERROR: empty PR head or base"; exit 1; }

   set -o pipefail
   REVIEW_STATE=$(gh api --hostname "$PR_HOST" --paginate "repos/$PR_SLUG/pulls/$PR_NUMBER/reviews" \
     --jq '.[].id' | sort -n | tail -1) || {
       echo "ERROR: reviews query failed"; exit 1; }
   REVIEW_STATE=${REVIEW_STATE:-0}

   COPILOT_STATE=$(gh api --hostname "$PR_HOST" --paginate "repos/$PR_SLUG/pulls/$PR_NUMBER/reviews" \
     --jq '.[] | select(.user.type == "Bot" and (.user.login | ascii_downcase | IN($COPILOT_LOGINS[]))) | .id' | sort -n | tail -1) || {
       echo "ERROR: reviews query failed"; exit 1; }
   COPILOT_STATE=${COPILOT_STATE:-0}
   ```
   Two fingerprints, because they answer different questions.

   `REVIEW_STATE` is the newest review id across **every author**, and it is what step 4 confirms. It is deliberately *not* filtered by SHA — a review of a *superseded* commit still adds unresolved threads while leaving the head unchanged — and deliberately *not* filtered by author either: the unresolved-thread fetch counts threads from every reviewer, so a **human** review landing after the evaluation would add threads that a Copilot-only fingerprint cannot see, and the pass would exit on a count taken before they existed.

   `COPILOT_STATE` is the Copilot-only equivalent, used solely as the `LAST_COPILOT_REVIEW_ID` handed to the re-request in step 5. That decision is about Copilot's own review history and must not be perturbed by other reviewers.

2. **Synchronize the checkout — before evaluating anything, and regardless of coverage.**
   ```bash
   # BASE_REPO and PR_SLUG come from Step 1, resolved from the PR's own URL.
   # Re-deriving them here with a bare `gh pr view` would reintroduce the fork
   # ambiguity that resolution exists to remove.

   # Dirty tree: stop and ask. Checked BEFORE the merge, because --ff-only
   # succeeds when local changes happen not to overlap the incoming commits.
   # Assigned rather than embedded in [ -z "$(...)" ]: there the empty output
   # of a FAILED command is indistinguishable from "tree is clean", and the
   # check would merge without ever having established that.
   DIRTY=$(git status --porcelain) || { echo "ERROR: could not read the working tree state"; exit 1; }
   [ -z "$DIRTY" ] || { echo "STOP: working tree is dirty"; exit 1; }

   git fetch "$BASE_REPO" "pull/$PR_NUMBER/head" || {
     echo "RESTART: fetch-failed"; exit 1; }
   git merge --ff-only FETCH_HEAD || {
     echo "STOP: cannot fast-forward - the branch has diverged"; exit 1; }

   LOCAL_HEAD=$(git rev-parse HEAD) || {
     echo "ERROR: could not read local HEAD"; exit 1; }
   if [ "$LOCAL_HEAD" != "$REMOTE_HEAD" ]; then
     # Two very different causes. Ask the remote which one it is.
     NOW=$(gh pr view "$PR_NUMBER" --repo "$PR_HOST/$PR_SLUG" --json headRefOid --jq '.headRefOid') || {
       echo "ERROR: could not re-read the PR head"; exit 1; }
     # Empty is fatal here, not "moved": treating it as movement would retry and
     # eventually blame branch churn for an invalid read.
     [ -n "$NOW" ] || { echo "ERROR: empty PR head on re-read"; exit 1; }
     if [ "$NOW" != "$REMOTE_HEAD" ]; then
       echo "RESTART: remote-moved"; exit 1
     else
       echo "STOP: local HEAD is ahead of a stable PR head - unpublished local commits"; exit 1
     fi
   fi
   ```
   Four things about this block are deliberate.

   **It is unconditional.** Earlier revisions synchronized only on the not-covered path, which left the "threads remain" branch handing Step 2a a stale checkout: a concurrently pushed head can *already* carry a Copilot review with findings, so the covered path is reached with the working tree still on the old commit and the fixes would target stale files.

   **The failures get different answers**, and collapsing them is wrong in every direction. A failed `git fetch` is transient — **restart the pass**. A merge that cannot fast-forward means the branch has diverged, which is someone else's work — **stop and ask the user**, never reset, rebase, or force.

   A SHA mismatch after a *successful* merge is the subtle one, because it has two causes needing opposite treatment. If the remote head has advanced since step 1, that is ordinary drift — **restart the pass**. But if the remote head is unchanged, the mismatch means local `HEAD` is **ahead** of it: unpublished commits, which `--ff-only` reports as *already up to date*. Retrying cannot change that, so every remaining pass hits the identical mismatch, the loop exhausts its bound, and it blames branch churn that never happened. That case is **stop and ask** — there is local work to preserve. Re-reading the remote head is what tells the two apart.

   **Every command is guarded on its own, so failures short-circuit** — `git rev-parse` included. In `[ "$(git rev-parse HEAD)" != … ]` the test swallows the substitution's failure: the empty value is unequal to `$REMOTE_HEAD`, the code falls into the mismatch branch, and it ends up reporting "local HEAD is ahead" for a read that never happened. Hence assign first, then compare. A failed `git fetch` leaves `FETCH_HEAD` absent or stale for the merge, and a plain `git rev-parse HEAD` afterwards succeeds regardless — so an unguarded sequence reads as a healthy block. The SHA equality is an executable condition, not a comment to eyeball.

   **The SHA comparison is not redundant.** `git merge --ff-only <ancestor>` reports success as *already up to date* when local `HEAD` is ahead, and the remote can advance between step 1 and this fetch — in both cases the merge succeeds while the checkout sits at a different commit than the one snapshotted.

   The fetch target is `BASE_REPO` from Step 1 — the pull request's **base** repository, resolved from the PR's own URL. `refs/pull/<N>/head` lives there, while in a fork workflow `origin` is commonly the contributor's fork, where the ref is absent or, worse, is a same-numbered pull request of the fork that would be fetched and merged before the SHA comparison caught it. It is likewise not `origin/$(git branch --show-current)`, which assumes the local branch name is also a ref on `origin`.

3. **Evaluate**, now against a checkout that matches `REMOTE_HEAD`:
   - unresolved threads, via the **fully paginated** GraphQL fetch from resolve-reviews Step 2 (all pages accumulated before filtering `isResolved: false`). Keep the **sorted list of unresolved thread ids** as `THREAD_STATE`, not just the count — step 4 confirms it;
   - coverage — is there a Copilot review whose `commit_id` equals `REMOTE_HEAD`?
     ```bash
     set -o pipefail
     COVERED=$(gh api --hostname "$PR_HOST" --paginate "repos/$PR_SLUG/pulls/$PR_NUMBER/reviews" \
       --jq '.[] | select(.user.type == "Bot" and (.user.login | ascii_downcase | IN($COPILOT_LOGINS[]))) | "\(.id) \(.commit_id)"' \
       | awk -v sha="$REMOTE_HEAD" '$2 == sha { print $1 }' | sort -n | tail -1) || {
         echo "ERROR: reviews query failed"; exit 1; }
     ```
     An empty `COVERED` from a *successful* query means exactly what it says: nothing has reviewed this head.

     Only the **id** is kept. The covering review's *state* is deliberately not snapshotted here: it drives no branch — the decision runs on `REVIEW_DECISION` and `APPROVALS_REQUIRED` — and it is read fresh where it is actually used, in the not-approved summary. Snapshotting it would mean either carrying a value that can go stale unnoticed, or confirming a seventh value that decides nothing. `dismissPullRequestReview` makes the staleness concrete: it can flip the covering review from `APPROVED` to `DISMISSED` while a *different* missing approval keeps `REVIEW_DECISION` at `REVIEW_REQUIRED`, so every confirmed value holds and a snapshot taken earlier would have the summary announce an approval that no longer exists.
   - whether the pull request's review requirement is satisfied, and **whether one exists at all**:
     ```bash
     REVIEW_DECISION=$(gh pr view "$PR_NUMBER" --repo "$PR_HOST/$PR_SLUG" \
       --json reviewDecision --jq '.reviewDecision // ""') || {
         echo "ERROR: could not read the review decision"; exit 1; }

     # REMOTE_BASE, not the setup value: a pull request can be retargeted while
     # this loop runs, and rules read for the old base would answer for a branch
     # the pull request no longer merges into.
     #
     # The branch goes into a path segment, so it MUST be encoded: a base such
     # as `release/2026` otherwise adds a segment and the request resolves to a
     # DIFFERENT, non-existent branch — which answers `[]`, indistinguishable
     # from "this branch has no rules". It does not fail; it lies quietly.
     PR_BASE_ENC=$(jq -rn --arg s "$REMOTE_BASE" '$s|@uri') || {
       echo "ERROR: could not encode the base branch"; exit 1; }

     # --paginate, and reduced in the shell rather than in jq: with --paginate
     # `gh` runs the filter PER PAGE, so a jq-side `| any` would emit one
     # verdict per page and `false` from page 1 could mask `true` from page 2.
     set -o pipefail
     APPROVAL_FLAGS=$(gh api --hostname "$PR_HOST" --paginate \
       "repos/$PR_SLUG/rules/branches/$PR_BASE_ENC" \
       --jq '.[] | select(.type == "pull_request") | .parameters
             | (.required_approving_review_count // 0) > 0
               or (.require_code_owner_review // false)
               or (.require_last_push_approval // false)
               or ((.required_reviewers // []) | map((.minimum_approvals // 0) > 0) | any)') || {
         echo "ERROR: could not read the branch rules"; exit 1; }
     APPROVALS_REQUIRED=false
     # `if`, not `&&`: on the ordinary ungated path grep finds nothing and exits
     # 1, and as the block's last command that becomes the block's status — which
     # the read-guard rule above would treat as a failed read and abort on. The
     # absence of a `true` line is data, not an error.
     if grep -qx true <<<"$APPROVAL_FLAGS"; then APPROVALS_REQUIRED=true; fi
     ```
     `reviewDecision` is GitHub's own answer to "do the approvals this pull request has satisfy the rules that apply to it", so it stays correct whatever a repository requires — a fixed approval count, a required reviewer, or nothing at all. Reading it rather than inferring the answer from `COVERED_STATE` matters in both directions: a repository may not gate on approvals at all, and an approval may come from a human while Copilot's covering review is only a comment.

     **An empty `reviewDecision` is not a statement that no approval is required.** GitHub returns null for a draft pull request, whose requirement is simply not evaluated yet — and Copilot reviews drafts, so a covered, threadless draft on an approval-gated branch would otherwise walk straight into the clean exit. Empty values have also been observed on **non-draft** pull requests whose base branch demonstrably required an approval (`msys-skillshare#209`, `#210`, `#211` on 2026-08-30, all with `required_approving_review_count: 1` in effect and one of them carrying an `APPROVED` review), so an empty value cannot be read as "the rule does not exist".

     `APPROVALS_REQUIRED` answers that second question separately and deterministically. It is the **effective** rule for the base branch — it reflects a ruleset change immediately, and it is `false` for a branch that carries no rules at all. Step 5 uses the two together: `reviewDecision` decides whenever it says anything, and `APPROVALS_REQUIRED` decides whether an empty decision may be treated as satisfied.

     **What this signal does not cover:** `rules/branches` returns **ruleset** rules — repository and organization alike, but not classic branch protection, which is a separate surface (`branches/{branch}/protection`, verified: a branch protected only by rulesets answers *Branch not protected* there). A repository that requires reviews through classic protection therefore leaves this signal `false`. That gap is deliberately not closed here: the classic endpoint is **admin-only**, so on an ordinary contributor's token every pass would 403, and the one field a non-admin can read (`branches/{branch}.protected`) is `true` for *any* protection — including rulesets that require no approval at all — so using it would turn legitimate clean exits into handovers for those repositories. `reviewDecision` remains the primary signal and does reflect classic protection; this fallback exists for the case where that field says nothing.

     It is a **boolean over every approval-bearing parameter**, not the numeric count alone. A rule may carry `require_code_owner_review: true` or a `required_reviewers` list while `required_approving_review_count` is `0`; reading only the count reports "nothing required" and hands the empty decision the clean exit for a branch that does demand an approval. `require_last_push_approval` is included on the same principle even though on its own, with a zero count, it likely gates nothing — the two failure directions are not symmetric, and an unnecessary handover costs a person one look while the opposite costs the guarantee.

     `required_reviewers` is the one place where the conservative reading would be **wrong rather than merely noisy**, so it is read by content and not by length. Each entry carries its own `minimum_approvals`, and GitHub documents `0` as "the team will be added to the pull request but approval is optional" — a team listed for visibility, gating nothing. Counting such an entry would force a handover on a configuration that requires no approval at all, every time. The signal therefore asks whether **any** entry sets `minimum_approvals` above zero.

     What it deliberately does **not** do is evaluate each entry's `file_patterns` against the pull request's changed files. A requirement scoped to paths this pull request does not touch does not apply to it, so the signal is over-inclusive there — on purpose. Deciding it correctly means running fnmatch with negation semantics over the changed file list, which is GitHub's own evaluation reimplemented inside a skill: the thing D1 rejected, and its failure mode is silent and path-dependent. Over-inclusive here costs a handover; getting the pattern semantics subtly wrong costs the guarantee.

4. **Confirm nothing moved.** Re-read `REMOTE_HEAD`, `REMOTE_BASE`, `REVIEW_STATE`, `REVIEW_DECISION` and `APPROVALS_REQUIRED` exactly as in steps 1 and 3, **and re-fetch `THREAD_STATE`**. If any of the six differs, everything observed in step 3 predates the change — **restart the pass**.

   The thread state has to be confirmed directly, not inferred from the review id. GitHub's `unresolveReviewThread` mutation reopens an existing thread **without creating a review**, so a thread reopened between step 3 and the decision leaves `REMOTE_HEAD` and `REVIEW_STATE` both untouched while the zero count it produced is already wrong. The decision is about threads, so the fingerprint is the threads.

   `REMOTE_BASE` is confirmed because retargeting a pull request changes which branch's rules apply without touching the head, any review, or any thread. A pass that read an ungated base and decides against a gated one would grant the clean exit the new base forbids.

   `REVIEW_DECISION` is confirmed for the same reason, and it is the same shape of mutation: `dismissPullRequestReview` flips an existing approval to `DISMISSED` **without creating a review**, so a dismissal between step 3 and the decision moves the decision from `APPROVED` to `REVIEW_REQUIRED` while leaving the head, the newest review id and the thread set all untouched. Every other fingerprint stays stable and a stale `APPROVED` would take the clean-exit branch. The direction matters: a decision that improves mid-pass only costs a restart, but one that degrades produces a pull request reported clean that does not merge.

5. **Decide.** The branches are ordered and mutually exclusive; **coverage is checked first**. When the head is uncovered *and* threads remain, both of the later conditions would otherwise apply — and taking the thread branch would fix the old findings, push, and produce a second unreviewed head, compounding the very gap this gate exists to close. Ask for the review first; those findings get triaged next round together with whatever the review adds.
   - **`COVERED` empty** → the branch carries code no reviewer has seen, **regardless of the thread count**. In this order:
     1. **Count the round first — but only if this round has not been counted already.** On entering the check, remember where you came from:
        - **via Step 2b** (straight from the triage): Step 2a has already counted this round. **Do not count again** — otherwise a never-reviewed, clean branch jumps from iteration 1 to 2 before it has requested any review at all, and both the checkpoint and the reported totals sit a round off.
        - **via Step 2i** (returning from the wait): this round ran without Step 2a, so it counts here. Increment the iteration counter and run the Step 2h checkpoint if one is due, *before* transferring control anywhere — after the return to the wait the counting would never happen, and a branch someone keeps pushing to would spin invisibly instead of reaching the checkpoint.
     2. Assign the two shell variables the downstream steps read — `LAST_COPILOT_REVIEW_ID=$COPILOT_STATE` (the Copilot-only fingerprint, not `REVIEW_STATE`) and `PUSHED_SHA=$REMOTE_HEAD`. These are the exact names Step 2f branches on and the Step 2i poll filters with; on the first-iteration and IGNORE-only paths Step 2e never ran, so `PUSHED_SHA` is unset until this line and an empty filter would match no review at all, timing the wait out. The refreshed snapshot matters: reusing a stale one leaves it at `0` after a cold start, so Step 2f would take the `--add-reviewer` branch, which no-ops once Copilot is already a reviewer, and the next wait would time out with no review ever requested.
     3. Re-request a Copilot review (Step 2f). **This path re-requests unconditionally** — Step 2f's "skip if no commit/push was made in Step 2e" guard does not apply here. The first-iteration and externally-pushed cases have no Step 2e push by definition, and an unreviewed head is precisely the reason to ask.
     4. Return to the wait (Step 2i), **also unconditionally**, overriding Step 2i's identical guard. The return from there enters the check via Step 2i, so the next round is counted under rule 1. Skipping the wait would run the next iteration against the un-reviewed state immediately after asking for the review, which is the behaviour this gate exists to prevent.
   - **`COVERED` non-empty and threads remain** → proceed to the next iteration (Step 2a). The checkout is already correct, because step 2 ran unconditionally.
   - **`COVERED` non-empty, zero threads, and the requirement satisfied** → the PR is clean. Go to Step 3 (exit). The requirement counts as satisfied when `REVIEW_DECISION` is `APPROVED`, or when it is **empty and `APPROVALS_REQUIRED` is `false`** — an empty decision on a branch that requires nothing is the ordinary case for repositories that do not gate on approvals, and their behaviour is unchanged.
   - **`COVERED` non-empty, zero threads, and the requirement not satisfied** — `REVIEW_DECISION` is anything other than `APPROVED`, **or** it is empty while `APPROVALS_REQUIRED` is `true` → every finding the loop can act on is resolved, yet the pull request still is not approved. Go to Step 3 (exit) with the **not-approved** summary, naming `REVIEW_DECISION`, `COVERED_STATE`, and the covering review's verdict line:
     ```bash
     COVERING_NOW=$(gh api --hostname "$PR_HOST" \
       "repos/$PR_SLUG/pulls/$PR_NUMBER/reviews/$COVERED" \
       --jq '"\(.state) \(.body | split("\n")[0])"') || {
         echo "ERROR: could not read the covering review"; exit 1; }
     COVERED_STATE="${COVERING_NOW%% *}"    # APPROVED | COMMENTED | CHANGES_REQUESTED | DISMISSED
     VERDICT_LINE="${COVERING_NOW#* }"
     ```
     One call, both fields, read at the moment the summary is rendered — so neither can describe a review state that has since changed. Guarded like every other read: an unguarded failure here reaches Step 3 without the state and verdict line the summary promises, and the handover then names neither what Copilot concluded nor why.

     Do **not** iterate here, and do not report the PR as clean. Iterating cannot help: the loop acts on review *threads*, and there are none left, so the next round would triage nothing, land back on this branch, and spin. Reporting it clean would be worse — it is the claim the caller acts on, and the pull request does not merge.

     The gap this branch closes is that a withheld verdict and zero unresolved threads coexist routinely. Copilot files part of its findings **into the review body only** — a "Suppressed comments" block — and those never become threads, so nothing in the triage can see or resolve them. A review that carries only suppressed findings therefore leaves the thread count at zero while the verdict stays short of an approval. It is not the only way to reach this branch — the covering review can be `APPROVED` while the rule still wants an approval nobody has given, a second reviewer or a code owner — which is why the summary reports what was read rather than asserting a cause. Either way someone has to look, which is exactly what it hands over.

---

## Step 3: Exit

Output a final summary:

```
PR is clean after N iterations.
Total: X fixed, Y ignored.
```

Or if no unresolved threads remain but the pull request is not approved:

```
No unresolved threads remain after N iterations, but the PR is not approved (<REVIEW_DECISION>).
Total: X fixed, Y ignored. The review covering the head is <COVERED_STATE>: "<verdict line>".
Nothing is left that the triage can act on — review threads are its only input — so the requirement needs a human. Check the review body for findings filed there rather than as threads, and whether an approval the loop cannot supply is still outstanding.
```

Substitute `unavailable` for an **empty** `REVIEW_DECISION`, and say what is known instead: `not approved (decision unavailable; the base branch requires an approval)`. The empty-decision path reaches this summary precisely when `APPROVALS_REQUIRED` is true, so printing the raw value would leave the reader with empty parentheses at the one moment the line has to explain itself.

Report what was read, not a cause. An unsatisfied requirement has several, and they need different responses: the covering review may carry findings that exist only in its body, or it may be `APPROVED` while the rule still wants an approval nobody has given — a second reviewer, a code owner, a required team. Naming suppressed comments as *the* reason would send the reader to an empty review body whenever the second case applies. `COVERED_STATE` and the verdict line are in the summary precisely so the reader can tell the two apart at a glance.

Or if stopped by user at checkpoint:

```
Stopped after N iterations.
Total: X fixed, Y ignored. Remaining unresolved threads may exist.
```

Or if exited due to re-review timeout:

```
Timed out after N iterations waiting for the requested re-review (30 minutes).
Total: X fixed, Y ignored. The re-review was requested but did not arrive — check the PR manually for any remaining comments.
```

---

## Edge Cases

- **Re-review timeout**: If no new Copilot review appears within 30 minutes after the re-request in Step 2f, the loop exits with a warning that the requested re-review did not arrive. Do not proceed to the next iteration — the reviewer may be unavailable or misconfigured.
- **Re-request failure**: If the explicit re-request in Step 2f fails (HTTP 403/422, an unresolvable bot node id, or PR review disabled), report the error and exit the loop. Re-requesting a bot reviewer via `botIds` requires a `gh` token with PR write scope (a personal access token); GitHub-App or org-app tokens may lack the capability. Do not retry silently.
- **No prior Copilot reviews on PR**: `LAST_COPILOT_REVIEW_ID` is `0` — the cold-start branch of Step 2f applies (`--add-reviewer "@copilot"`). Any Copilot review detected afterward is treated as new.
- **Copilot bot login variant**: The author filter compares **exactly** against the Step 1 allow-list and additionally requires `.user.type == "Bot"`. If a previously unknown Copilot login variant appears, it belongs in that list — not in a broader pattern match that would also admit unrelated accounts with `copilot` in the name.
- **Remote head moves during the wait**: If the remote head is not covered by a Copilot review when the loop is about to declare the PR clean, someone pushed while the background wait was running. Fast-forward the checkout to it (stop and ask if that is not possible), refresh `LAST_COPILOT_REVIEW_ID`, adopt the head, re-request a review, and wait again — never exit as clean against a head the loop has no review for.
- **Zero threads on a never-reviewed branch**: A first iteration can find zero unresolved threads simply because no review exists yet. The Step 2j gate catches this: no coverage for the remote head means the loop requests a review and waits, rather than reporting a PR clean that nobody has looked at.
- **Empty review decision**: `reviewDecision` is null for a draft pull request, whose requirement GitHub has not evaluated — and Copilot reviews drafts, so a covered, threadless draft would otherwise reach the clean exit. It has also been observed empty on non-draft pull requests whose base branch required an approval. Neither case is "no approval is required", so the gate derives `APPROVALS_REQUIRED` from the branch's effective rules — every approval-bearing parameter, not just the numeric count — and treats an empty decision as satisfied only when it is `false`.
- **Zero threads while the verdict withholds approval**: two causes reach this state, and the summary reports the reading rather than picking one. Copilot files part of its findings into the review body only (a "Suppressed comments" block) and those never become review threads; or the covering review is `APPROVED` while the rule still requires an approval nobody has given. Either way the triage has nothing left to act on, so Step 2j exits with the not-approved summary instead of claiming the PR is clean — iterating would triage an empty set forever. `COVERED_STATE` and the verdict line let the reader tell the cases apart.
- **Review arrives for a superseded commit**: If a newer Copilot review appears but its `commit_id` is not `PUSHED_SHA` (a review that was already in flight when the iteration's push landed), keep waiting under the same 30-minute timeout. Do not treat it as the requested re-review, and note that because the poll filters on the SHA before reducing, such a review cannot mask a valid one that arrived before it.
- **No code changes across multiple iterations**: If 3 consecutive iterations produce no code changes (only IGNORE resolutions), the PR likely has only non-actionable comments left. Report this and suggest stopping.
- **Push fails**: If `git push` fails (e.g., remote rejection, branch protection), report the error and exit the loop. Do not retry.
- **resolve-reviews fails**: If the inner skill invocation fails, report the error and exit. Do not retry automatically.
- **Branch has diverged**: If the remote has new commits, `git push` will fail. Report and let the user handle the merge/rebase.
