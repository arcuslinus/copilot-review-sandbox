---
name: docs-audit
description: Audit the docs/ knowledge base for quality, accuracy, staleness, and structural complexity (overly long, multi-topic, or unwieldy docs that should be simplified or split). Use when the user asks to check, audit, review, or improve documentation, or mentions "docs maintenance", "stale docs", "docs quality", "knowledge base health", or "split a doc".
license: MIT
compatibility: Requires docs/ directory with markdown files.
metadata:
  author: meistersystems
  version: "1.0"
---

Audit the `docs/` knowledge base. Evaluate every doc for accuracy, currency, completeness, clarity, and actionability, and check structural complexity (overly long, multi-topic, or unwieldy docs that should be simplified or split). Output a quality report, then propose targeted improvements.

**Do NOT make changes without explicit approval.** Always show the quality report and proposed updates, then get user sign-off before editing, splitting, or deleting any file.

---

> **Not compatible with `/batch`.** This skill must not be run via `/batch`.
> Documentation changes are interdependent (cross-references, shared README, scope checks) and require
> coordinated output. If you are a sub-agent spawned by `/batch`, **stop immediately** and report back
> that this skill cannot be parallelized via `/batch`.

---

## Sub-agent strategy

This skill is context-intensive — it reads many docs and cross-references them against the codebase. Use the **Agent tool** (sub-agents) aggressively to parallelize work and protect the main context window from ballooning.

**General principles:**

- Spawn sub-agents for any phase that involves reading multiple files or making independent edits.
- Each sub-agent should receive a focused, self-contained task with all the context it needs (file paths, scoring rubric, instructions).
- Collect structured results (JSON or markdown) from sub-agents and synthesize them in the main context.
- The main agent orchestrates, presents results to the user, and makes decisions. Sub-agents do the heavy lifting.

**Model selection for sub-agents:** spawn sub-agents on a balanced-cost model rather than the top-tier model. The work — reading files, extracting structure, and returning either structured JSON (discovery, scope, cross-references, structural classification, quality scoring, split execution) or complete markdown diffs (Phase 5 editorial proposals) — does not require frontier reasoning, and parallelizing many sub-agents on the top tier burns budget without quality gain. When using Claude, prefer Sonnet over Opus; when using other AI agents, pick the equivalent balanced tier. The main (orchestrating) agent stays on whatever model the user invoked the skill with. Sub-agents that perform structural classification (Phase 2c) MUST read `references/quality-criteria.md` → `## Structural Thresholds` for the classification rubric and the JSON shape they return.

---

## Scope: `docs/` vs `openspec/`

This project separates **usage documentation** from **implementation specifications**:

<!-- prettier-ignore -->
| | `docs/` | `openspec/specs/` |
| --- | --- | --- |
| **Purpose** | How to use the system, general knowledge, feature docs | Implementation specs, design decisions, requirements, tasks |
| **Audience** | Developers using/operating the system | Developers building/changing the system |
| **Content** | Setup guides, architecture overviews, feature usage, troubleshooting | Requirements, design rationale, implementation plans, task lists |
| **Managed by** | These skills (`/docs-audit`, `/docs-revise`) | OpenSpec skills (`/openspec-*`) |

**This skill operates ONLY on `docs/`.** Never read, audit, or modify files in `openspec/`.
If you encounter content in `docs/` that looks like implementation specs (requirements, design decisions, task lists), flag it as misplaced — it likely belongs in `openspec/specs/`.

---

## Phase 1: Discovery (use sub-agents)

Scan `docs/` recursively for all `.md` files and build a categorized inventory.

**Step 1 — Get the file list (main agent):**

```bash
find docs/ -name "*.md" -type f | sort
```

**Step 2 — Categorize and summarize in parallel (sub-agents):**

Split the file list into batches of ~5-8 files. Spawn one sub-agent per batch with this prompt:

> Read each of the following docs files and return a JSON array with one entry per file:
> `{ "path": "docs/...", "category": "...", "title": "...", "summary": "one-line description" }`
>
> Categories: Architecture, Setup, Steering, Features, API docs, Guides.
> Files: [list of file paths for this batch]

**Step 3 — Merge results (main agent):**

Combine the sub-agent outputs into a single inventory table. Present the categorized inventory to the user before proceeding.

<!-- prettier-ignore -->
| Category | Examples |
| --- | --- |
| Architecture | System design, module relationships, data flow |
| Setup | **General** dev environment, tooling, onboarding (NOT feature-specific setup) |
| Steering | Product direction, tech strategy, team structure |
| Features | Feature-based docs (overview, setup, architecture, usage per feature folder) |
| API docs | Endpoint documentation, integration guides |
| Guides | How-to guides, troubleshooting, runbooks |

**Cross-reference check:** During assessment, flag feature-specific setup content that lives in `docs/setup/` instead of `docs/features/<feature-name>/setup.md`. Also verify that `docs/setup/` files cross-reference relevant feature setup docs.

---

## Phase 2: Scope Check

Check whether any documentation lives outside the repository's stated scope.

**Step 1 — Read the scope definition (main agent):**

Read `docs/README.md` and look for a **Scope** section containing "Owns" and "Does not own" lists. These describe which domains, features, and topics belong in this repository versus others.

If `docs/README.md` does not exist or has no Scope section, skip this phase entirely and note in the final report: _"Scope checking was skipped because no scope is defined in `docs/README.md`."_

**Step 2 — Check each doc against scope (sub-agents):**

For each documentation file discovered in Phase 1, assess whether its topic falls within the repository's stated scope. Spawn sub-agents with batches of files and the scope definition. Each sub-agent returns:

```json
{
  "path": "docs/...",
  "inScope": true,
  "reason": "Topic matches 'authentication' in Owns list"
}
```

Or for out-of-scope docs:

```json
{
  "path": "docs/...",
  "inScope": false,
  "suggestedRepo": "msys-pim",
  "reason": "Topic is PIM product sync, which is listed under 'Does not own: PIM (msys-pim)'"
}
```

**Step 3 — Include in report (main agent):**

Add a **Scope Issues** section to the quality report (Phase 4). For each out-of-scope doc, recommend:
- Moving or removing it from this repository
- Which repository should own it (based on the "Does not own" list)

Scope issues are classified as **Important** priority (same level as stale references).

---

## Phase 2b: Cross-reference Check (main agent or sub-agents)

**Skip this phase if the Atlassian MCP is unavailable.** Note in the report: _"Cross-reference checking was skipped because the Atlassian MCP is not configured."_

For each documentation file discovered in Phase 1, search the shared `docs` Confluence space for related content owned by other repositories using the Atlassian MCP `search` tool:

```
search({ query: "<topic derived from doc title and content>" })
```

**Only consider results from the `docs` space.** Ignore results from other spaces. For each doc, classify the `docs`-space results:

- **Related content owned by another repo** — check whether the doc already has a "Related documentation" section or inline links to the found page. If not, flag as a missing cross-reference.
- **No related content** — no flag needed.

If there are many docs, batch them and use sub-agents. Each sub-agent returns:

```json
{
  "path": "docs/...",
  "missingCrossRefs": [
    {
      "pageTitle": "Auth Middleware",
      "url": "https://foundfair.atlassian.net/wiki/spaces/docs/pages/123/Auth+middleware",
      "repo": "ms-platform",
      "reason": "Doc discusses JWT validation but doesn't link to platform auth docs"
    }
  ]
}
```

Missing cross-references are classified as **Nice-to-have** priority (suggestion level). Include them in the Phase 4 report and propose adding "Related documentation" sections in Phase 5.

---

## Phase 2c: Structure Check (use sub-agents)

The 5-dimension quality rubric in Phase 3 scores quality *within* a doc. It does not detect when a doc has grown too long, too dense, or now covers too many distinct topics to belong in one file. This phase fills that gap with a cheap heuristic pre-filter (main agent) followed by semantic classification of suspects (sub-agents).

**Step 1 — Cheap pre-filter (main agent):**

For every doc discovered in Phase 1, collect cheap structural metrics:

```bash
# per-file metrics (run in main agent or batch via a small script)
wc -l docs/path/to/file.md            # line count
wc -c docs/path/to/file.md            # byte count
grep -c '^## ' docs/path/to/file.md   # H2 count
grep -oE '^#+' docs/path/to/file.md \
  | awk '{ if (length($0) > m) m = length($0) } END { print m }'
                                       # max heading depth
```

A doc is a **structural suspect** if **any** of the thresholds in `references/quality-criteria.md` → `## Structural Thresholds` are tripped (defaults: lines > 500 OR file size > 25 KB OR H2 count > 5). The OR-logic favors recall — false positives are cheap to dismiss in Step 2; false negatives let multi-topic monsters slip through. `maxHeadingDepth` is collected for the metrics record (returned as part of the sub-agent JSON in Step 2) but is not part of the suspect predicate — deep nesting alone is not a complexity signal, but the metric is useful when the user reviews the structural-findings report.

Docs that pass all thresholds are classified `focused` automatically and skip Step 2.

**Step 2 — Semantic classification (sub-agents):**

For each suspect, spawn one sub-agent (balanced-cost model per the Sub-agent strategy section). Each sub-agent receives:

> Read `docs/path/to/file.md`. Use the rubric in `references/quality-criteria.md` → `## Structural Thresholds` to classify the doc as one of `focused | simplify-in-place | split-by-topic | both`.
>
> If the classification is `split-by-topic` or `both`, also produce a split plan:
>
> - **`overviewSections`** — a list of source H2 names whose content belongs in `overview.md`. Pick: (a) the source's intro paragraphs above the first H2, (b) any H2 named "Overview", "System overview", "Introduction", or "Summary", (c) any short cross-cutting H2 (≤ 30 lines) referenced by multiple sibling H2s.
> - **`children`** — a list of `{ name, sourceH2s }` mapping target child files to the source H2 sections they will contain. Use kebab-case names matching the topic (e.g. `ci`, `docker`, `aws`, `aws-infrastructure`). See the **File Naming** section of `references/doc-conventions.md`.
> - **`inboundLinks`** — a list of every `docs/` doc whose markdown link target resolves to **this exact file**. Match using the full path relative to `docs/` (not just the basename) — for each candidate link you find, resolve it from the referring file's location and only include it if it points at this source. Prefer markdown link targets (`[...](path)`) over plain-text mentions. If multiple files share the same basename, treat that as a collision: do not infer inbound links from basename-only matches; only include links you can resolve unambiguously to this specific file. For each inbound link, also report what the rewrite target would be (`overview.md` for top-level links; the mapped child for anchor links; `overview.md` as fallback for unmapped anchors).
>
> Return JSON only, matching the shape documented in `references/quality-criteria.md` → `## Structural Thresholds`.

**Step 3 — Collect and surface (main agent):**

Collect every sub-agent's JSON. Build a structural-findings table with columns: path, classification, triggering metrics, proposed action. The findings are surfaced in Phase 4 (report) and Phase 5 (proposed updates / split plans). No writes happen in this phase.

---

## Phase 2d: Filename Conformance (main agent)

Verify that every `.md` file under `docs/` follows the kebab-case naming rule defined in the **File Naming** section of `references/doc-conventions.md`. This phase is **read-only** — it flags non-conforming filenames in the report; it never renames, moves, or modifies files. Remediation goes through `/docs-revise` (or another approval-gated workflow).

**Step 1 — Scan filenames (main agent):**

For every `.md` file discovered in Phase 1, check whether the basename matches:

```
^[a-z0-9]+(-[a-z0-9]+)*\.md$
```

The single exception is `README.md` (case-sensitive). Any file named exactly `README.md` is conforming regardless of where it sits in `docs/`. Every other filename whose basename does not match the regex is non-conforming.

**Step 2 — Build the proposed rename:**

For each non-conforming file, derive a mechanical kebab-case rename target:

1. Strip the `.md` extension.
2. Insert a hyphen at every camelCase / PascalCase boundary (`confluenceSync` → `confluence-Sync`, `SAPIntegration` → `SAP-Integration`).
3. Replace underscores and whitespace with hyphens.
4. Lowercase the entire stem.
5. Collapse runs of hyphens to a single hyphen and trim leading/trailing hyphens.
6. Re-append `.md`.

The rename is mechanical — if the result is awkward (e.g. acronyms or version numbers split unexpectedly), the user can override it during the rename via `/docs-revise`. This phase only proposes; it never applies.

**Step 3 — Emit findings (main agent):**

Produce a list of non-conforming entries for the Phase 4 report:

```json
[
  { "path": "docs/guides/confluenceSync.md", "proposedRename": "docs/guides/confluence-sync.md" }
]
```

If every file conforms (the expected steady state), record _"All filenames conform to kebab-case."_ in the report and move on. **No writes happen in this phase** — even if findings exist, the audit only flags them.

---

## Phase 3: Quality Assessment (use sub-agents)

Evaluate each doc against 5 criteria (100 points total). Use the bundled `references/quality-criteria.md` for the full scoring rubric with examples.

<!-- prettier-ignore -->
| Criterion | Weight | What to check |
| --- | --- | --- |
| Accuracy | 25 | File paths exist, commands run, code snippets match reality, architecture descriptions match code |
| Currency | 25 | No references to removed/renamed modules, tech versions current, no stale links |
| Completeness | 20 | Key topics covered, no major gaps, all sections filled out, cross-repo references where applicable (from Phase 2b) |
| Clarity | 15 | Well-organized headings, code examples present, logical structure |
| Actionability | 15 | Runnable commands, concrete steps, troubleshooting guidance |

**Parallelize with sub-agents:** Spawn one sub-agent per doc (or per small batch of 2-3 related docs). Each sub-agent receives:

1. The doc file path(s) to assess
2. The scoring rubric (inline or reference to `references/quality-criteria.md`)
3. Instructions to cross-reference with the actual codebase:
   - Check that referenced file paths exist (use `find` or `ls`)
   - Verify command examples would actually work
   - Confirm architecture descriptions match current code structure
   - Check that module/package names are current
   - Validate any version numbers mentioned

Each sub-agent returns structured results:

> ```json
> {
>   "path": "docs/...",
>   "scores": { "accuracy": 20, "currency": 25, "completeness": 15, "clarity": 12, "actionability": 10 },
>   "total": 82,
>   "grade": "B",
>   "issues": [
>     { "criterion": "accuracy", "severity": "critical", "line": 45, "description": "File path does not exist" }
>   ],
>   "proposed_improvements": ["Update file path on line 45", "Add missing troubleshooting section"]
> }
> ```

Collect all sub-agent results before proceeding.

---

## Phase 4: Quality Report

Output the report BEFORE making any changes. The main agent compiles sub-agent results into the report.

**Summary table:**

```
<!-- prettier-ignore -->
| Doc | Category | Score | Grade | Top Issues |
| --- | --- | --- | --- | --- |
| docs/example.md | Architecture | 85/100 | B | Minor staleness in paths |
```

**Grading scale:**

- **A** (90-100): Excellent — minor polish only
- **B** (75-89): Good — some updates needed
- **C** (60-74): Fair — significant gaps or staleness
- **D** (40-59): Poor — major rewrite needed
- **F** (0-39): Failing — largely unusable or severely outdated

**Per-file breakdown** (for each doc scoring below 90):

- Score per criterion
- Specific issues found (with line references where possible)
- Proposed improvements

### Structural Issues

List every doc with a non-`focused` classification from Phase 2c. This section sits **alongside** (not folded into) the 5-dimension quality findings — complexity is a structural finding, not a score.

For each entry:

<!-- prettier-ignore -->
| Field | Notes |
| --- | --- |
| Path | `docs/...` |
| Classification | `simplify-in-place` / `split-by-topic` / `both` |
| Triggering metrics | The cheap signals that flagged it (e.g. `lines: 812, h2Count: 11`) |
| Proposed action | One-line summary; full plan lives in Phase 5 |
| Confluence impact | (splits only) Existing page repurposed/orphaned; N new child pages expected; outside-space inbound links may break |
| External inbound links | (splits only) References from outside `docs/` (e.g. `content/skills/*/SKILL.md`, source READMEs) — flag-only; the audit does NOT modify these |

Structural issues are classified as **Important** priority (same level as scope issues and stale references).

### Filename Conformance

List every non-conforming filename detected in Phase 2d. This section is informational only — the audit never renames files. Remediation goes through `/docs-revise`.

For each entry:

<!-- prettier-ignore -->
| Field | Notes |
| --- | --- |
| Current path | `docs/...` |
| Proposed rename | `docs/...` (mechanical kebab-case form) |

If every file conforms, record _"All filenames conform to kebab-case."_ instead of an empty table.

Filename-conformance issues are classified as **Nice-to-have** priority — they do not block any sync and are easy to fix individually.

---

## Phase 5: Proposed Updates (use sub-agents if many docs)

This phase surfaces **two kinds** of proposals: structural changes (split plans for `split-by-topic` / `both` docs from Phase 2c) and editorial changes (per-file diffs from Phase 3). Surface structural proposals **first** — they change the file shape and supersede per-file edits on docs that are about to be split.

### Split Plans (structural)

For every doc classified `split-by-topic` or `both` in Phase 2c, surface a complete split plan **before any write**. Each plan MUST include:

- **Source path and metrics** — `docs/foo.md`, lines / bytes / H2 count
- **Reason** — one-line summary of why the doc was flagged (which thresholds tripped, what the sub-agent observed semantically)
- **New file layout** — the directory + `overview.md` + child files, with the H2-section-to-target mapping
- **Inbound link rewrite preview** — every `docs/` doc that references the source, the existing link, and the rewrite target (`overview.md` for top-level, mapped child for anchor links, `overview.md` fallback for unmapped anchors)
- **Confluence impact note** — flag-only: existing page repurposed/orphaned on next sync; N new child pages expected; outside-space inbound links may break
- **External inbound links** — references from outside `docs/` (SKILL.md files, source READMEs, code comments) — listed so the user knows what cross-tree updates will be needed manually

Format (per split):

```
### Split: docs/foo.md → docs/foo/
**Why:** lines=812, h2Count=11; sub-agent classification: split-by-topic
**New layout:**
  docs/foo/overview.md     ← intro + System overview + Region and account + index
  docs/foo/ci.md           ← H2 "CI pipeline" + 5 sub-phases
  docs/foo/docker.md       ← H2 "Docker builds"
  ...
**Inbound link rewrites (in-tree, auto-applied):**
  docs/setup.md:42        foo.md             → foo/overview.md
  docs/onboarding.md:88   foo.md#aws-...     → foo/aws.md
**Confluence impact (flag-only, sync not modified):**
  Existing page "Foo" repurposed/orphaned on next sync; 6 new child pages expected;
  outside-space inbound links may break and need manual update.
**External inbound links (flag-only, NOT auto-rewritten):**
  content/skills/some-skill/SKILL.md:14 references docs/foo.md
```

Call the **AskUserQuestion** tool **per split** with these options:

1. **Approve (default)** — execute the split as proposed in Phase 6.
2. **Edit plan** — let the user revise the H2-to-target mapping before approval; the revised mapping is used by Phase 6 for both child files and anchor-link resolution.
3. **Skip** — leave the source file intact; per-file editorial fixes still apply to it.

The default is **Approve**. In autonomous/non-interactive modes the default is selected automatically. Splits are presented per-doc — the user can approve some and skip others independently.

### Editorial Updates (per-file diffs)

For each doc needing updates **that is not being split**, show the proposed changes in diff format with justification.

If there are **4 or more docs** needing updates, use sub-agents to draft the proposed changes in parallel. Each sub-agent receives the doc path, its assessment results from Phase 3, and instructions to produce a diff with justification:

> Read `docs/path/to/file.md`. Based on these issues: [issues from Phase 3].
> Produce the proposed changes as a markdown diff block with justification.
> Any tables in the proposed changes MUST use compact format with `<!-- prettier-ignore -->` before each table.
> Format:
> ```
> ### Update: docs/path/to/file.md
> **Score:** X/100 → estimated Y/100 after changes
> **Why:** [summary of issues]
> [diff of proposed changes]
> ```

For docs classified `simplify-in-place` in Phase 2c, the sub-agent prompt is "produce a clarity-and-trim rewrite that keeps the doc's scope but reduces dense, repetitive, or low-value content" rather than "fix these specific issues". Surface the rewrite as a diff like any other editorial update.

Group changes by priority:

1. **Critical** — Incorrect information, broken commands, wrong file paths
2. **Important** — Stale references, missing sections, outdated architecture, structural simplifications (`simplify-in-place` from Phase 2c)
3. **Nice-to-have** — Clarity improvements, better formatting, additional examples, missing cross-repo references (from Phase 2b)

For docs flagged with missing cross-references in Phase 2b, propose adding a "Related documentation" footer section with the identified cross-repo links. Follow the conventions in `references/doc-conventions.md`. Present these as separate items so the user can approve or reject them individually.

Call the **AskUserQuestion** tool with these options (editorial updates only — split plans are gated separately above):

1. **Apply all (default)** — apply every proposed change.
2. **Apply by priority (Critical / Important / Nice-to-have)** — follow up with a priority-level selection.
3. **Apply specific files** — follow up with a per-file selection.

The default is **Apply all**. In autonomous/non-interactive modes the default is selected automatically.

---

## Phase 6: Apply Updates (use sub-agents)

**Before applying**, scan every approved change and verify each markdown table in the proposed edits starts with `<!-- prettier-ignore -->` and uses compact (no column padding) format. Fix any non-compliant tables in the proposals before dispatching to sub-agents.

Apply approved changes in **this order**: splits → inbound link rewrites → per-file editorial fixes → format. Splits run first because they change the file shape; editing a doc that is about to be split would waste the edit. Each step parallelizes with sub-agents.

**Step 1 — Execute approved splits (sub-agents, balanced-cost tier):**

For every approved split plan from Phase 5, spawn one sub-agent. Each sub-agent receives the source file path, the approved (possibly user-edited) split plan, and this contract:

> Execute the approved split of `<source>` into `<sourceDir>/`, where `<source>` is the source file's full path relative to the repo root (e.g. `docs/foo.md` for a top-level doc, or `docs/setup/foo.md` for a nested doc) and `<sourceDir>` is the same path with the `.md` extension dropped (e.g. `docs/foo` or `docs/setup/foo`). The split output stays under the source's parent directory — the directory replaces the file in place.
>
> 1. Read `<source>` in full.
> 2. Create the directory `<sourceDir>/` (use the Write tool to create files; the directory is implied). Do not move the source under a different parent.
> 3. Write `<sourceDir>/overview.md` containing, in order:
>    - The source's intro paragraphs (everything above the first H2)
>    - Each H2 listed in `splitPlan.overviewSections`, with its full body
>    - A trailing `## In this section` index that links to every child file (one bullet per child, format `- [<Child Title>](<child>.md) — <one-line summary derived from the child's first paragraph>`)
> 4. For each entry in `splitPlan.children`, write `<sourceDir>/<name>.md` containing the source content from each H2 in `sourceH2s` (preserve heading levels; H2 in source becomes H2 in child). Add a `# <Title>` H1 at the top of each child file matching the child name.
> 5. Delete the original `<source>` (use the Bash tool: `rm <source>`). Do **not** leave a redirect stub.
> 6. Return a JSON summary: `{ source, deleted: true, written: ["<sourceDir>/overview.md", "<sourceDir>/<child>.md", ...] }`.
>
> Do not modify any file outside the split scope. Do not perform git operations.

**Step 2 — Rewrite inbound links across `docs/` (sub-agents, balanced-cost tier):**

For each affected `docs/` doc identified in any approved split plan's `inboundLinks`, spawn one sub-agent (one per affected doc, parallel). Each sub-agent receives the path of the affected doc and the topic mapping for every split that touches it:

> Rewrite inbound links in `docs/<affected-doc>` based on these split mappings (each split source is identified by its full path relative to `docs/`):
>
> ```
> foo.md                    → foo/overview.md
> foo.md#aws-infrastructure → foo/aws.md
> foo.md#docker-builds      → foo/docker.md
> setup/foo.md              → setup/foo/overview.md
> setup/foo.md#install      → setup/foo/install.md
> ...
> ```
>
> Rules:
>
> - **Identify split sources by full path relative to `docs/`**, not by basename. For a nested source like `docs/setup/foo.md`, the destination directory stays under the same parent: `docs/setup/foo/overview.md`, `docs/setup/foo/<child>.md`.
> - **Plain links to a split source** rewrite to that source's `overview.md`. Resolve every link target from the referring file's location and only rewrite when it resolves to an approved split source — including all relative forms such as `foo.md`, `./foo.md`, `setup/foo.md`, `../setup/foo.md`, or any other equivalent path.
> - **Anchor links to a split source** (e.g. `foo.md#some-anchor`, `setup/foo.md#some-anchor`, `../setup/foo.md#some-anchor`) rewrite to the mapped child if the anchor matches an H2 in the approved topic mapping; otherwise fall back to that source's `overview.md` and include the rewrite in the returned `unmappedAnchors` list.
> - **Preserve the original link's relative-path style** (`./`, `../`, subpath traversal) so the rewritten link still resolves correctly from the referring file's location.
> - Do not modify any link that does not resolve to an approved split source.
>
> Use the Edit tool. Return JSON `{ path, rewrites: [...], unmappedAnchors: [...] }`.

**External-tree references** (files outside `docs/` — e.g. `content/skills/*/SKILL.md`, source READMEs, in-code comments) are listed in the Phase 4 report as flag-only. The audit MUST NOT modify them in this phase. They are the user's follow-up.

**Step 3 — Apply editorial fixes (sub-agents):**

For each non-split doc with approved editorial changes from Phase 5, spawn one sub-agent (or a small batch of 2-3 files if changes are minor). Each sub-agent receives:

- The file path to edit
- The exact changes to make (from the approved proposals in Phase 5)
- Instruction to apply the changes using the Edit tool

> Apply the following approved changes to `docs/path/to/file.md`:
> [diff or list of specific edits from Phase 5]
> Use the Edit tool to make the changes. Do not modify anything beyond the approved changes.

Editorial fixes for files that were just split apply implicitly via the split execution — sub-agents in Step 1 emit cleaned-up child content that already absorbs the editorial intent.

**Step 4 — Format (main agent):**

After all sub-agents complete, collect every file that was created or modified across Steps 1–3 and format them:

```bash
{{ formatCommand }} <modified-files>
```

**Step 5 — Summary (main agent):**

Show a summary of what was changed, listing each split (with its child files and the deleted original), each inbound-link rewrite (with the count and any unmapped-anchor fallbacks), and each editorial edit applied.

---

## Phase 7: Update scope descriptor and documentation index (use sub-agent)

After all approved changes are applied, spawn a sub-agent to follow the procedure in `references/readme-maintenance.md`:

1. **Check `docs/README.md` scope descriptor** — verify the "Owns" and "Does not own" lists are still accurate after the audit fixes. If docs were removed (out-of-scope) or new domains surfaced, propose scope updates. If `docs/README.md` doesn't exist or has no Scope section, create one by investigating the codebase. Report scope changes back to the main agent, which calls the **AskUserQuestion** tool with options `Apply scope update (default)` / `Skip scope update`. The default is **Apply scope update**.
2. **Regenerate root `README.md` documentation index** — auto-generated index of all doc files. No additional approval needed.

---

## Guardrails

- **Report first, edit second** — Never modify, split, or delete files before showing the report and proposed updates
- **Get approval** — Every change needs explicit user sign-off; splits are gated per-doc in Phase 5
- **Splits are destructive** — When a split runs, the original `foo.md` is deleted and replaced by `foo/`. No redirect stub. Inbound `docs/` links are auto-rewritten; external-tree references are flagged but never modified by the audit.
- **Be specific** — Cite exact lines and paths, not vague observations
- **Verify against code** — Don't just read docs in isolation; cross-reference with the actual codebase
- **Stay in scope** — Only audit `docs/`. Never audit or modify files in `openspec/` or anywhere outside `docs/`.
- **Respect doc conventions** — Follow the project's formatting standards (see `references/doc-conventions.md`)
- **Run Formatter** — Always format modified files before finishing
- **No git operations** — Never commit, push, create branches, or open pull requests. The skill's job ends at writing files to disk and formatting them. Git operations are the user's responsibility.
- **Sub-agent isolation** — Sub-agents must not modify files unless explicitly in Phase 6 (Apply Updates). In all other phases (including Phase 2c structural classification), sub-agents only read and return results. Sub-agents never perform git operations (commit, push, branch, PR).
