# Knowledge Base Quality Criteria

## Scoring Rubric

### 1. Accuracy (25 points)

**25 points**: All technical content verified against codebase

- File paths reference real, existing files
- Commands are runnable and produce expected results
- Code snippets match current source
- Architecture descriptions match actual module structure
- API signatures and types are correct

**20 points**: Almost all content accurate, 1-2 minor inaccuracies

**15 points**: Mostly accurate but several file paths or commands are wrong

**10 points**: Multiple inaccuracies that could mislead readers

**5 points**: Significant portions are incorrect

**0 points**: Content bears little resemblance to current codebase

### 2. Currency (25 points)

**25 points**: Fully up-to-date with current codebase

- No references to removed/renamed modules or files
- Package names match current `package.json` entries
- Technology versions are current
- No references to deprecated APIs or patterns
- Links (internal and external) are not broken

**20 points**: Current with 1-2 minor stale references

**15 points**: Mostly current but references some renamed/removed items

**10 points**: Several outdated references, some sections clearly stale

**5 points**: Largely outdated, many references to things that no longer exist

**0 points**: Describes a fundamentally different version of the codebase

### 3. Completeness (20 points)

**20 points**: Comprehensive coverage of its topic

- All key aspects of the topic are addressed
- No obvious gaps or missing sections
- Prerequisites and dependencies noted
- Edge cases and limitations mentioned
- Related docs cross-referenced

**15 points**: Good coverage, one minor gap

**10 points**: Covers basics but misses important aspects

**5 points**: Significant gaps — reader would need to look elsewhere for key info

**0 points**: Stub or placeholder content only

### 4. Clarity (15 points)

**15 points**: Exceptionally clear and well-organized

- Logical heading hierarchy
- Code examples for key concepts
- Tables or diagrams where they help
- Consistent formatting throughout
- Progressive disclosure (overview → details)

**10 points**: Clear but could use better organization or more examples

**7 points**: Understandable but dense or poorly structured

**3 points**: Confusing organization, walls of text, no examples

**0 points**: Incomprehensible or severely disorganized

### 5. Actionability (15 points)

**15 points**: Reader can immediately act on the content

- Commands are copy-pasteable
- Steps are concrete and ordered
- Troubleshooting guidance for common failures
- Clear "what to do next" guidance
- Environment-specific notes where relevant

**10 points**: Mostly actionable, some steps could be more concrete

**7 points**: Gives general direction but reader must figure out specifics

**3 points**: Mostly theoretical, few concrete actions

**0 points**: No actionable content

---

## Assessment Process

1. Read the doc completely
2. Cross-reference with actual codebase:
   - Check if referenced files/directories exist
   - Verify commands would work
   - Confirm architecture descriptions match code
   - Check package/module names are current
3. Score each criterion
4. Calculate total and assign grade
5. List specific issues found with line references
6. Propose concrete improvements

## Grading Scale

<!-- prettier-ignore -->
| Grade | Score | Meaning |
| --- | --- | --- |
| A | 90-100 | Excellent — minor polish only |
| B | 75-89 | Good — some updates needed |
| C | 60-74 | Fair — significant gaps/staleness |
| D | 40-59 | Poor — major rewrite needed |
| F | 0-39 | Failing — largely unusable |

## Red Flags

- Commands that would fail (wrong paths, missing deps, wrong flags)
- References to files or directories that no longer exist
- Outdated package names (e.g., old scoped packages that were renamed)
- Architecture descriptions that don't match the current module structure
- Version numbers that are significantly behind current
- "TODO" items that were never completed
- Broken internal cross-references between docs
- Copy-paste from templates without project-specific customization
- Generic advice not grounded in this specific codebase
- Implementation specs, design decisions, or task lists that belong in `openspec/specs/`

---

## Structural Thresholds

The 5-dimension rubric above scores quality *within* a doc. It does not detect when a doc has grown too long or now covers too many topics to belong in one file. Phase 2c (Structure Check) handles that with a cheap heuristic pre-filter followed by semantic classification of suspects in sub-agents. **Sub-agents performing structural classification MUST read this section** before deciding whether a doc is structurally sound.

### Pre-filter (cheap signals, run in main agent)

A doc is flagged as a **structural suspect** if **any** of the following are true:

<!-- prettier-ignore -->
| Signal | Threshold | Why |
| --- | --- | --- |
| Line count | `> 500` | Long files are hard to navigate, hard to review, and bad mapping targets for the docs-to-Confluence sync. |
| File size | `> 25 KB` | Catches docs that are line-light but byte-heavy (tables, code blocks, ADF dumps). |
| H2 count | `> 5` | More than five top-level sections is a strong signal the file covers multiple distinct topics. |

The thresholds are **OR**, not AND — any one signal is enough. The OR-logic favors recall over precision. False positives are cheap (a sub-agent classification on a long-but-focused doc returns `focused`); false negatives are expensive (a multi-topic monster slips through unflagged).

The thresholds are **tunable**: edit the values above and the next audit run picks them up. There is no separate config file or CLI flag — this file is the source of truth.

### Classification (semantic, run in sub-agents)

For every flagged suspect, a sub-agent reads the file and returns one of four classifications:

<!-- prettier-ignore -->
| Classification | When to use it | Phase 5/6 outcome |
| --- | --- | --- |
| `focused` | The doc tripped a cheap threshold but covers a single coherent topic with cohesive H2 sections. | No structural action; per-file quality fixes still apply. |
| `simplify-in-place` | The doc is dense, repetitive, or could be shorter without losing essentials, but its scope is correct. | Propose a clarity-and-trim rewrite as a Phase 5 update; no split. |
| `split-by-topic` | The doc covers several topically distinct H2-level subjects that would each stand on their own. | Propose a split plan: `foo.md` → `foo/overview.md` + `foo/<topic>.md` × N, with inbound-link rewrites. |
| `both` | The doc covers multiple topics AND each topic is itself dense/overgrown. | Propose a split plan; each child carries the simplified version of its source sections. |

Sub-agents return JSON with shape:

The `classification` field MUST be exactly one of `focused`, `simplify-in-place`, `split-by-topic`, or `both` — not a list.

```json
{
  "path": "docs/...",
  "classification": "split-by-topic",
  "metrics": { "lines": 0, "bytes": 0, "h2Count": 0, "maxHeadingDepth": 0 },
  "topics": ["Topic 1", "Topic 2"],
  "splitPlan": {
    "overviewSections": ["System overview", "Region and account"],
    "children": [
      { "name": "ci", "sourceH2s": ["CI pipeline", "Build workflow ..."] }
    ],
    "inboundLinks": [
      { "from": "docs/setup.md", "anchor": null,         "rewriteTo": "foo/overview.md" },
      { "from": "docs/onboarding.md", "anchor": "aws-infrastructure", "rewriteTo": "foo/aws.md" }
    ]
  }
}
```

`splitPlan` is omitted for `focused` and `simplify-in-place`. For `split-by-topic` and `both`, the main agent surfaces the plan in Phase 5 (`Approve / Edit plan / Skip`) before any write.
