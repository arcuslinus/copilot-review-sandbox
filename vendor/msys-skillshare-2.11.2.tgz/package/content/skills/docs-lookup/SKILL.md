---
name: docs-lookup
description: >
  Look up documentation across local docs/ and Confluence to answer questions
  about architecture, setup, integrations, or how things work. Use when the user
  asks "how does X work?", "what does Y do?", "look up docs for Z", "find
  documentation about...", "check the docs", "search docs for...", or wants to
  understand an existing system before making changes. Also triggers when the
  user provides a topic as an argument (e.g. `/docs-lookup SAP sync`).
license: MIT
compatibility: Works best with docs/ directory and Atlassian MCP for Confluence search.
metadata:
  author: meistersystems
  version: "1.0"
---

Read-only documentation research skill. Search local `docs/` and Confluence, synthesize findings, and report with source links. **Never write, create, or modify any files.**

## Input

The user provides a research topic — either as a direct argument (`/docs-lookup SAP sync`) or in conversation context. If the topic is unclear, ask one clarifying question.

## Search Strategy

### Step 1 — Local docs/

1. Use Grep to search `docs/` for files related to the research topic
2. Use Glob with `docs/**/*.md` to find potentially relevant files by name
3. Read the most relevant files (up to 5)
4. If `docs/` does not exist, note it and move to Step 2

### Step 2 — Confluence (if Atlassian MCP available)

{%- if target.supportsAgents and flags.docsSubagent %}

Spawn a `docs-research-agent` subagent in the background to run the Confluence search in parallel while you process local results. Pass the user's research topic as context.

{%- endif %}

Use a two-phase search:

**Phase 1 — Rovo Search (broad semantic discovery)**

Decompose the research topic into 2-3 focused sub-queries:
- **Primary domain**: the core technical area (e.g., "SAP integration order sync")
- **Cross-cutting concerns**: permissions, data flow, configuration patterns
- **Prior art**: related changes, similar features, existing solutions

For each sub-query, use the Atlassian MCP `search` tool (Rovo Search):
- Use natural language, not code identifiers (camelCase returns no results on Confluence)
- Include 3-5 specific terms per query
- Filter results to `type = "page"` to skip Jira issues
- Deduplicate results across queries

**Phase 2 — CQL targeted follow-up (optional)**

If Phase 1 reveals specific pages to investigate further:
- Use `searchConfluenceUsingCql` with `title ~` queries for precision
- Scope CQL queries to specific spaces using the `space` field when relevant

**If Atlassian MCP tools are not available**: skip Confluence search entirely and note the limitation.

### Step 3 — Synthesize

Merge results from local docs and Confluence:

1. Deduplicate — if the same content appears in both local docs and the Confluence `docs` space (auto-published mirror), keep only the local version
2. Group findings by topic rather than by source
3. Resolve conflicts using the Trust Hierarchy below
4. If no relevant results were found from any source, report this clearly and suggest `/docs-add`

## Trust Hierarchy

When information conflicts across sources, apply this priority:

1. **Local `docs/`** — ground truth (lives in repo, always current)
2. **Confluence `docs` space** — auto-published mirror of local docs
3. **Other Confluence spaces** (MPortal, TD, RF, etc.) — useful for discovery, potentially stale

Note conflicts explicitly and which source was preferred.

## Output Format

Structure findings as:

1. **Summary** — 2-3 sentence overview answering the user's question
2. **Findings** — grouped by topic, each with source attribution:
   - Local docs: file path (e.g., `docs/architecture/sap-sync.md`)
   - Confluence: page title and space key (e.g., "SAP Order Sync — TD space")
3. **Gaps** — what was searched for but not found
4. **Suggestion** — if significant gaps exist, suggest creating documentation via `/docs-add`
