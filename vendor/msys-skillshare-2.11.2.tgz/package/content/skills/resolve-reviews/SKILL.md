---
name: resolve-reviews
description: >
  Triage and resolve PR review comments from any reviewer (bots, automated tools,
  or humans). Fetches unresolved review threads via GitHub GraphQL API, validates
  each against the actual code, presents a ranked overview with severity and AI
  assessment, then applies fixes, posts brief replies, and resolves threads on
  user confirmation. Use when the user says "resolve reviews", "triage reviews",
  "fix review comments", "handle PR feedback", "clean up review comments",
  "resolve PR threads", or mentions unresolved review comments on a pull request.
  Accepts a PR number or a full PR URL; the URL form identifies a pull request
  unambiguously in a fork checkout.
  Also triggers when the user wants to process automated review feedback from
  Copilot, code-quality bots, or any other reviewer.
license: MIT
compatibility: Requires GitHub CLI (gh) authenticated with repo access.
metadata:
  author: meistersystems
  version: "1.4"
---

# Resolve Reviews

Triage, fix, and resolve PR review comments in one pass.

**Invocation:**
- `/resolve-reviews` — interactive mode, auto-detect PR from current branch
- `/resolve-reviews <PR# | PR-URL>` — interactive mode, specify the PR
- `/resolve-reviews auto` — autonomous mode, skip confirmation, apply all fixes
- `/resolve-reviews auto <PR# | PR-URL>` — autonomous mode for a specific PR

A bare number resolves against the checkout's default repository; a full URL names the pull request unambiguously and is what `resolve-reviews-loop` forwards.

---

## Step 1: Prerequisites

Run these checks before anything else. Stop on the first failure.

1. Verify the `gh` CLI exists:
   ```bash
   which gh
   ```
   If not found: "GitHub CLI (gh) is required but not found. Install it: https://cli.github.com"

2. Verify authentication:
   ```bash
   gh auth status
   ```
   If unauthenticated: "GitHub CLI is not authenticated. Run: gh auth login"

3. Parse arguments, storing any selector as `PR_SELECTOR` (empty when none was given):
   - If argument is `auto` or starts with `auto`: enable auto mode. If a PR selector follows `auto` (e.g., `auto 1656`, or a full PR URL), store it as `PR_SELECTOR`.
   - If the argument is a PR selector: store it as `PR_SELECTOR`, stay in interactive mode.
   - If no argument: interactive mode, leave `PR_SELECTOR` empty and auto-detect from the branch.

4. Detect the PR **and capture its URL in the same call**, then derive the repository from that URL:
   ```bash
   # Two cases, split explicitly: `gh pr view` distinguishes "no argument"
   # (branch auto-detection) from a selector. A notation like [<SELECTOR>]
   # would not be an optional argument here but literal shell syntax, and the
   # auto-detection path would fail before `gh` even runs.
   if [ -n "$PR_SELECTOR" ]; then
     PR_JSON=$(gh pr view "$PR_SELECTOR" --json number,url,headRefOid) || { echo "ERROR: PR not found"; exit 1; }
   else
     PR_JSON=$(gh pr view --json number,url,headRefOid) || {
       echo "No open PR found for this branch. Provide a PR number or URL: /resolve-reviews <number|url>"; exit 1; }
   fi

   PR_NUMBER=$(jq -r '.number' <<<"$PR_JSON")
   PR_URL=$(jq -r '.url' <<<"$PR_JSON")
   [ -n "$PR_URL" ] && [ "$PR_URL" != "null" ] || { echo "ERROR: empty PR url"; exit 1; }

   PR_REST="${PR_URL#*://}"
   PR_HOST="${PR_REST%%/*}"                       # github.com OR the GHE instance
   PR_SLUG="${PR_REST#*/}"; PR_SLUG="${PR_SLUG%/pull/*}"   # owner/name
   OWNER="${PR_SLUG%%/*}"
   REPO="${PR_SLUG##*/}"

   # Does the checkout belong to this PR? (Rationale below the block.)
   PR_HEAD_OID=$(jq -r '.headRefOid' <<<"$PR_JSON")
   HEAD_OID=$(git rev-parse HEAD) || { echo "ERROR: could not read HEAD"; exit 1; }
   [ "$HEAD_OID" = "$PR_HEAD_OID" ] || CHECKOUT_MISMATCH=1
   ```
   Only **equality** with the checked-out `HEAD` answers the question. Checking that the commit exists in the object database would be too weak: that succeeds for any commit ever fetched, including an earlier pull request's head that has long been sitting there while `HEAD` and the working files are something else entirely — and those are exactly what this skill would then assess.

   **On `CHECKOUT_MISMATCH`:** the skill reads and modifies files in the current worktree, while the selector can point at any pull request — another one in the same repository just as easily as one in a foreign repository. Assessing threads against unrelated files and "fixing" them there is always wrong.

   The response depends on the mode, because the two make different promises:

   - **Auto mode** (how the loop invokes it): **stop and report.** Here files are changed unattended and then pushed; the loop has itself verified that its push target hits the pull request, so a mismatch here means the two checks disagree.
   - **Interactive:** **warn and ask.** `/resolve-reviews <PR#>` for a pull request other than the current branch's is documented behaviour ("uses PR #1656 regardless of the current branch") and is sometimes exactly what is wanted — to read threads, for instance. The decision belongs to the user, but it must not be made without asking.

   Host and path are taken generically from the URL, not by stripping a fixed `https://github.com/` prefix: on a GitHub Enterprise instance that fixed strip leaves the scheme and host inside the slug, and every subsequent API call names a nonsensical repository.

   Derive `OWNER`/`REPO` from the pull request, **not** from `gh repo view`. That returns the *checkout's* repository, which in a fork workflow is the contributor's fork — so every thread query, reply and resolve would target a same-numbered pull request in the fork instead of the one being triaged. A full PR URL is the unambiguous selector; a bare number resolves against the checkout's default repository, so `resolve-reviews-loop` forwards the URL rather than the number.

   The message in the error branch above **is** the required one: it names both accepted selector forms. A generic error line there with the detailed one only in the prose would be two different promises, and when executed the prose would never be seen.

---

## Step 2: Fetch Unresolved Review Threads

Fetch all review threads via GraphQL — this gives thread IDs (needed for resolution), `isResolved`, `isOutdated`, and proper thread grouping. The `reviewThreads` connection returns at most 100 nodes per request, so you **MUST paginate**: loop the query with the `after` cursor until every page is fetched. Do **not** treat the first page as complete — on a large PR the newest unresolved threads are on later pages, and stopping early silently reports the PR as clean while feedback remains.

```bash
gh api --hostname "$PR_HOST" graphql -f query='
  query($owner: String!, $repo: String!, $pr: Int!, $endCursor: String) {
    repository(owner: $owner, name: $repo) {
      pullRequest(number: $pr) {
        reviewThreads(first: 100, after: $endCursor) {
          pageInfo { hasNextPage endCursor }
          nodes {
            id
            isResolved
            isOutdated
            path
            line
            comments(first: 10) {
              nodes {
                author { login }
                body
                databaseId
                createdAt
              }
            }
          }
        }
      }
    }
  }
' -f owner="$OWNER" -f repo="$REPO" -F pr="$PR_NUMBER"
```

**Paginate through every page:**

1. Run the query above for the first page. Omit `endCursor` on this first call — GraphQL treats a missing `after` as "from the start". (Do **not** pass the literal string `"null"`.)
2. Read `pageInfo { hasNextPage endCursor }` from the response and append this page's `nodes` to an accumulated list.
3. While `hasNextPage` is `true`, repeat the same query adding `-f endCursor="<endCursor from the previous page>"`, appending each page's `nodes`.
4. Stop when `hasNextPage` is `false`.

Only once **all** pages are accumulated, filter the combined node list to **unresolved threads only** (`isResolved: false`).

- If 0 unresolved threads across all pages → report "No unresolved review threads found on PR #N" and exit.

---

## Step 3: Analyze Each Thread

For each unresolved thread:

1. **Read the code context.** Use the Read tool on the file at `path`, centering on `line` with ~20 lines of surrounding context. For file-level comments (`line: null`), read the first 100 lines of the file.

2. **Read the comment body** from the first comment in the thread.

3. **Assess the comment.** Determine:

   | Field | Values |
   |-------|--------|
   | **Severity** | CRITICAL · HIGH · MEDIUM · LOW · IGNORE |
   | **Verdict** | `✓ Valid` · `~ Debatable` · `✗ Not actionable` · `✗ Outdated` |
   | **Assessment** | 1–2 sentence justification |
   | **Proposed fix** | What code change resolves this (for Valid/Debatable only) |

   Severity guidance:
   - **CRITICAL**: Security issues, permission gaps, data loss risks, crashes
   - **HIGH**: Bugs that affect correctness, wrong file formats, broken tests
   - **MEDIUM**: Missing test fields, incomplete mocks, type mismatches
   - **LOW**: Unused imports, minor style issues, trivial cleanup
   - **IGNORE**: Repo policy reminders, not-actionable workflow flags, stale/outdated comments

   Use the `isOutdated` flag as a signal — if the thread is marked outdated, verify by reading the current code. If the issue no longer exists, verdict is `✗ Outdated`.

4. **Deduplicate.** Group comments into a single entry when:
   - Same issue flagged on adjacent lines of the same file (duplicate review runs)
   - Same pattern repeated across multiple files (e.g., 6 test files all missing the same mock field)
   
   Show the count and list all affected file:line references in the grouped entry.

---

## Step 4: Present Ranked Overview

Display a header followed by a markdown table sorted by severity (CRITICAL first, IGNORE last):

**REVIEW TRIAGE — PR #\<number\> (\<title\>)** — N threads found · M unresolved · by: \<reviewer1\>, \<reviewer2\>

| # | Sev | File | Issue | Assessment |
|---|-----|------|-------|------------|
| 1 | CRITICAL | `Component.tsx:216` | Permission gate removed | ✓ Valid — wrapper was dropped in refactor, needs re-adding |
| 2 | HIGH | `utils.ts:45`, `utils.ts:52` (×2) | Null check missing | ✓ Valid — both paths can receive undefined from API response |
| ... | | | | |
| 8 | IGNORE | `docs/overview.md:118`, `docs/setup.md:137`, `docs/guide.md:54` (×3) | Docs workflow reminder | ✗ Not actionable — repo policy reminder, not a code issue |

**Summary:** M threads → G groups · F fixable · I to ignore

Each entry MUST include the assessment with verdict and justification — this is the core value of the skill. The user sees the AI's reasoning before confirming.

---

## Step 5: User Confirmation

### Interactive mode (no `auto` argument)

Use the **AskUserQuestion tool** to let the user choose what to act on:

| Option | Description |
|--------|-------------|
| **All above IGNORE** (default) | Fix all Valid + Debatable items, reply + resolve IGNORE items with reason |
| All above LOW | Fix CRITICAL + HIGH + MEDIUM only, leave LOW and IGNORE |
| All above MEDIUM | Fix CRITICAL + HIGH only |
| Let me pick individually | Select specific items via multiSelect |

If the user picks "Let me pick individually", call **AskUserQuestion** again with `multiSelect: true`, listing each item as a selectable option with its severity and one-line summary.

### Auto mode (`auto` argument)

Skip AskUserQuestion entirely. Act on everything:
- Fix all `✓ Valid` and `~ Debatable` items
- Reply + resolve all items with severity IGNORE (verdict `✗ Not actionable` or `✗ Outdated`) with reason

---

## Step 6: Apply Fixes (Batch)

For each selected Valid/Debatable item:
1. Read the current file state (it may have changed from earlier fixes)
2. Apply the code fix using the Edit tool
3. Track which files were modified

Apply ALL fixes before any commit — no per-fix commits.

When an applied fix changes a value, name, or behavior (not a purely local correction like a typo), re-run the artifact consistency sweep for that fact in the same fix batch, before the fixes are committed: whole-tree grep the old and the new form and reconcile every restatement — OpenSpec artifacts (proposal, design, tasks, delta spec, canonical spec, archive copy), code comments, and docs.

After all fixes, report: "Applied N fixes across M files"

---

## Step 7: Reply and Resolve

For each acted-upon thread:

**Reply** — post a brief comment via REST API and verify the response:
```bash
gh api --hostname "$PR_HOST" "repos/$PR_SLUG/pulls/$PR_NUMBER/comments" \
  -f body="<reply text>" \
  -F in_reply_to={databaseId}
```

To detect failures, capture both stdout and the exit code. `gh api` writes JSON to stdout on success and error details to stderr on failure (e.g., `gh: HTTP 422`). Check the exit code first: on success (exit 0), validate the JSON response contains an `id` field using `jq -e .id`. On failure (non-zero exit), extract the HTTP status from stderr.

If the reply failed (non-zero exit or no `id` in response):
1. If the HTTP status is **422** (validation error, e.g., invalid `in_reply_to`): do **not** retry — this is a permanent failure. Log a warning and skip resolving this thread.
2. For all other failures: **retry once** — re-run the same `gh api` call.
3. If the retry also fails: log a warning and **skip resolving this thread** (leave it unresolved so it is picked up on the next iteration or manual run):
   > "Warning: Reply failed for `<path>:<line>` (HTTP `<status>`). Thread left unresolved for retry."
4. Continue processing remaining threads — do not abort the entire batch.
5. Track each failed reply (file path, line number, HTTP status) so the Step 8 summary can list them.

Reply content by verdict:
- **✓ Valid / ~ Debatable** (fixed): Brief explanation of the fix. Example: "Fixed — moved `setFieldValue` into a `useEffect` to avoid calling it during render."
- **✗ Not actionable** (severity IGNORE): Brief reason. Example: "Not actionable in this PR — this is a repo-level docs policy reminder, not a code issue."
- **✗ Outdated** (severity IGNORE): "This issue was resolved in a subsequent commit — the code no longer matches the original comment."

**Resolve** — only if the reply was successfully posted, close the thread via GraphQL:
```bash
gh api --hostname "$PR_HOST" graphql -f query='
  mutation($threadId: ID!) {
    resolveReviewThread(input: { threadId: $threadId }) {
      thread { isResolved }
    }
  }
' -f threadId="<thread node ID>"
```

If the resolve mutation fails (e.g., GraphQL error, network issue), log a warning:
> "Warning: Reply posted but resolve failed for `<path>:<line>`. Thread remains unresolved."

The reply is already visible to the reviewer, so do not retry the reply — only the thread resolution was lost. The thread will appear unresolved on the next check and can be resolved then.

---

## Step 8: Summary

Output:
```
Resolved N threads: X fixed, Y ignored across Z files

Files modified:
  - path/to/file1.tsx
  - path/to/file2.ts
```

If any replies failed, include in the summary:
```
Warning: N reply(s) failed — threads left unresolved for retry:
  - path/to/file.tsx:45 (HTTP 429)
  - path/to/other.ts:12 (HTTP 404)
```

In auto mode, this summary is the primary output — it tells the calling skill (`resolve-reviews-loop`) what happened.

---

## Edge Cases

- **File-level comments** (`line: null`): Read the full file for context rather than centering on a line.
- **Outdated flag**: Use `isOutdated` from GraphQL as a signal, but always verify by reading the current code — the flag means the diff changed, not necessarily that the issue was fixed.
- **Conflicting fixes in the same file**: Read the file state between edits to avoid applying a fix against stale content.
- **GraphQL failure**: If `gh api graphql` fails entirely, report the error and suggest the user check their `gh` token scopes (needs `repo` scope for GraphQL).
- **Deduplication across grouped items**: When a grouped entry is selected for fixing, apply the fix to ALL instances in the group, not just the first.
- **Reply API failure**: If a reply POST fails, retry once. If the retry also fails, log a warning and leave the thread unresolved. Do not resolve a thread whose reply was not successfully posted — the reviewer needs to see the explanation.
