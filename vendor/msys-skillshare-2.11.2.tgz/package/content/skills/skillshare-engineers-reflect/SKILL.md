---
name: skillshare-engineers-reflect
description: >
  Post-implementation self-improvement loop for coding engineers. After engineers
  have finished doing work (e.g. at the end of an OpenSpec apply), collect each
  engineer's reflection on its own definition, draft minimal edits, and apply them
  behind a single review gate. Use when engineers just completed tasks and we want
  to reflect on and improve their definitions, when the user says "reflect on the
  engineers", "improve the engineers from this work", "update engineer definitions
  from what we just did", or when a delegated implementation has wrapped up and the
  engineers surfaced "my instructions said X but the codebase does Y" signal.
---

Run the engineer self-improvement loop after coding engineers have done work. This
captures the most grounded signal there is — what each engineer learned *while doing
the task* — and folds minimal improvements back into its definition.

This skill runs in the main agent that already orchestrated the work. It does **not**
spawn any subagents, and it does **not** call any other engineer skill.

**Steps**

1. **Collect per-engineer reflections**

   Gather a reflection for every engineer that did work in this session. There are
   two arms depending on how the engineers were delegated — use whichever applies:

   - **Subagent arm** (engineers ran as subagents): read each engineer agent's
     `## Definition Improvements` report section straight from the main agent's
     context. Do not re-spawn the agents. If an agent reported "none", that engineer
     has nothing to apply.
   - **Skill-fallback arm** (engineers were loaded as skills): no agent boundary
     exists, so **self-reflect inline**, per engineer group, using the work you just
     performed. For each engineer, ask: did its definition mislead you, miss a recipe
     you had to discover, or contain guidance the codebase contradicts?

2. **Curate and draft a minimal edit per affected engineer**

   For each engineer with a reflection, curate the raw signal down to concrete,
   grounded improvements, then draft the smallest edit to that engineer's
   `.skillshare/engineers/<name>.md` that captures it.

{% include "references/engineer-edit-principles.md" ignore missing %}

When wording each edit, follow:

{% include "references/writing-instructions.md" ignore missing %}

3. **Present ONE combined overview (the single confirm gate)**

   Show a single overview of **all** proposed edits across **all** affected engineers
   at once — this is the only approval step. For each engineer, show which file,
   which section, and a brief description of the edit (not the full file dump). Then
   ask for approval to apply everything together.

4. **On approval, write all files then sync ONCE**

   Once the user approves:
   - Write every affected `.skillshare/engineers/<name>.md` with its drafted edit.
   - Run `{{ runPrefix }} skillshare sync` **exactly once**, after all writes, to
     redistribute the updated definitions across tools.

**No actionable improvements**

If no engineer produced an actionable, grounded improvement (every reflection was
"none", restated the diff, or was speculative), report that there is nothing to
apply. Do **not** present an empty overview and do **not** run a sync.

**If the user declines the overview**

Write no engineer definition file and run no sync. Report that nothing was changed.

**Guardrails**

- Run in the main agent only — never spawn reflection subagents.
- One combined overview, one confirm, one sync. Never prompt or sync per engineer.
- Curate before drafting: drop anything speculative or that merely restates the diff.
- Keep each edit minimal and well-placed per the principles above.
