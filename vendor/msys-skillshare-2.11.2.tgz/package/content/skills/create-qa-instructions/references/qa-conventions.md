# QA Instructions Conventions

Default conventions for what makes good QA instructions generated from an OpenSpec change. These are the **shipped defaults**. A repository MAY override or extend them with a committed **`.skillshare/references/qa-conventions.md`**, which is **spliced onto the end of these shipped defaults at sync time** (repo guidance is appended and wins on conflict; everything not overridden falls back to these defaults).

QA instructions are written for a human tester who has the change deployed but did not write the code. They describe **what to verify and how**, in concrete, reproducible steps — not how the code works internally.

## Audience and tone

- **Reader — a non-technical product tester.** Assume no coding ability and no knowledge of the codebase, branch, PR, or how the feature is built. The reader uses the running product through its UI; they do not read code, run commands, inspect diffs, or read logs.
- **Voice** — imperative and concrete: "Open X", "Click Y", "Confirm Z appears". Avoid "should probably", "verify it works", or anything that requires reading code to interpret.
- **Self-contained** — a tester must be able to execute every scenario using only the instructions, the running product, and the named test data. No "see the PR for details".

**Every step is a product interaction.** A step names a screen, a button, a field, a value, and an observable result. A step SHALL NOT reference code, a CLI or terminal command, a file path, a git operation, a diff, or logs. If a check can only be done by reading code, running a command, or inspecting a diff or logs, it is **not** a QA step — it is pre-merge PR verification and belongs in the PR body (see the routing note in `SKILL.md`).

## Environment and how the tester reaches it

QA is performed on **the running environment that carries this change for this branch** — a single, known environment the tester is pointed at. They do not choose, build, or configure one.

Which environment that is depends on the branch. Many repos stand up a per-branch preview/feature environment only for branches matching a naming rule; a branch outside that rule gets no such environment, and its change is first testable on the shared pre-production environment. **Do not assume a per-branch environment exists** — resolve it per `SKILL.md` → "Resolving the QA environment", and where none exists, name the shared environment and when the change reaches it.

The Environment section states only product-level facts the tester needs:

- How to open that environment (the URL or entry point) and how to confirm they are looking at this change's build.
- The account, role, or permissions to sign in with.
- Any product-level toggle the reader can see and flip in the UI (a settings switch, a plan tier) — never a code flag, env var, or config file.

Do **not** list developer setup (installing tooling, running a CLI, syncing, checking out a branch). Those are not part of QA.

## Source material and what to test

Derive QA instructions from the change's artifacts and diff, in this order of authority:

<!-- prettier-ignore -->
| Source | Use |
| --- | --- |
| Delta-spec `#### Scenario:` blocks | **Primary** source of test cases — each user-facing scenario becomes a QA scenario |
| Proposal "What Changes" / "Why" | Frame the environment, preconditions, and which product surfaces changed |
| Design decisions | Identify edge cases, fallbacks, and non-obvious behavior worth a dedicated scenario |
| Implementation diff | Confirm which user-facing surfaces actually changed; translate them into product interactions (never into code-level checks) |
| Tasks | Cross-check that every user-facing capability has a verification |

**Test the observable product behavior, not the implementation.** A delta-spec scenario phrased as WHEN/THEN maps directly to a QA scenario: the WHEN becomes the setup + steps, the THEN becomes the expected outcome. Internal refactors with no user-facing change get a regression check, not a scenario — and if a change is purely internal with no product surface, say so rather than inventing a technical "scenario".

## Canonical output structure

Every generated set of QA instructions fills in these sections, in this order, and is posted to Jira as the managed comment. The exact ADF node grammar (title level, badges, checkboxes, dividers, code marks) is defined in `SKILL.md` → "Canonical ADF grammar"; this section defines the content of each part.

### Title

An `h2` heading with a leading 🧪 emoji reading **QA instructions**.

### 1. Environment

Rendered as a `bulletList`. The product-level conditions from "Environment and how the tester reaches it" above — how to open the resolved environment, the account/role, any UI-visible toggle. Include only what is relevant to this change.

### 2. Preconditions and test data

Rendered as a `bulletList`. What must be true before the first scenario runs:

- Required test data (records, accounts) and how to create or obtain it **through the product**
- The starting screen or state the product must be in
- The role or permissions the tester's account needs
- **The gate**, when a check depends on one: an optional integration setting, a feature flag or a user preference that decides whether the entry point renders at all. Name the setting and where it is configured — an option that simply does not appear is otherwise indistinguishable from a broken build.

**Never assert a precondition, mechanism or control whose existence you have not established.** Where the gate could not be identified, say so. A fabricated precondition reads as authoritative and sends the tester looking for something that is not there.

If a scenario needs unique data, state it in that scenario instead of here.

### 3. Scenarios

One or more scenarios, each user-facing and independently executable, separated from the sections around them by `rule` dividers. Derive them from delta-spec scenarios first, then add edge cases the specs imply (error paths, empty states, permission denials). Each scenario is:

- **Title** — an `h4` heading carrying a sequential `#N` badge (numbered from 1, no gaps or duplicates), any coverage badges it earned (see "Coverage badges and performability" below), and a short description of the behavior being verified (mirrors the spec scenario name where one exists).
- **Steps** — a `taskList` of tickable steps. Each step is a single observable product action ("Click Save", "Submit the form with an empty name"). No step requires reading code, running a command, or inspecting a diff or logs. The steps are the checkboxes the tester ticks off as they go. Steps start unchecked **except** for a scenario badged **E2E COVERED**, whose steps ship already checked — the tester's attention goes to the unchecked ones.
- **Expected outcome** — a `blockquote` whose paragraph opens with a bold **Expected:** label followed by one explicit statement of what the tester should observe ("An error reading 'Name is required' appears and the record is not created" — not "it should fail gracefully"). The expected outcome is the judgment, not a checkbox.

Every scenario states exactly one expected end state (use sub-clauses only when one action legitimately has multiple observable effects).

### 4. Regression checks

A flat `taskList` of adjacent product behavior the change could plausibly break but does not directly target. Derive these from the diff's blast radius (shared screens, common flows, the areas next to the changed one), expressed as product checks:

- "Existing X still loads and behaves as before"
- "The unrelated Y flow next to the changed Z is unaffected"

A check is judged as a unit, so a check bundling several unrelated behaviors is usually only partly covered by automation, which leaves the whole item unbadged and its covered part re-tested by hand. A repo that wants a stricter granularity rule than the anti-patterns below states it in its own `.skillshare/references/qa-conventions.md`.

Regression checks carry badges on exactly the same terms as scenarios (see below); they are not exempt from either question. A badged item renders its badge inline and takes its tick state from the same rule — green ticked, blue unticked — and the section opens with the legend paragraph defined in `SKILL.md`, worded for the badges actually present.

If the change is fully isolated with no plausible regression surface, say so explicitly rather than omitting the section.

The gate is judged per check, so it can also empty one section alone: where no scenario survives but a regression check does, omit the Scenarios section and render the rest normally; where every regression check is routed out but a scenario survives, omit the Regression checks section rather than emit it empty. Neither is the "no plausible regression surface" case above, which is still stated in words rather than by omission. Where nothing survives — a wholly machine-to-machine change — the instructions collapse to the short form defined in `SKILL.md` → step 6: the title, one sentence that nothing here is performable by a non-technical tester, and the marker. What was routed out, and to which lane, goes to draft review rather than into the comment; the comment is still posted, because silence would be indistinguishable from the skill not having run.

## Coverage badges and performability

Every check the instructions emit — each scenario `h4` and each regression-check item — passes two questions before it is rendered: **can a human perform it**, and **does automation already cover it**. See `SKILL.md` → "Coverage badges, and whether a check is performable at all" for the decision table, the reachability barriers, the per-tier candidate sets and the honesty rules.

The two questions are a **gate and then a judgement**. A check nobody can perform in the product is not QA work at all — it leaves the comment regardless of what covers it, because the routing model reserves this lane for what a non-technical tester can actually do. Where it goes instead is that model's decision, surfaced at draft review: Post-Merge Items when it needs merged code live, the PR body as pre-merge verification otherwise.

What survives that gate is then judged for coverage, and where a concrete match is found it carries one of two badges: **E2E COVERED** (green, ships ticked) or **LOGIC COVERED** (blue, for unit or integration coverage, ships **unticked** — the test verified the logic, the tester still confirms the rendered path). Most surviving checks carry neither, and that is the ordinary case. A badge is applied only on a confident, concrete match; its absence means "unbadged", never a claim that a check is uncovered. Note what each grants: green is permission to **skip**, blue only **narrows** — it never means "do nothing here".

The badge is a **static fact about the suite**: it says an automated test covers this check, regardless of where or whether that suite has run. The instructions therefore never mention a CI run, its result, its environment, or its tier, and never phrase a badge as depending on one — run status reaches the ticket through the GitHub–Jira integration, and a badge the reader must verify against CI is no longer permission to skip anything.

## Quality bar

A good set of QA instructions is:

- **Concrete** — exact screens, fields, buttons, values, and expected text; never "the relevant page" or "appropriate data"
- **Non-technical** — every step is doable by a product tester through the UI, with no code, command, diff, or log inspection
- **Reproducible** — a second tester following the same steps reaches the same outcome
- **Complete** — every user-facing delta-spec scenario is covered; no scenario lacks an expected outcome
- **Scoped** — covers this change, not the whole product; regression checks stay adjacent, not exhaustive
- **Honest about gaps** — when a needed artifact (e.g. delta specs) is absent, note that the coverage is derived from the available material and which inputs were unavailable

## Sparse-artifact handling

When only a subset of artifacts exists (e.g. tasks only, no delta specs), still produce instructions from what is available and add a short note in the Environment section naming which inputs were missing, so the tester understands the coverage may be incomplete.

## Anti-patterns

- **Technical steps** — asking the tester to run a CLI command, check out a branch, read a file or diff, or inspect logs. These are PR verification, not QA. Translate the underlying behavior into a product interaction, or route it to the PR body.
- Restating implementation detail ("the reducer now dispatches…") instead of observable product behavior
- Vague expectations ("works correctly", "looks right", "no errors")
- Developer environment setup listed as preconditions (installing tooling, syncing, configuring env vars)
- Exhaustive regression sweeps unrelated to the change's blast radius
- Bundling multiple distinct behaviors into one scenario or regression check with one fuzzy expectation — besides being vague, a bundle cannot be badged, so automation's contribution to it is lost
- Reporting CI run status (passed/failed/skipped, environment, tier) or making a coverage badge sound conditional on a run
- Emitting a check with no human entry point as ordinary QA work — an external callback, an operation only a service credential can reach with no UI calling it, or an infrastructure trigger is not something a tester can drive
- Inventing a precondition, trigger or control to make a check look actionable — including guessing the screen a check starts from when the entry point could not be identified; ask for it before posting instead
- Judging coverage from the e2e suite alone, so a scenario a unit test already verifies ships as manual work
- Post-merge actions (confirming a prod migration, watching a metric after deploy) listed as QA — those belong in the post-merge checklist

{% include "references/qa-conventions.md" ignore missing %}
