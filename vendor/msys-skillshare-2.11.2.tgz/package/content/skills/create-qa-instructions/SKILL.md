---
name: create-qa-instructions
description: >
  Generate structured QA instructions from an OpenSpec change and post them to the
  corresponding Jira ticket as a single managed comment with native checkboxes. Use when
  the user says "create QA instructions", "generate a test plan", "write QA for this change",
  "post QA to Jira", "what should QA test", or runs the final pre-merge QA step of the
  OpenSpec workflow. Also triggers when the user provides a change name as an argument
  (e.g. `/create-qa-instructions aim-51-generate-qa-instructions`).
license: MIT
compatibility: Requires the openspec CLI and the Atlassian MCP (for posting to Jira).
metadata:
  author: meistersystems
  version: "1.1"
skillset:
  name: wrap-up
  when: >
    the change alters observable behavior, a user-facing flow, an API contract, or config a
    tester could exercise
  phase: work
  writes: false
---

Generate QA instructions for an OpenSpec change and post them to the corresponding Jira ticket as a single, idempotent **managed comment** with native Jira checkboxes. The QA instructions tell a tester what to verify and how — derived from the change's specs, design, and diff.

{% if (settings.openspecEnhanced.jiraConfirmPrompt | default("prompt")) == "prompt" -%}
**Do NOT write to Jira without explicit approval.** Always show the drafted QA instructions, allow edits, and get user sign-off before any Jira write.
{%- else -%}
This skill drafts QA instructions and posts them to Jira automatically, without a confirmation prompt. Set `features.openspec-enhanced.settings.jiraConfirmPrompt: prompt` to restore sign-off before posting.
{%- endif %}

This skill reads the default QA conventions in `references/qa-conventions.md`. Read that file before generating — it defines the output structure and the quality bar.

---

## Information routing

{% include "instructions/workflow-routing.md" %}

**Your lane — QA Instructions.** Emit only QA-lane scenarios: functional checks a non-technical tester performs in the product UI on the environment that carries this change. When a candidate belongs to another lane — a code/CLI/diff/logs check doable before merge (PR verification), or an action only possible once merged and live (post-merge checklist) — surface it to the user during draft review and leave it out of the posted comment. Never absorb it to "rescue" it.

---

## Steps

### 1. Resolve the change name

If the user passed a change name as an argument, use it. Otherwise check whether it can be inferred from conversation context (a change just implemented or verified).

If it is missing or ambiguous, prompt for selection — do NOT guess or auto-select:

```bash
openspec list --json
```

Use the **AskUserQuestion tool** to let the user pick from the available changes. Mark changes with incomplete tasks as "(In Progress)".

### 2. Resolve the target Jira ticket from the branch

Read the current branch name and extract a `<PROJECT>-<number>` ticket key:

```bash
git rev-parse --abbrev-ref HEAD
```

Branch `aim-51-generate-qa-instructions` → ticket `AIM-51`. Uppercase the project segment. Find the `<letters>-<digits>` tokens anywhere in the branch name (so prefixed branches like `feature/aim-51-…` or `linus/aim-51-…` are supported — the prefix segment isn't such a token):

- **Exactly one** such token → use it as the ticket key.
- **Zero, or more than one** such token → use the **AskUserQuestion tool** to request the ticket key. **Never guess the ticket.**

### 3. Check the Atlassian MCP is available

Posting requires the Atlassian MCP (`getJiraIssue`, `addCommentToJiraIssue`).

**If Atlassian MCP tools are not available**: STOP before posting. Explain that the QA instructions were drafted but cannot be pushed to Jira because the Atlassian MCP is not configured, and prompt the user to configure it. Offer to display the drafted instructions so they can be pasted manually. **Do NOT fail the surrounding workflow** — this is graceful degradation, same as the `docs-*` skills. The OpenSpec workflow continues.

### 4. Read the change artifacts and diff

Load the change's source material:

```bash
openspec instructions apply --change "<name>" --json
```
> Run as-is — never `| head/grep/python/jq` or truncate. The `rules` are binding.

This returns the change directory and `contextFiles` (artifact ID → file paths). Read all available artifacts: **proposal**, **design**, **delta specs**, **tasks**. Also read the implementation diff (e.g. `git diff main...HEAD` scoped to the change) for behavior the specs may not capture.

**Treat delta-spec `#### Scenario:` blocks as the primary source of QA test cases.** Each user-facing scenario becomes a QA scenario. See `references/qa-conventions.md` → "Source material and what to test".

If only a subset of artifacts exists (e.g. tasks only, no delta specs), still produce instructions from what is available and note which inputs were unavailable.

### 5. Account for repo-specific QA guidance

The conventions you read in `references/qa-conventions.md` (step 4) already incorporate any repo-specific overrides: a consuming repo's committed `.skillshare/references/qa-conventions.md` is **spliced onto the end of the shipped defaults at sync time**. There is no separate file to read at runtime. The repo's guidance appears **after** the shipped defaults and **wins on conflict** (e.g. mandatory environments, required scenario types, house format rules); everything not overridden falls back to the shipped defaults.

### 6. Generate the structured QA instructions

Produce QA instructions for the **non-technical product tester** in the structure defined by `references/qa-conventions.md`, written entirely as product-UI interactions (no code, CLI, paths, diffs, or logs):

1. **Environment** — the environment that carries this change, resolved per "Resolving the QA environment" below; the account/role to sign in with; any UI-visible toggle
2. **Preconditions and test data** — product-level starting state, records/accounts, permissions, and **the gate** any check depends on (see below)
3. **Scenarios** — one or more, each with a `#N`-badged title, ordered concrete product steps, and an explicit expected outcome
4. **Regression checks** — adjacent product behavior the change could plausibly break

**The gate is judged per check, so it can thin the comment or empty it — neither is a licence to invent.**

- **No scenario survives, but a regression check does** — drop the Scenarios section and render the rest normally. Do not manufacture a scenario to fill the shape.
- **Every regression check is routed out, but a scenario survives** — drop the Regression checks section the same way. An empty `taskList` is not an option, and neither is an invented item. This is *not* the "no plausible regression surface" case, which still says so in words.
- **Nothing survives at all** (a wholly machine-to-machine change) — post the **short form**: the emoji `h2` title, one paragraph saying this change contains nothing a non-technical tester can perform, and the marker footer. Nothing else.

**The short form does not list what was routed out.** Those checks belong to another lane, and a producer omits out-of-lane items from its posted output — naming them here would be the absorption the routing model forbids, just dressed as an explanation. The barrier and destination go to draft review, where the reviewer who needs them is. And never skip the write: an absent comment is indistinguishable from the skill never having run, leaving the assignee guessing exactly as they were before this rule existed.

Each delta-spec scenario's WHEN becomes the setup + steps; its THEN becomes the expected outcome. Every scenario MUST have exactly one explicit expected outcome — no "works correctly". Number scenarios sequentially from 1, and run **every scenario and every regression check** through the two questions in "Coverage badges, and whether a check is performable at all" before rendering — reachability first, then coverage.

**Preconditions name the gate, and invent nothing.** When a check depends on an optional integration setting, a feature flag or a user preference, name it: the setting and where it is configured. An option that simply does not render is otherwise indistinguishable from a broken build, and the tester loses a round trip finding out. Where you could not identify the gate, **say so** — never supply a plausible substitute. A real comment once asserted "a schedulable product import" for an import that has no scheduling of any kind; a fabricated precondition reads as authoritative and sends the tester looking for a control that does not exist.

### 7. {% if (settings.openspecEnhanced.jiraConfirmPrompt | default("prompt")) == "prompt" %}Draft, show, confirm (gate){% else %}Draft and post directly (no confirmation){% endif %}

{% if (settings.openspecEnhanced.jiraConfirmPrompt | default("prompt")) == "prompt" -%}
Show the full drafted QA instructions to the user. Use the **AskUserQuestion tool** to confirm: **Post to Jira (default)** / **Edit first** / **Cancel**. If the user requests changes, revise and re-show. **No Jira write happens until the user approves.**
{%- else -%}
Show the full drafted QA instructions to the user, then proceed directly to Step 8 and post them — do **not** ask for confirmation before posting. This does not change the genuine-ambiguity prompts elsewhere in this skill — change selection (step 1), ticket-key resolution (step 2), and an entry point you could not identify for a check you are keeping (step 6): those still fire regardless of this setting, because each asks for something you would otherwise have to guess.
{%- endif %}

### 8. Post to Jira as a managed comment

Build the comment body as ADF and create-or-update the single managed comment keyed by the `skillshare:qa-instructions` marker (mechanism below).

---

## Jira managed-comment mechanism

QA instructions live in exactly **one** managed Jira comment per ticket, identified by an embedded marker token. This mechanism is **QA-agnostic** — it is a generic "managed comment keyed by a marker token, built as ADF, created-or-updated-in-place". A future feature (e.g. AIM-11 post-merge action items) can reuse it verbatim with a **different marker token and a different ADF body**; nothing below assumes QA-specific content except the marker value and the body you supply.

### Canonical ADF grammar

Build the comment body as **ADF (Atlassian Document Format)** by hand and call the MCP with `contentFormat: "adf"`. **Never** rely on markdown → ADF conversion: it is unreliable (identical markdown was observed to produce a plain `bulletList` in one place and a `taskList` in another within the same comment). Every set of QA instructions follows this fixed grammar (see the worked example below for the literal nodes):

```
doc
├─ heading h2   🧪 QA instructions
├─ heading h3   Environment                 → bulletList (listItem → paragraph)
├─ heading h3   Preconditions and test data → bulletList
├─ rule
├─ heading h3   Scenarios
│   └─ per scenario:
│       heading h4   status(#N, neutral) [+ coverage status badges]  Title
│       taskList → taskItem (state per the decision table)  ← ordered STEPS; the checkboxes
│       blockquote → paragraph: strong("Expected:") + outcome
├─ rule
├─ heading h3   Regression checks
│   ├─ paragraph  em legend — ONLY when at least one regression item is badged
│   └─ flat taskList → taskItem (badges inline; state per the decision table)
├─ rule
└─ paragraph    marker footer
```

**Rules for the nodes:**

- **Node whitelist.** Emit only these node types: `doc`, `heading` (levels 2–4), `bulletList`, `listItem`, `paragraph`, `rule`, `taskList`, `taskItem`, `blockquote`, `status`, `text`. `text`-node `marks` are limited to `code`, `strong`, and `em`. Do not introduce other nodes (panels, tables, expand, media).
- **Checkboxes are the steps.** Each `taskItem` has `attrs: { localId: "<unique>", state: "<TODO|DONE>" }`; the wrapping `taskList` has `attrs: { localId: "<unique>" }`. The expected outcome is a `blockquote`, never a checkbox.
- **Tick state follows the decision table — everywhere.** See "Coverage badges, and whether a check is performable at all". `E2E COVERED` ships `DONE`; everything else ships `TODO`. That applies to the steps of a scenario and to a regression-check item alike — no category of check is exempt from the judgement.
- **Scenario badges.** Each scenario `h4` opens with a neutral `status` badge `#N` numbered sequentially from 1 (no gaps or duplicates), followed by whichever coverage badges apply, then the title text. `status` attrs: `{ text, color, localId: "<uuid>", style: "" }`. Only two coverage badges exist — `E2E COVERED` green and `LOGIC COVERED` blue.
- **Regression badges are inline.** A regression item has no heading to carry a badge, so a badged one puts its `status` node **inside** the `taskItem` as the first child, followed by a single `text` node holding the item text with a two-space prefix (`"  Quotes list opens…"`) — not a separate `"  "` node. This is the shape verified to render correctly in Jira, and it matches how a scenario `h4` merges the spacing into its title text node; a standalone `"  "` node is used only *between* two adjacent `status` badges, where no text node follows.
- **Legend, only when it earns its place, and it names what is actually there.** When at least one regression item is badged, put a single `em`-marked paragraph between the `Regression checks` heading and the `taskList`. Use exactly the wording matching the markers present — as plain text, no marks of its own beyond the paragraph's `em` — so re-runs stay byte-stable:

  - Green only:

    ```
    E2E COVERED items are already covered by the automated end-to-end suite and are pre-ticked — concentrate the manual pass on the rest.
    ```

  - Blue only:

    ```
    LOGIC COVERED items have their logic verified by automated tests. They stay unticked because the visible behaviour still needs a look — the test checked what happens underneath, not what the screen does.
    ```

  - Both present:

    ```
    E2E COVERED items are pre-ticked — automation already performs them. LOGIC COVERED items are not: their logic is verified, but the visible behaviour still needs a look.
    ```

  When no regression item is badged, emit no legend paragraph.
- **Inline code uses `code` marks, never literal backticks.** Any code token in prose — a field name, value, or identifier the tester sees on screen — is a `text` node carrying `marks: [{ "type": "code" }]`, split out from the surrounding text nodes. Jira renders a literal backtick verbatim, so never wrap tokens in backtick characters.
- **`rule` dividers** separate the major blocks (after Preconditions, after Scenarios, before the footer).

**Render inline code with ADF `code` marks, never literal backtick characters.** Inside ADF, a backtick is shown verbatim — `` `skillshare skillset` `` renders as the literal string with backticks, not monospace. For any code token (a command, flag name, file path, identifier), split the `taskItem` content into separate `text` nodes and apply `marks: [{ "type": "code" }]` to the code token. Example: the step "run `skillshare skillset wrap-up`" becomes two text nodes — `"run "`, then `"skillshare skillset wrap-up"` with a `code` mark. Plain prose stays a single unmarked text node.

### Embed the marker

Every write MUST end with this exact footer line as the comment's final paragraph — it embeds the `skillshare:qa-instructions` marker that identifies and re-discovers the managed comment, and it is byte-identical on every run so idempotent updates produce no spurious diff:

```
skillshare:qa-instructions · generated by /create-qa-instructions via Skillshare · do not edit manually
```

Render it as a single trailing paragraph: the `skillshare:qa-instructions` token carries `code` marks, and the remainder (`· generated by /create-qa-instructions via Skillshare · do not edit manually`) carries an `em` mark (see the worked example). Do not reword it — the discovery scan matches on the `skillshare:qa-instructions` substring, and the fixed wording keeps re-run updates byte-stable.

### Idempotent create-or-update by marker discovery

1. Fetch the ticket's existing comments:

   ```
   getJiraIssue({ issueIdOrKey: "AIM-51", fields: ["comment"], responseContentFormat: "adf" })
   ```

2. Scan the comments for one whose body contains the `skillshare:qa-instructions` marker.

   - **If found** → call `addCommentToJiraIssue` with that comment's `commentId` to **update it in place**. (Verified: same id, `created` preserved, only `updated` bumped, no duplicate.)
   - **If not found** → call `addCommentToJiraIssue` **without** `commentId` to create a new one carrying the marker.

The ticket's managed-comment count stays at exactly one. Never create a second managed comment.

### Re-runs and deletion

Re-running **overwrites** the comment and **resets checkbox state** — this is intended: an update means the change must be re-tested. The reset is not a blanket clear: it **recomputes** tick state from the freshly judged badges, exactly as a first render does. `E2E COVERED` scenarios' steps and `E2E COVERED` regression items come back `DONE`; everything else — including `LOGIC COVERED` items, which never pre-tick — resets to `TODO`. The Atlassian MCP has **no delete-comment operation**; to invalidate QA instructions, update the managed comment in place — never attempt to delete.

---

## Coverage badges, and whether a check is performable at all

Badges exist for one reason: **QA must be able to see what automation already did, so they do not repeat that work by hand.** They are not documentation of CI. What a badge grants depends on which one it is: green is permission to **skip** the check, blue only **narrows** it — the logic is verified, the visible behaviour still wants a look. Every rule below follows from that, and from the fact that a check nobody can perform is not QA's at all.

Every check you emit — **scenarios *and* regression checks** — passes through two questions, in this order:

1. **Can a human perform it at all?** A check whose only trigger is a machine has no place in a QA comment.
2. **Does automation already cover it, and at which tier?**

Skipping question 1 is what produced the reply `HOW??` on a real ticket: the instruction read "Run a quote product import and check its result", and there is no way to do that by hand. Skipping question 2 is what sends a tester to redo, worse, what a unit test already did better.

### The decision table

**They are a gate and then a judgement, in that order** — not two inputs to one decision. A check that fails question 1 never reaches question 2, whatever automation covers it.

<!-- prettier-ignore -->
| Question 1 | Question 2 — coverage | Badge | Emitted state |
| --- | --- | --- | --- |
| No human entry point | *not asked* | — | **not emitted** — routed out |
| Human entry point exists | Active **e2e** test | `E2E COVERED` green | `DONE` |
| Human entry point exists | **Unit or integration** test | `LOGIC COVERED` blue | `TODO` |
| Human entry point exists | None found | none | `TODO` |

`LOGIC COVERED` stays **unticked**: the test verifies the logic, **not** the rendered path, so the tester still confirms what the screen does. That reasoning holds for every badged check that survives question 1, because surviving it *means* a rendered path exists.

The routing model this skill includes is what settles row 1: a check a non-technical tester cannot perform in the product UI is not QA-lane content, and a producer never absorbs another lane's work — not even to be helpful by showing it pre-ticked.

### Question 1 — establish reachability

A check has **no human entry point** when its only trigger is one of these, each of which you can name concretely:

- **An external system calling in** — a partner callback, a webhook, a vendor-initiated sync.
- **A credential no interface surfaces, *and* no UI calls the operation behind it** — an API key living in a table, a service token. **Both halves are required.** A hidden credential proves nothing on its own: nearly every backend operation sits behind one the tester never sees, and the UI presents it for them. What makes the quote product import unreachable is not its `x-api-key` but that no frontend calls it — search the frontend for callers of the operation and find none. Finding none is a positive fact about the product; *not having found the UI* is not, and that one is forbidden below.
- **An infrastructure event** — an S3 upload, a queue message, a schedule.

**Judge this one-sidedly.** Conclude "no entry point" only from a barrier you can name; never from having failed to find a UI. Routing a performable check out is coverage lost silently, which is the failure this skill exists to prevent — so when in doubt, keep the check.

Keeping it is not licence to invent the way in. If you cannot name the screen it starts from, **ask** — this is a genuine-ambiguity prompt, so it fires before the write regardless of `jiraConfirmPrompt`, exactly like change selection (step 1) and ticket-key resolution (step 2), which step 7 exempts alongside it. Do not settle for showing it in the draft: under `jiraConfirmPrompt: auto` the draft is shown and posted in the same breath, so a note there reaches nobody in time. The user knows the product and answers in a sentence; guessing a plausible-sounding screen is the one thing you must not do. That is the same honesty step 6 demands of Preconditions, and for the same reason: a fabricated path reads as authoritative and sends the tester hunting for a control that may not exist. Doubt about *where* a check is reached is a question, not a barrier.

**A gated UI is reachable, not unreachable.** An entry point that renders only when an optional setting is present still exists — a tester who has the setting can use it. That is a *precondition* problem, not a routing one: name the gate (see step 6) rather than dropping the check.

A repo MAY list its machine-to-machine services in `.skillshare/references/qa-conventions.md`; honor that list.

**A check with no entry point is not QA work — whether or not automation covers it.** Leave it out of the comment and surface it during draft review with the reason **and the destination the routing model gives it** — run it through the same decision as any out-of-lane item: needs merged code live → Post-Merge Items; otherwise → the PR body as pre-merge verification. Do not label every such check "developer verification": an infrastructure trigger that only fires once the change is live is post-merge work, and naming the wrong lane sends it to a producer that will not emit it. If the tier search happened to turn up coverage for it, say so — it helps the reviewer decide whether anyone still owes work — but do not go looking on behalf of a check you are not emitting.

If the gate empties the comment entirely, that is a real outcome, not a failure — post the short form described in step 6, and keep the per-check reasons in draft review rather than in it.

Resist the temptation to keep such a check visible as a pre-ticked, badged item "so the tester knows it was handled". That is exactly the absorption the routing model forbids, and the reader it would serve is the reviewer, not the tester — so the place for it is draft review.

### Question 2 — locate the suites, across every tier

Coverage is not an e2e-only question. Search **every tier the repo declares** — a repo that states its tiers in `.skillshare/references/qa-conventions.md` is authoritative; otherwise auto-detect:

<!-- prettier-ignore -->
| Tier | Typical shape | Badge it earns |
| --- | --- | --- |
| End-to-end | `e2e/`, `tests/e2e/`, `cypress/`, `playwright/`, `**/__e2e__/`, or a `playwright.config.*` / `cypress.config.*` project | `E2E COVERED` |
| Integration | suites that exercise real services or a database | `LOGIC COVERED` |
| Unit | tests colocated with the source | `LOGIC COVERED` |

Searching only the e2e suite is how a fully covered scenario ends up looking untested: on one change, a scenario was completely covered by a colocated unit test — including a readiness transition the change's own record says cannot be reproduced by hand — and shipped as manual work because nothing looked past `e2e/`.

**If a tier has no locatable suite, it contributes no badges.** Do not guess.

### Derive the candidate set from the runner, not from the files — per tier

**A skipped test covers nothing.** That is a static property of the suite — it has nothing to do with whether or where the suite ran — and reading spec files cannot reliably see it. So do not assemble candidates by reading spec files: ask the runner which tests it would actually execute, and judge only against those. Where a runner cannot answer at that granularity, what may stand in for it is set out under the blue badge below — it is never the spec file taken at face value.

The listing must be **machine-readable and must distinguish disabled tests**. For Playwright:

```bash
playwright test --list --reporter=json
```

Run it from the package that owns the suite (e.g. `pnpm exec playwright test --list --reporter=json`). Keep **only** entries whose `expectedStatus` is `"passed"` and that carry no `skip`, `fixme` or `fail` annotation; what remains is the candidate set.

Allow-list, not deny-list, and deliberately so. `"passed"` admits exactly the tests the runner expects to succeed. A deny-list on `"skipped"` alone would let an **inverted** test through: `test.fail()` reports `expectedStatus: "failed"` and is *satisfied when the asserted behaviour breaks*, so it proves the opposite of coverage and must never pre-tick a QA check. Any future expected-status the runner adds is excluded by default rather than silently badged.

> **The human-readable `playwright test --list` is NOT usable as the filter.** It prints skipped tests indistinguishably from active ones — a suite with two `test.skip` journeys lists all of them with no visible marker. Only the JSON reporter carries `expectedStatus` and `annotations`. Never substitute the plain listing.

Conditional skips evaluated inside a test body are invisible at list time; they are runtime behavior and out of scope here.

**This applies to every tier — but the required strictness scales with what the badge grants.**

- **Green `E2E COVERED` pre-ticks**, so it tells QA to skip work. It requires a **per-test** machine-readable listing, as above. No such listing → no green badge, no exceptions.
- **Blue `LOGIC COVERED` does not pre-tick**, so at worst a wrong one narrows a check the tester still performs. It may therefore fall back one level — but only one. Where the tier's runner offers a per-test listing, use it. Where it offers only a **file**-level listing (Jest's `--listTests`), take the candidate files from that listing and then confirm from its source that the runner would actually execute the matching test. Two things stop it. The test is **disabled** — a skip modifier or one of its aliases (`it.skip`, `test.skip`, `xit`, `xtest`, `xdescribe`, `describe.skip`, `.todo`, `.failing`). Or it is **deselected by a focus elsewhere in the same file**: one `it.only`, `describe.only`, `fit` or `fdescribe` confines that file's run to what it marks, so an unmarked test beside it never executes though nothing is written on it. Read the enumeration as examples of the question, not as the whole of it — the question is whether the runner would run *this* test.

  **Both halves are required.** The file listing rules out files the runner never selects at all — `testMatch`, `testPathIgnorePatterns` — and a test in such a file carries no inline marker while never executing. The source check rules out a test the runner skips or never reaches inside a file that *is* selected. Either half alone badges something that never runs. Where a runner offers neither listing, establish from its configuration that the file is selected before reading it; if you cannot, emit no badge.

Without that split the rule would be self-defeating: the tier AIM-134 exists to make visible is exactly the one whose runners cannot list active tests, so a uniform requirement would mean no unit coverage is ever badged. The weaker claim tolerates the weaker source; the stronger claim does not.

### Judge coverage per check

Read the candidate tests — the ones each runner listed as active, plus, for the blue-eligible tiers whose runner cannot list, the ones you inspected and confirmed enabled — and judge, **for every scenario and every regression check**, whether one concretely exercises the same user-facing behavior — matching on what the test drives and asserts, not on name similarity alone. Apply a badge only on a **confident, identifiable** match you could point to.

**E2e wins where both exist.** A check covered at more than one tier gets `E2E COVERED`, not both badges: the green badge is the stronger claim, and two badges saying "covered" would only make the reader work out which one governs the tick.

Judge a check as one unit, and **never badge a bundle on the strength of one covered part**. A check spanning several unrelated screens or flows is usually only partly covered, which leaves the whole item unbadged — so the covered part gets tested by hand anyway. That is a cost of how the check was written, and a repo that wants to avoid it says so in its own `.skillshare/references/qa-conventions.md`.

### Honesty rules

- **Badge only on a concrete match.** Absence of a badge means "unbadged / unknown", **never** "not covered". Do **not** emit a red or "NOT COVERED" badge — a false positive that tells QA a check is covered when it is not would be worse than silence, and a loud "uncovered" marker adds noise.
- **When unsure, leave it off.** Uncertain, partial, or inferred-by-name matches get no badge.
- **Only two badges exist**, with fixed text and colour: `E2E COVERED` green and `LOGIC COVERED` blue. Do not invent a third. There is no marker for "no UI path", because such a check is never rendered — it left at question 1.
- **The badge is unconditional — never mention a CI run.** It states a static fact about the suite, true or false regardless of where or whether the suite has run. The comment SHALL NOT report whether the suite ran, passed, failed or was skipped, on which environment or tier it ran, or use any wording that makes a badge depend on a run ("…which has already run green on staging"). Run status is already surfaced on the ticket by the GitHub–Jira integration; restating it would send the reader to look up CI just to decide whether to trust the badge.
- **No suite → no badges**, as above. **No active-test listing → no _green_ badge**: a runner that cannot produce a machine-readable per-test listing counts as "no suite" for `E2E COVERED`, and there is no fallback for it. Blue keeps the source-inspection fallback described above, because it grants less. Name the reason during draft review either way, so the user can fix the listing and re-run.

### Rendering and fallback

Each badge is a `status` node with `attrs: { text, color, localId: "<uuid>", style: "" }`, using exactly these pairs:

<!-- prettier-ignore -->
| Text | Colour |
| --- | --- |
| `E2E COVERED` | `green` |
| `LOGIC COVERED` | `blue` |

Placement, and the tick state from the decision table:

- **Scenario** — the badge goes on the `h4` after the `#N` badge, separated by a `"  "` text node, with the title text merged into the final `text` node behind a two-space prefix. Set that scenario's step `taskItem`s to the state the table gives.
- **Regression check** — the badge goes *inside* the `taskItem` as its first child, with the item text merged into the following `text` node behind a two-space prefix. Set that `taskItem` to the state the table gives, and add the legend paragraph to the section (see "Canonical ADF grammar").

If the round-trip validation (see the change's design) shows the MCP cannot write `status` nodes faithfully in this environment, fall back to bold `strong` text prefixes for **all** of them — `#N` as plain bold text and the coverage label likewise — rather than dropping the information. The `#N` badge is a `status` node too, so a fallback that covers only the coverage labels would leave the numbering unrendered. The tick states still apply.

---

## Resolving the QA environment

The Environment section must name the running environment that **actually carries this change for this branch**. Never assume a per-branch preview environment exists: in a repo whose preview/e2e deploy triggers on a branch-name prefix the everyday branch convention does not use, most branches get no such environment, and naming one sends the tester to a URL that was never deployed.

This is unrelated to coverage. It is about where the tester goes to perform the *unbadged* work.

Resolve in this order, and stop at the first that answers:

1. **The repo's guidance.** A branch-to-environment rule stated in the repo's `.skillshare/references/qa-conventions.md` (spliced onto the shipped conventions) wins outright.
2. **An explicit branch-to-environment mapping in the repo's own deploy/e2e workflow config** — the place where a workflow *names its target*: an environment or URL derived from the branch, the provisioning job that stands it up, the parser that turns a branch name into an environment identifier. A trigger condition alone does **not** answer this. It establishes only that a job runs for this branch, not what that job deploys to or tests against — an e2e workflow may well trigger on your branch and run against shared staging. Treat a bare trigger as **inconclusive** and fall through to step 3; assuming it implies a per-branch environment recreates the very "URL that was never deployed" problem this rule exists to fix.
3. **Ask.** Use the **AskUserQuestion tool**. Guessing is not an option here: the hardcoded "the preview URL on the PR" sentence this rule replaces *was* the guess, and it was wrong for most branches.

When the branch gets no per-branch environment, name the **shared pre-production environment the change reaches first**, with its URL, and tell the tester how to confirm this change is actually present there — a visible build or version marker they can read in the product. State availability in those product-visible terms, never as a git or CI event: a non-technical tester cannot observe a merge, but they can observe a build.

---

## Worked example

### Mapping a delta-spec scenario to a QA scenario

Source delta-spec scenario:

```
#### Scenario: Empty name is rejected

- **WHEN** a user submits the new-contact form with the Name field left blank
- **THEN** an error reading "Name is required" appears and no contact is created
```

Generated QA scenario (as a product tester sees it):

> **#1  Empty name is rejected**
>
> ☐ Open the Contacts screen and click **New contact**.
> ☐ Leave the **Name** field blank and click **Save**.
>
> > **Expected:** An error reading "Name is required" appears beneath the Name field and no new contact is added to the list.

The WHEN became the tickable steps; the THEN became the single **Expected:** blockquote. Every step is a product interaction — no code, command, or diff.

### ADF comment body

A full managed comment following the canonical grammar: an emoji `h2` title; Environment and Preconditions as `bulletList`s; a `rule`; two scenarios, each an `h4` with a `#N` badge (the first also `E2E COVERED`) plus a `taskList` of steps and an `Expected:` `blockquote`; a `rule`; the Regression legend paragraph and `taskList`; a `rule`; and the marker footer. Note the sequential `#1`/`#2` badges, the `code` marks on on-screen tokens, and the `status` `localId`s (any unique UUID-like string).

The example shows every state the decision table produces for a check that reaches rendering. Scenario `#1` is `E2E COVERED`, so its steps are pre-ticked. Scenario `#2` is `LOGIC COVERED` and stays `TODO` — a unit test verifies the logic, the tester still confirms the screen. Among the regression items: 1 is `E2E COVERED` and ticked, its badge **inside** the `taskItem`; 2 is unbadged and `TODO`; 3 is `LOGIC COVERED` and `TODO`. The legend uses the both-present wording because green and blue both appear **in this section** — it explains a state the reader can actually see here, which is the point of wording it per section.

The second Preconditions bullet is the no-gate branch of the precondition rule: nothing gates these screens, and the instructions say so rather than staying silent.

What the example cannot show is the check that failed question 1 — it is not here, which is the point.

The Environment bullet names a concrete environment resolved from the branch — an example, not a default to copy; a branch with no per-branch environment gets the shared pre-production one instead.

```json
{
  "type": "doc",
  "version": 1,
  "content": [
    { "type": "heading", "attrs": { "level": 2 }, "content": [{ "type": "text", "text": "🧪 QA instructions" }] },
    { "type": "heading", "attrs": { "level": 3 }, "content": [{ "type": "text", "text": "Environment" }] },
    { "type": "bulletList", "content": [
      { "type": "listItem", "content": [{ "type": "paragraph", "content": [{ "type": "text", "text": "Open the ft-4821 feature environment at https://ft-4821.example.com and sign in. The footer shows the build number — confirm it matches the one on this ticket." }] }] },
      { "type": "listItem", "content": [{ "type": "paragraph", "content": [{ "type": "text", "text": "Use an account with the Editor role." }] }] }
    ] },
    { "type": "heading", "attrs": { "level": 3 }, "content": [{ "type": "text", "text": "Preconditions and test data" }] },
    { "type": "bulletList", "content": [
      { "type": "listItem", "content": [{ "type": "paragraph", "content": [{ "type": "text", "text": "Start on the Contacts screen with at least one existing contact." }] }] },
      { "type": "listItem", "content": [{ "type": "paragraph", "content": [{ "type": "text", "text": "No setting or feature flag gates these screens — everything below is reachable with an ordinary Editor account." }] }] }
    ] },
    { "type": "rule" },
    { "type": "heading", "attrs": { "level": 3 }, "content": [{ "type": "text", "text": "Scenarios" }] },
    { "type": "heading", "attrs": { "level": 4 }, "content": [
      { "type": "status", "attrs": { "text": "#1", "color": "neutral", "localId": "s1-num", "style": "" } },
      { "type": "text", "text": "  " },
      { "type": "status", "attrs": { "text": "E2E COVERED", "color": "green", "localId": "s1-cov", "style": "" } },
      { "type": "text", "text": "  Empty name is rejected" }
    ] },
    { "type": "taskList", "attrs": { "localId": "s1-steps" }, "content": [
      { "type": "taskItem", "attrs": { "localId": "s1-1", "state": "DONE" }, "content": [{ "type": "text", "text": "Open the Contacts screen and click New contact." }] },
      { "type": "taskItem", "attrs": { "localId": "s1-2", "state": "DONE" }, "content": [{ "type": "text", "text": "Leave the Name field blank and click Save." }] }
    ] },
    { "type": "blockquote", "content": [{ "type": "paragraph", "content": [
      { "type": "text", "text": "Expected: ", "marks": [{ "type": "strong" }] },
      { "type": "text", "text": "An error reading " },
      { "type": "text", "text": "Name is required", "marks": [{ "type": "code" }] },
      { "type": "text", "text": " appears beneath the Name field and no new contact is added to the list." }
    ] }] },
    { "type": "heading", "attrs": { "level": 4 }, "content": [
      { "type": "status", "attrs": { "text": "#2", "color": "neutral", "localId": "s2-num", "style": "" } },
      { "type": "text", "text": "  " },
      { "type": "status", "attrs": { "text": "LOGIC COVERED", "color": "blue", "localId": "s2-cov", "style": "" } },
      { "type": "text", "text": "  A valid contact is created" }
    ] },
    { "type": "taskList", "attrs": { "localId": "s2-steps" }, "content": [
      { "type": "taskItem", "attrs": { "localId": "s2-1", "state": "TODO" }, "content": [{ "type": "text", "text": "Open New contact, enter a name, and click Save." }] }
    ] },
    { "type": "blockquote", "content": [{ "type": "paragraph", "content": [
      { "type": "text", "text": "Expected: ", "marks": [{ "type": "strong" }] },
      { "type": "text", "text": "The contact appears in the list with the entered name." }
    ] }] },
    { "type": "rule" },
    { "type": "heading", "attrs": { "level": 3 }, "content": [{ "type": "text", "text": "Regression checks" }] },
    { "type": "paragraph", "content": [{ "type": "text", "text": "E2E COVERED items are pre-ticked — automation already performs them. LOGIC COVERED items are not: their logic is verified, but the visible behaviour still needs a look.", "marks": [{ "type": "em" }] }] },
    { "type": "taskList", "attrs": { "localId": "reg" }, "content": [
      { "type": "taskItem", "attrs": { "localId": "reg-1", "state": "DONE" }, "content": [
        { "type": "status", "attrs": { "text": "E2E COVERED", "color": "green", "localId": "reg-1-cov", "style": "" } },
        { "type": "text", "text": "  Editing an existing contact still saves as before." }
      ] },
      { "type": "taskItem", "attrs": { "localId": "reg-2", "state": "TODO" }, "content": [{ "type": "text", "text": "The contact export on the same screen still produces a file." }] },
      { "type": "taskItem", "attrs": { "localId": "reg-3", "state": "TODO" }, "content": [
        { "type": "status", "attrs": { "text": "LOGIC COVERED", "color": "blue", "localId": "reg-3-cov", "style": "" } },
        { "type": "text", "text": "  Duplicate email addresses are still rejected on save." }
      ] }
    ] },
    { "type": "rule" },
    { "type": "paragraph", "content": [{ "type": "text", "text": "skillshare:qa-instructions", "marks": [{ "type": "code" }] }, { "type": "text", "text": " · generated by /create-qa-instructions via Skillshare · do not edit manually", "marks": [{ "type": "em" }] }] }
  ]
}
```

Post it with:

```
addCommentToJiraIssue({ issueIdOrKey: "AIM-51", contentFormat: "adf", body: <the doc above>, commentId: "<existing id if the marker was found, else omit>" })
```

---

## Guardrails

{% if (settings.openspecEnhanced.jiraConfirmPrompt | default("prompt")) == "prompt" -%}
- **Draft first, post second** — Never write to Jira before showing the draft and getting explicit approval.
{%- else -%}
- **Draft, then post automatically** — With `jiraConfirmPrompt: auto` (the default), show the draft and post it directly, with no confirmation prompt. Set `features.openspec-enhanced.settings.jiraConfirmPrompt: prompt` to restore confirm-before-post.
{%- endif %}
- **Never guess the ticket** — If the branch yields no unambiguous `<PROJECT>-<number>` key, ask via AskUserQuestion.
- **Degrade gracefully** — If the Atlassian MCP is unavailable, stop before posting, explain, prompt for setup, and do NOT fail the surrounding workflow.
- **One managed comment** — Always discover-by-marker and update in place; never create a duplicate.
- **Canonical grammar only** — Hand-build the ADF to the canonical grammar and node whitelist; never rely on markdown `- [ ]` conversion. Steps are `taskItem`s; the expected outcome is a `blockquote`. Anything structural — badges, task items, nested blocks — is hand-built ADF; markdown handed to Jira's converter has been observed to silently drop whole blocks.
- **Reachability gates coverage** — Ask whether a human can perform the check at all *before* asking whether automation covers it. No entry point → it leaves the QA comment, whatever covers it, and is surfaced at draft review with the lane the routing decision gives it (Post-Merge Items or the PR body), not with a fixed label. Conclude "no entry point" only from a nameable barrier, never from not finding a UI — and where you keep a check whose entry point you could not identify, ask for it before posting (a genuine-ambiguity prompt, not a draft note) instead of inventing a screen.
- **Every check is judged** — Scenarios *and* regression checks go through both questions, and tick state follows the decision table in both. No category is exempt.
- **Two badges, fixed pairs** — `E2E COVERED` green ships ticked, `LOGIC COVERED` blue ships unticked. E2e wins where both tiers cover a check.
- **Preconditions name the gate** — An optional setting, flag or preference a check depends on is named with its location. Where none was identified, say so; never invent a mechanism.
- **Candidates come from the runner where it can tell you** — Green requires a per-test active listing (`expectedStatus: "passed"`, no `skip`/`fixme`/`fail`); no listing → no green badge, ever. Blue may fall back one level: the file must appear in a file-level listing (Jest's `--listTests`) or be shown selected by the runner config, **and** the source must show the runner would run that test — not disabled (`skip`/`xit`/`xtest`/`todo`/`failing`) and not deselected by an `.only`/`fit` focus elsewhere in the file.
- **The badge never mentions CI** — No run result, environment, or tier in the comment, and no wording that makes a badge conditional on a run.
- **Name the environment the branch gets** — Resolve it from repo guidance or an explicit branch-to-environment mapping in the repo's workflow config; a bare trigger is inconclusive, so fall through to asking. Never emit a preview URL by default.
- **Non-technical steps only** — Every step is a product-UI interaction. No code, CLI, file paths, git, diffs, or logs — those are PR verification, routed to the PR body, not QA.
- **Inline code uses `code` marks** — Render on-screen tokens as `text` nodes with a `code` mark, never literal backticks (Jira shows backticks verbatim).
- **No delete** — There is no delete operation; invalidate by updating the managed comment in place.
- **Repo guidance wins** — a repo's `.skillshare/references/qa-conventions.md` is spliced onto the shipped defaults at sync time and overrides them where they conflict.
- **No git operations** — The skill reads the diff but never commits, pushes, branches, or opens PRs.
