---
name: skillshare-modify
description: Interactively modify Skillshare configuration for a repository or for the developer's global setup. Use when the user wants to change tools, toggle features, adjust variables, edit flags, update hooks, force-include or force-exclude individual skills or workflows, add a custom tool, change content committedness, modify instruction or rule splice files, add personal/global custom content, edit their global ~/.skillshare config, or says "change skillshare config", "add a feature", "enable X", "modify my setup", "set this for all my repos". Distinct from skillshare-onboard which is for first-time setup only.
license: MIT
---

# Modify Skillshare Configuration

Interactively guide edits to the Skillshare config layers (`.skillshare/repo.yml`, `.skillshare/user.yml`,
`~/.skillshare/user.yml`) and related source-of-truth files. This skill is for ongoing configuration changes — not
first-time setup (use `skillshare-onboard` for that).

**Before making non-trivial changes, read `.skillshare/README.md`** for the authoritative reference on the config
cascade, template variables, feature sets, and splice file conventions.

> **Config cascade (four layers).** They merge lowest→highest, ordered by distance-from-developer (closer wins; maps
> deep-merge, scalars/arrays replace): the package's `global.yml` (org defaults) → committed `.skillshare/repo.yml`
> (team deviations) → gitignored `~/.skillshare/user.yml` (the developer's **global** personal deviations, applied to
> every repo) → gitignored `.skillshare/user.yml` (personal deviations for **this** repo). The two `user.yml` layers
> feed only the user surface and never affect committed outputs. Generated outputs are gitignored and regenerated
> per-machine; the committed generated outputs are `.github/workflows/skillshare-*.yml`, `.skillshare/README.md`, and —
> when `github-copilot` is committed-selected (the default) — `.github/copilot-instructions.md` (read server-side by
> GitHub's Copilot reviewer).

---

## What You Can Edit

All changes go through source-of-truth files — never edit skillshare-managed output files directly.

### Config files — `repo.yml`, `.skillshare/user.yml`, `~/.skillshare/user.yml`

All three use the **same schema** (every key optional per file). Choose the layer by scope:

| File | Scope | Committed |
|---|---|---|
| `.skillshare/repo.yml` | team-wide, this repo | yes |
| `.skillshare/user.yml` | personal, this repo | no (gitignored) |
| `~/.skillshare/user.yml` | personal, **every** repo the developer syncs | no (home dir) |

Put team-wide deviations in `repo.yml`; per-repo personal deviations (e.g. "only sync the tools I use here") in
`.skillshare/user.yml`; cross-repo personal defaults (e.g. a personal tool or flag preference you want everywhere) in
`~/.skillshare/user.yml`. The two `user.yml` layers accept the same keys; the global one resolves just below the
repo one.

> **Locating `~/.skillshare/` (the global layer) per OS.** `~` is the developer's home directory. It is **not**
> expanded by Windows `cmd`/PowerShell, so when creating or editing the global config/content you must use the real
> home path:
>
> | OS | Global config file | Create the dir with |
> |---|---|---|
> | macOS / Linux | `~/.skillshare/user.yml` (`$HOME/.skillshare/`) | `mkdir -p ~/.skillshare` |
> | Windows (PowerShell) | `$HOME\.skillshare\user.yml` (e.g. `C:\Users\you\.skillshare\user.yml`) | `New-Item -ItemType Directory -Force $HOME\.skillshare` |
> | Windows (cmd) | `%USERPROFILE%\.skillshare\user.yml` | `mkdir "%USERPROFILE%\.skillshare"` |
>
> The skillshare CLI itself resolves this via `os.homedir()` on every platform, so once the file exists in the right
> place, `skillshare sync` picks it up identically — the OS difference matters only when you (or the agent) create or
> edit the file by hand. The same applies to global **content** dirs (`~/.skillshare/skills/`, `~/.skillshare/agents/`, …).

| Section | What It Controls |
|---|---|
| `tools` | Selection **array** (replace semantics; absent = all defined tools) of tool IDs (`claude`, `codex`, `cursor`, `gemini`, `github-copilot`, `opencode`, `dot-agents`) |
| `variables` | Explicit template variables (`repoName`, `packageManager`, `runPrefix`, `formatCommand`, `nodeVersion`, `defaultBranch`, custom). No inference — set every value a template uses |
| `features` | Feature toggles. Bare boolean (`feature-name: true`) or override object (`enabled: true` + `skills`/`github-workflows`/`agents`/`engineers`/`openspec-rules`/`flags`). Selection fields are `name: true\|false` maps |
| `skills` / `github-workflows` / `agents` / `engineers` | `name: true\|false` selection maps. `true` = force-include from the catalog; `false` = force-exclude. Unknown name = validation error |
| `flags` | Positive-named flags (on by default), deviations only. Set `false` to suppress the content a flag gates, `true` to force it on |
| `toolDefinitions` | Add a custom tool or override a built-in tool's fields (deep-merged). Each entry: `name`, `skillsDir`, optional `agentsDir`/`agentFileExt`, `instructionFile`, `instructionTemplate` (`plain` or `cursor-rule`), optional `serverSideInstructions` (instruction file read server-side from the committed tree ⇒ committed by necessity, exempt from the derived ignore when the tool is committed-selected; built-in: `github-copilot`). There is **no** `ignore` field — gitignore patterns are derived from the structural dirs; a tool defined only in a `user.yml` layer routes its ignores to `.git/info/exclude`, and a `user.yml` structural override of a committed-defined tool routes each divergent path there too |
| `content.<type>.committed` | Whether a content type's outputs are committed (default: `github-workflows` and `readme`; instruction files of committed-selected `serverSideInstructions` tools are committed per-file regardless of this setting). **Not** allowed in either `user.yml` layer |
| `hooks.postSync` | Shell command run after writing managed files (typically a formatter). `false` disables. Supports {% raw %}`{{ variable }}`{% endraw %} interpolation |
| `gitattributes` | `false` disables the managed `.gitattributes` block |

> There is **no** `rules`, `instructions`, or `rules.schema` config key in 2.0. OpenSpec `config.yaml` generation is
> driven by an enabled feature contributing an `openspec-context` instruction reference or a non-empty `openspec-rules`
> artifact map (a per-feature `openspec-rules: false` drops just the rules block). Rule customization happens in the
> splice files below.

### `.skillshare/instructions/*.md`

Flat splice files that inject repo-specific content into the rendered instruction files (CLAUDE.md, AGENTS.md, etc.).
Edit these to customize per-repo guidance:

- `project-context.md` — project description, business domain, high-level overview
- `technical-context.md` — tech stack, architecture, build/test commands (also the `context:` block of `openspec/config.yaml`)
- `coding-standards.md` — repo-specific coding conventions

### `.skillshare/openspec-rules/<artifact>.md`

Flat, plain-named splice files for repo-specific OpenSpec rule additions — `proposal.md`, `design.md`, `specs.md`,
`tasks.md`. Each holds YAML list items (`- rule text`) spliced into the composed per-artifact template. Nunjucks
variables and flag conditionals are supported; new flags may be declared in frontmatter. No sub-folders.

### `.skillshare/skills/<name>/`

Per-repo **committed, team-shared** custom skills. Each subdirectory is a custom skill distributed to all configured
tool directories on sync. Use the `skillshare-create-skill` skill to scaffold new ones.

### Personal & global custom content (gitignored)

Beyond the committed team content above, a developer can add **personal** content of any type (skills, agents,
engineers, instructions, targets, OpenSpec rule splices — **not** github-workflows) in two gitignored scopes. Both are
**synced by default — enabled by presence** (just drop the file in), feed only the user surface, and are never
committed.

| Scope | Location | Applies to |
|---|---|---|
| Repo-user | `.skillshare/<type>/user/` (e.g. `.skillshare/skills/user/<name>/`, `.skillshare/agents/user/<name>.md`) | this repo only |
| Global-user | `~/.skillshare/<type>/` (e.g. `~/.skillshare/skills/<name>/`) plus `~/.skillshare/user.yml` config | every repo the developer syncs |

Precedence (closest wins): `content/` < `.skillshare/<type>/` < `~/.skillshare/<type>/` < `.skillshare/<type>/user/`.
Personal **instructions** are appended (not shadowed) to the composed instruction file via two anchors —
`.skillshare/instructions/user/user-instructions.md` (this repo) and `~/.skillshare/instructions/global-user-instructions.md`
(every repo). `skillshare init` scaffolds the repo `user/` subfolders; the personal layers are documented in the
generated `.skillshare/README.md`. Note
`user` is a reserved name in a repo type dir — it always means "the personal subfolder."

---

## How to Apply Changes

1. **Understand the request** — ask clarifying questions if the user's intent is ambiguous. Establish **scope**: team-wide (`repo.yml`), personal-this-repo (`.skillshare/user.yml`), or personal-all-repos (`~/.skillshare/user.yml`).
2. **Read `.skillshare/README.md`** for full reference on the section being changed.
3. **Edit the source-of-truth file** — the right config layer for the scope, a splice file, or a custom-content file (committed `.skillshare/<type>/`, or gitignored `.skillshare/<type>/user/` / `~/.skillshare/<type>/`).
4. **Run `{{ runPrefix }} skillshare sync`** to regenerate all managed output files.

When editing prose splice files (`.skillshare/instructions/*.md`, `.skillshare/openspec-rules/*.md`), follow:

{% include "references/writing-instructions.md" ignore missing %}

---

## Common Tasks

### Enable or disable a feature

```yaml
# In .skillshare/repo.yml
features:
  auto-docs: true        # bare toggle
  openspec-enhanced:
    enabled: true
    github-workflows:
      openspec-to-confluence: false   # drop one workflow from the feature (name→bool map)
```

### Restrict tools (personal, this repo)

```yaml
# In .skillshare/user.yml — only sync the tools you use here
tools: [claude]
```

### Set a personal default for every repo (global)

```yaml
# In ~/.skillshare/user.yml — applies to every repo you sync
tools: [claude]
flags:
  tddWorkflow: false
toolDefinitions:
  my-editor: { name: My Editor, skillsDir: .myeditor/skills, instructionFile: .myeditor/INSTRUCTIONS.md, instructionTemplate: plain }
```

### Add personal custom content

Drop the item into the personal scope — no config entry needed (enabled by presence):

```text
.skillshare/skills/user/<name>/SKILL.md     # personal skill, this repo (gitignored)
~/.skillshare/agents/<name>.md              # personal agent, every repo
~/.skillshare/instructions/global-user-instructions.md  # appended to every CLAUDE.md
```

### Force-include / force-exclude a skill

```yaml
skills:
  openspec-archive-change: false   # exclude one skill a feature provides
  docs-lookup: true                # include one skill no feature provides
```

### Change the post-sync formatter

```yaml
hooks:
  postSync: "npx prettier --write ."
```

### Add repo-specific instructions or rules

Edit the relevant splice file under `.skillshare/instructions/` or `.skillshare/openspec-rules/`. The content is injected into the
rendered output at the correct position.

---

## Guardrails

- **Never edit skillshare-managed output files directly.** If a file's first lines contain `Managed by @msys/skillshare`,
  route the edit to its source:
  - Instruction content → `.skillshare/instructions/<name>.md` (team) or the personal anchors (`.skillshare/instructions/user/user-instructions.md`, `~/.skillshare/instructions/global-user-instructions.md`)
  - Rule additions → `.skillshare/openspec-rules/<artifact>.md`
  - Config changes → `.skillshare/repo.yml` (team) · `.skillshare/user.yml` (personal, this repo) · `~/.skillshare/user.yml` (personal, all repos)
  - Skill content → `.skillshare/skills/<name>/` (team) · `.skillshare/skills/user/<name>/` or `~/.skillshare/skills/<name>/` (personal) · `content/skills/<name>/` (in the skillshare repo)
- **Always run `{{ runPrefix }} skillshare sync` after changes** to regenerate managed files. (A `~/.skillshare` change affects every repo — re-sync each repo where you want it to take effect.)
- **Read `.skillshare/README.md` first** for non-obvious configuration options — do not guess semantics.
- **Validate feature, skill, and flag names** — unknown names cause sync to fail with an error listing the valid options.
- **`content.<type>.committed` belongs in `repo.yml`, never a `user.yml` layer** — committedness is a committed-surface decision. Personal content is never committed regardless.
- **Confirm scope before editing a global layer** — changes to `~/.skillshare/` affect *all* the developer's repos, not just this one; make sure that's intended.
