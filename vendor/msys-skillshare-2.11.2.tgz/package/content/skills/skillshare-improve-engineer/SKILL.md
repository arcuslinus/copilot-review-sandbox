---
name: skillshare-improve-engineer
description: >
  Improve an existing coding engineer definition based on user feedback.
  Updates .skillshare/engineers/<name>.md with new conventions, recipes, or
  gotchas. Use when the user says "improve engineer", "update engineer",
  "fix engineer", "the engineer keeps doing X wrong", "add a convention to the
  engineer", or wants to refine how a coding engineer behaves. Also triggers when
  the user provides feedback about an engineer's incorrect behavior.
---

Improve an existing coding engineer definition based on feedback.

**Input**: The user typically describes what the engineer does wrong or what to add.

**Steps**

1. **Identify which engineer to update**

   If the user mentions a specific engineer name, use it. Otherwise:
   - List available engineers from `.skillshare/engineers/`
   - If only one exists, use it (confirm with user)
   - If multiple exist, use **AskUserQuestion** to let the user select

2. **Read the current definition**

   Read `.skillshare/engineers/<name>.md` to understand its current content.

3. **Understand the feedback**

   The user might say:
   - "It keeps using raw SQL instead of the ORM" → add a convention
   - "Add a recipe for creating a new migration" → add a step-by-step section
   - "It doesn't know about our error handling pattern" → add a conventions entry
   - "The project structure is outdated" → update the structure section
   - "It should always run tests after changes" → update verification section

   If the feedback is vague, ask clarifying questions.

4. **Read source code if needed**

   If the improvement requires understanding current codebase patterns
   (e.g., adding a new recipe), read the relevant source files first.

5. **Propose the update**

   Show a concise summary of what will change — do NOT dump the full file or large content blocks:
   - Which section(s) are being added or modified
   - A brief description of the new content (not the full text)
   - Why this addresses their feedback

   If the user wants to see the exact wording, show just the relevant snippet on request.
   Wait for user approval before writing.

6. **Apply and sync**

   Update `.skillshare/engineers/<name>.md` with the approved changes.
   Run `{{ runPrefix }} skillshare sync` to redistribute.

{% include "references/engineer-edit-principles.md" ignore missing %}

When wording the edit itself, follow:

{% include "references/writing-instructions.md" ignore missing %}

**Guardrails**
- Always show proposed changes before writing
- Keep edits minimal and well-placed per the principles above — add only what addresses the feedback
- If the feedback reveals a bigger issue (wrong scope, missing domain), suggest creating a new engineer instead
