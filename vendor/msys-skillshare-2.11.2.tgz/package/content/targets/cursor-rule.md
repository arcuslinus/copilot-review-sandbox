---
description: "Shared coding standards and conventions from @msys/skillshare"
alwaysApply: true
---
{{ managedHeader }}

{% include "instructions/base.md" -%}
