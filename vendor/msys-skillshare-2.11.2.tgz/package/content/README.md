# @msys/skillshare

Shared AI-asset distribution for MeisterSystems repositories. One package distributes skills, instruction
files, sub-agents, GitHub Actions workflows, and OpenSpec rules across every repo and every AI tool, so a
developer configures **one file** (`.skillshare/repo.yml`) instead of hand-maintaining `CLAUDE.md`,
`AGENTS.md`, `.cursor/…`, and a pile of workflows.

This page is the configuration reference for a consuming repo. For step-by-step setup see the
[onboarding guide](../docs/guides/onboarding-consumer-repo.md); for migrating a 1.x repo see
[`MIGRATION.md`](../MIGRATION.md).

## Quick start

```bash
skillshare init     # scaffold .skillshare/, wire postinstall, write the .gitignore block (no generated output yet)
# edit .skillshare/repo.yml — fill in variables, toggle features
skillshare sync     # render + write outputs to every tool dir (also runs automatically via postinstall)
skillshare check    # is this machine in sync? (run sync if it reports drift)
```

`init` produces **no** generated files — those come from `sync`. It scaffolds:

```
.skillshare/
├── repo.yml              # committed team config: schemaVersion + variables + enumerated features + commented examples
├── user.example.yml      # tracked example; copy to user.yml (gitignored) for personal deviations
├── skills/               # repo-local skills (override shared by name)        ┐
│   └── user/             # repo-user personal skills (gitignored)             │
├── agents/               # repo-local sub-agents (override shared by name)    │ each ships an
│   └── user/             # repo-user personal agents (gitignored)             │ explanatory
├── engineers/            # repo-local coding-engineer definitions             │ README.md;
│   └── user/             # repo-user personal engineers (gitignored)          │ each `user/`
├── instructions/         # instruction splice files (see "Customizing content") │ subfolder is
│   └── user/             #   user-instructions.md splice (gitignored)         │ gitignored via
├── openspec-rules/       # OpenSpec rule splice files (proposal/design/specs/tasks.md) │ .skillshare/*/user/
│   └── user/             # repo-user personal rule splices (gitignored)       │
└── targets/              # optional template overrides (advanced)             ┘
    └── user/             # repo-user personal template overrides (gitignored)
```

`init` also scaffolds the gitignored repo-user `user/` subfolders; the two personal content layers (repo-user
`.skillshare/<type>/user/` and global `~/.skillshare/` + `~/.skillshare/user.yml`, which apply to every repo you
sync) are documented in [Personal (gitignored) content](#personal-gitignored-content) below.

Plus a managed block in `.gitignore` and `"postinstall": "skillshare sync --yes"` in `package.json`.

## The config cascade

Configuration is a **four-layer cascade**; org defaults ship in the package, repos and developers write only
deviations:

```
content/global.yml          # org defaults (ships in the npm package — lowest layer)
  → .skillshare/repo.yml    # committed team deviations
    → ~/.skillshare/user.yml # gitignored per-developer deviations, EVERY repo (global-user)
      → .skillshare/user.yml # gitignored per-developer deviations, THIS repo (highest layer)
```

- **One schema, every key optional per file**; completeness is validated on the merged result.
- **Merge:** scalars/arrays replace wholesale, maps deep-merge, closer layer wins per key. No sticky bans — a
  closer `true` always beats a lower `false`.
- **Double resolution:** the *committed surface* (`global + repo`, used for the `.gitignore` block and
  `check --ci`) is resolved independently of every personal layer, so it is byte-identical on every machine.
  The *user surface* (what actually writes to disk) adds the two personal layers.
- **Global-user config** (`~/.skillshare/user.yml`) carries the full `user.yml` surface (tools,
  `toolDefinitions`, features, flags, variables, selection maps, `hooks.postSync`) and applies to **every** repo
  you sync; the repo-local `.skillshare/user.yml` still wins on a key collision. Both personal config layers are
  rejected if they set `content.<type>.committed` (the committed surface must stay user-independent).
- `content/features.yaml` defines what features *are*; the cascade decides what is *enabled*.

### `schemaVersion`

Every config file declares `schemaVersion` as its **bare first line** (no comment) — the durable detection key
for breaking config changes across future majors. The 2.0 major is `2`.

```yaml
schemaVersion: 2
```

| Layer | Carries it | Notes |
|---|---|---|
| `repo.yml` | always | written by `init` and the migrate skill |
| `.skillshare/user.yml` | when it has active (non-comment) keys | a fully-commented `user.yml` is version-agnostic |
| `~/.skillshare/user.yml` | when it has active keys | the global-user config layer; carries its own version stamp and is dropped (with a warning, never fatal) if stale |
| `global.yml` | always | ships with the CLI; for consistency. **Detection ignores its value** — it reads only the committed (`repo.yml`/legacy `config.yaml`) and personal (`user.yml`) surfaces |

The CLI compares each detected major to its built-in `CURRENT_SCHEMA_VERSION`: equal proceeds; *lower* is stale
(routes to `skillshare-migrate`); *higher* is refused (upgrade the pinned `@msys/skillshare`). A 1.x
`config.yaml` predates the field and is the implicit major `1`.

## Configuring `repo.yml`

### Variables

Explicit — skillshare infers nothing from `package.json`, the lockfile, or `.nvmrc`. Referencing an unsupplied
variable in output is a render error. `init` scaffolds the repo-specific ones as fill-in fields.

```yaml
variables:
  repoName: "my-repo"
  packageManager: "bun"
  runPrefix: "bun"
  nodeVersion: "22"
  formatCommand: "bun oxfmt"
```

| Variable | Set in | Used by | Required |
|---|---|---|---|
| `defaultBranch` | `global.yml` (`"main"`) | workflow push triggers | yes (org default) |
| `repoName` | `repo.yml` | instruction/rule context, Confluence workflows | yes |
| `packageManager` | `repo.yml` | postSync hook, workflow installs | yes |
| `runPrefix` | `repo.yml` | `openspec-*` skill CLI-prefix directives, skill instructions | yes |
| `nodeVersion` | `repo.yml` | workflow templates | yes |
| `formatCommand` | `repo.yml` | task rules (`formatStep`), coding standards | yes |
| `commitFormat` | `repo.yml` (optional) | the `git-*` commit skills' conventions partial (`instructions/commit-conventions/format.md`): `"commitlint-jira-type"` selects the dwmt commit/PR format, any other value or unset uses `(<TICKET-ID>) description` | no |
| `skillshareVersion` | auto (skillshare's own pkg) | workflow `@msys/skillshare@~…` pin — not user-overridable | auto |

`prMode` is no longer a variable — it is a feature **setting** (`features.git-commands.settings.prMode`), read in templates as `{{ settings.gitCommands.prMode }}`. See [Settings](#settings) below.

### Features

The `features:` block is the primary configuration surface — enabling a named set expands into the right
skills, workflows, agents, rules, and flag defaults. `init` writes a **fully enumerated** block (every feature
with its current default) so you see all options at a glance.

```yaml
features:
  skillshare-management: true
  onboarding-skill: true
  openspec-enhanced: true
  auto-docs: true
  ts-coding-standards: true
  review-triage: true
  coding-engineers: false
  ts7-lsp: false
  git-commands: true
  skillsets: false
```

| Feature | What it adds | Org default |
|---|---|---|
| `skillshare-management` | Self-management skills (`skillshare-create-skill`, `skillshare-modify`, `skillshare-migrate`, `skillshare-evaluate`) + hosts the opt-in `sync-check` gate (`pr-quality-assessment` workflow + `syncCheck` flag) | on |
| `onboarding-skill` | `skillshare-onboard` (disable after onboarding) | on |
| `openspec-enhanced` | Eight `openspec-*` skills, Confluence + PR-quality workflows, composed `openspec/config.yaml` via the `openspec-rules` artifact map + `openspec-context` | on |
| `auto-docs` | `docs-*` skills, `docs-research-agent`, docs→Confluence workflow | on |
| `ts-coding-standards` | Strict TS standards (no `!`, no `any`) | on |
| `review-triage` | `resolve-reviews`, `resolve-reviews-loop` | on |
| `coding-engineers` | Domain coding-engineer agents/skills + OpenSpec task mapping | off |
| `ts7-lsp` | The `typescript-lsp` plugin skill (Claude Code language server over the workspace `tsc --lsp`) + contributes `lspNavigation: true`. **Requires workspace `typescript` ≥ 7** — `tsc --lsp` does not exist below that, and the server silently fails to attach | off |
| `git-commands` | Six `git-*` skills carrying the repo's commit/PR conventions on-demand (commit, push, PR, cleanup) | on |
| `skillsets` | Background skillset dispatch engine (`dispatch` skill) — triage which post-implementation/verification follow-up skills apply to the current change and run the scheduled ones unattended as background sub-agents after showing a triage preview (no confirmation prompt); declares the `wrap-up` and `review` skillsets | off |

A feature value is a bare boolean or an override object (selection fields are `name: true|false` maps;
`openspec-rules: false`/`{}` drops the feature's rule map):

```yaml
features:
  auto-docs:
    enabled: true
    skills: { docs-init: false }          # drop one feature-provided skill
  openspec-enhanced:
    openspec-rules: false                 # keep the feature, suppress the rules block in openspec/config.yaml
  coding-engineers:
    enabled: true
    settings: { mode: skills }            # skill-only mode (no sub-agent delegation)
  git-commands:
    enabled: true
    settings: { prMode: always-draft }   # override a feature-contributed setting
```

### Settings

Settings are a feature's **validated enumerated choice** — the typed counterpart to boolean flags and free-form variables. A feature declares each setting's allowed `values` + `default` in `content/features.yaml`; a repo/developer overrides it under the feature object (`features.<name>.settings.<key>`, shown above), validated against those values, and reads it in templates as `{{ settings.<camelFeature>.<key> }}` (the feature name camel-cased, e.g. `{{ settings.gitCommands.prMode }}`). The shipped settings:

| Setting | Values (default) | Effect |
|---|---|---|
| `coding-engineers` › `mode` | `subagents` / `skills` (default `subagents`) | **only** how coding **engineers** are materialized — `subagents` renders them as sub-agent definitions (with delegation) on agent-capable tools, `skills` falls back to skills on all tools. Governs engineer delivery only (shared agents are controlled separately by `docsSubagent`). It does NOT gate engineer enumeration or assignment: `openspec/engineers.md`, the engineer task-assignment rule (top of `rules.tasks` in `openspec/config.yaml`), and the slice-granular TDD reconciliation are gated on coding engineers being **active** (the `coding-engineers` feature enabled + a non-empty resolved engineer set), since engineers remain assignable whether delivered as sub-agents or skills |
| `coding-engineers` › `modelTier` | `sm` / `md` / `lg` / `inherit` (default `inherit`) | Model tier coding-engineer sub-agents spawn at; resolves through the per-tool model map (see [Model tiers](#model-tiers)) |
| `git-commands` › `prMode` | `smart` / `always-ask` / `always-draft` / `always-ready` (default `smart`) | `git-commit-push-pr` draft/ready policy |

### Tools

`tools` is a selection **array** (replace semantics): absent = all defined tools; the dominant `user.yml` use
is "only the tools I use" (`tools: [claude]`). Each selected tool gets skills + a generated instruction file.

```yaml
tools: [claude, cursor, codex, gemini, github-copilot, opencode, dot-agents]
```

| Tool | Skills dir | Agents dir | Instruction file | Template |
|---|---|---|---|---|
| `claude` | `.claude/skills/` | `.claude/agents/` | `CLAUDE.md` | `plain` |
| `codex` | `.codex/skills/` | — | `AGENTS.md` | `plain` |
| `cursor` | `.cursor/skills/` | `.cursor/agents/` | `.cursor/rules/skillshare/RULE.md` | `cursor-rule` |
| `gemini` | `.gemini/skills/` | — | `AGENTS.md` | `plain` |
| `github-copilot` | `.github/skills/` | `.github/agents/` | `.github/copilot-instructions.md` | `plain` |
| `opencode` | `.opencode/skills/` | — | `AGENTS.md` | `plain` |
| `dot-agents` | `.agents/skills/` | — | `AGENTS.md` | `plain` |

> codex/gemini/opencode/dot-agents share `AGENTS.md` — rendered once and deduplicated; tools sharing an
> instruction file must declare the same `instructionTemplate`.

Tool definitions are **data** under `toolDefinitions` (a deep-merged map) — add a custom tool or override a
built-in field in any layer without a release:

```yaml
toolDefinitions:
  custom-agent:
    name: In-House Agent
    skillsDir: .custom-agent/skills
    agentsDir: .custom-agent/agents       # presence ⇒ agent support
    agentFileExt: .md
    instructionFile: .custom-agent/INSTRUCTIONS.md
    instructionTemplate: plain       # plain | cursor-rule | a repo-local target name
    # serverSideInstructions: true   # instruction file read server-side from the committed
    #                                # tree (committed by necessity; built-in: github-copilot)
```

#### Model tiers

Each tool may declare a `models` map binding the tiers `sm` (small/fast), `md` (mid), and `lg`
(large/most-capable) to that tool's concrete model identifiers. Per-tool-rendered content (skills, agents,
engineers) references a tier via the placeholders `{{ model.sm }}`, `{{ model.md }}`, `{{ model.lg }}`, or the
always-available `{{ model.inherit }}` (the literal `inherit` sentinel) — each resolves to the active tool's
model at render time, so the same template emits the right model for Claude, Codex, Gemini, etc. (Tier
placeholders are **not** available in the shared instruction files, which render deduplicated with no single
tool target.) Defaults are version-agnostic where the tool supports it; `opencode`/`dot-agents` ship no map and
resolve every tier to `inherit`. Override any tier in `repo.yml`/`user.yml` (the map deep-merges):

```yaml
toolDefinitions:
  claude:
    models: { sm: haiku, md: sonnet, lg: opus }   # override e.g. lg to pin a specific model
```

A reference to a tier a tool does not define resolves to `inherit`; if the tool defines *some* tiers but not
the requested one, sync emits a warning.

### Flags

Flags are **positive-named** booleans, each *declared with its default* by the content that consumes it
(instruction/rule template frontmatter, or a feature entry). The union of declarations is the closed set of
valid keys — an undeclared flag in config is a validation error. A `flags:` map in any layer holds deviations
only.

```yaml
flags:
  tddWorkflow: false   # drop the TDD bullets from task rules
  syncCheck: true      # opt into the CI sync-check job (off by default)
```

Resolution precedence (low → high): declared default → enabled-feature contribution → `global.yml` →
`repo.yml` → `user.yml`.

**Instruction flags** (declared in `content/instructions/base.md`, default `true`): `branchConventions`,
`formatCommandRule` (gates the "run the repo formatter before finishing" rule, now a general bullet under
`## Coding Standards & Instructions` rather than OpenSpec-gated), `userInteraction`. `lspNavigation` is also an
instruction flag but defaults to `false` (opt-in: set `flags: { lspNavigation: true }` to enable the
grep-vs-language-server guidance). Enabling the `ts7-lsp` feature **contributes** `lspNavigation: true`, so the
guidance (and the engineer LSP snippets from `references/lsp-navigation.md`) light up with the plugin; a repo that
runs some other language server can set the flag à la carte without the feature, and any cascade layer setting
`flags: { lspNavigation: false }` still wins over the contribution.

**Feature flags** (declared on a feature's `flags` map in `content/features.yaml`): `jiraPrefix`
(default `true`, on `openspec-enhanced`) gates the JIRA-ticket change-naming rule inside the
`openspec-new-change` / `openspec-propose` skills — it is no longer declared in `base.md`. (The flag
registry discovers flags from instruction/rule frontmatter and feature maps, not from skill frontmatter,
so a skill-consumed flag must be declared on the owning feature.) Other feature flags include
`qaInstructions` and `postMergeChecklist` (`openspec-enhanced`), `syncCheck` (`skillshare-management`),
`docsSubagent` (`auto-docs`), and `engineerReflection` (`coding-engineers`). Engineer delivery is a **setting**
(`coding-engineers` › `mode`), not a flag — see [Settings](#settings).

**Rule flags** (declared in the per-artifact rule template frontmatter, default `true`): `jiraConventions`,
`scopeBoundaries`, `appImpact`, `changeImpact` (proposal); `architecturePatterns`, `dataChanges` (design);
`acceptanceScenarios`, `apiContracts` (specs); `taskStructure`, `formatStep`, `tddWorkflow` (tasks).

**Feature-owned flags** (declared on the owning feature in `content/features.yaml`):

| Flag | Owning feature | Default | Gates |
|---|---|---|---|
| `docsSubagent` | `auto-docs` | `true` | how shared agents (`docs-research-agent`) are materialized for agent-capable tools — `true` renders them as sub-agent definitions, `false` falls back to skills. Independent of the engineer `mode` setting |
| `engineerReflection` | `coding-engineers` | `true` | the post-implementation `skillshare-engineers-reflect` invocation in `openspec-apply-change` (and the per-arm reflection-capture instructions) |
| `syncCheck` | `skillshare-management` | `false` | the **opt-in** `sync-check` job in `pr-quality-assessment` (enable with `flags: { syncCheck: true }`) — declared on the self-management feature because sync-check verifies skillshare's own committed surface |
| `worktreeScript` | `git-commands` | `false` | worktree removal in `git-worktree-cleanup` / `git-branch-cleanup` (and so `git-cleanup`) — `true` routes it through the repo's `{{ runPrefix }} worktree remove --name <dir> --force` teardown from the main checkout, `false` uses plain `git worktree remove --force`. Enable only in a repo that has a `worktree` package script whose `remove` tears down the worktree's isolated resources |
| `qaInstructions` | `openspec-enhanced` | `false` | with `skillsets` disabled: the **opt-in** final pre-merge QA task in `tasks.md` (the `/create-qa-instructions` invocation, rendered before the `auto-docs` `docs-revise` task). With `skillsets` enabled: a static membership toggle — `false` drops `create-qa-instructions` from the resolved `wrap-up` skillset member table instead of rendering a task — enable with `flags: { qaInstructions: true }` |
| `postMergeChecklist` | `openspec-enhanced` | `false` | with `skillsets` disabled: the **opt-in** pre-merge post-merge-checklist task in `tasks.md` (the `/create-post-merge-checklist` invocation). With `skillsets` enabled: a static membership toggle — `false` drops `create-post-merge-checklist` from the resolved `wrap-up` skillset member table instead of rendering a task — enable with `flags: { postMergeChecklist: true }` |

> Repo-local splice files (`.skillshare/instructions/*.md`, `.skillshare/openspec-rules/*.md`) may declare **new** flags
> in their frontmatter without a release. Duplicate declarations must agree on the default.

### Selection maps

`skills`, `github-workflows`, `agents`, and `engineers` are `name: true|false` maps everywhere (top-level and
per-feature): `true` force-includes, `false` force-excludes. With no entry, the default depends on the item's
source: a **repo-local** item (`.skillshare/skills|agents|engineers/<name>`) and a **personal** item
(`~/.skillshare/<type>/…` or `.skillshare/<type>/user/…`) are **enabled by presence** (drop the file in — no
entry needed), while a **shared-catalog** item is enabled only when a feature provides it. A `false` entry still
force-excludes a personal item. Engineers are repo-local/personal only, so every engineer present is on by
default and removed individually with `engineers: { <name>: false }`. An unknown name is a validation error
(typo safety); globs are not allowed.

```yaml
skills:
  docs-lookup: true                # force-include a shared skill no feature provides
  openspec-archive-change: false   # force-exclude even if a feature provides it
engineers:
  legacy-engineer: false           # drop one repo-local engineer (the rest stay on by presence)
```

### Content committedness

Whether a content type's outputs are committed is a cascade attribute. In 2.0 `github-workflows` and the managed
`.skillshare/README.md` are committed; everything else is gitignored and regenerated per machine — with one per-file
exception: the instruction file of a committed-selected tool with `serverSideInstructions: true` (built-in:
`github-copilot`) is committed by necessity regardless of the `instructions` type committedness.

| Content type | Source roots (low → high precedence) | Default committed | Output location |
|---|---|---|---|
| `github-workflows` | `content/github-workflows/` | `true` | `.github/workflows/skillshare-*.yml` |
| `readme` | `content/README.md` (static, no override roots) | `true` | `.skillshare/README.md` |
| `skills` | `content/skills/` < `.skillshare/skills/` < `~/.skillshare/skills/` < `.skillshare/skills/user/` | `false` | each tool's skills dir |
| `agents` | `content/agents/` < `.skillshare/agents/` < `~/.skillshare/agents/` < `.skillshare/agents/user/` | `false` | each agent-capable tool's agents dir |
| `engineers` | `.skillshare/engineers/` < `~/.skillshare/engineers/` < `.skillshare/engineers/user/` | `false` | agents dir (skill fallback otherwise) |
| `instructions` | `content/instructions/` < `.skillshare/instructions/` < `~/.skillshare/instructions/` < `.skillshare/instructions/user/` | `false` | each tool's instruction file |
| `openspec-rules` | `content/openspec-rules/` < `.skillshare/openspec-rules/` < `~/.skillshare/openspec-rules/` < `.skillshare/openspec-rules/user/` | `false` | `openspec/config.yaml` |

> The two highest roots (`~/.skillshare/<type>/` global-user and `.skillshare/<type>/user/` repo-user) are the
> gitignored **personal** layers — see "Personal (gitignored) content". `github-workflows` has no personal
> root. Personal outputs are never committed regardless of this column.

```yaml
content:
  skills: { committed: true }   # opt a type back into git (e.g. staged migration)
```

> `content.<type>.committed` may be set in `global.yml`/`repo.yml` only — setting it in `user.yml` is rejected
> (the committed surface must be user-independent).

### Hooks

```yaml
hooks:
  postSync: "{{ packageManager }} run format:fix"   # default (ships in global.yml)
  # postSync: false                                  # disable
```

Runs after writing files, before manifest hashing (so formatted files don't read as drift). Supports
`{{ variable }}` interpolation; a `<pm> run <script>` whose script is absent is silently skipped.

## Customizing content

You never edit generated/managed files — you edit sources, then `sync`:

- **Instruction splices** — drop repo-specific content into `.skillshare/instructions/`:

  | File | Rendered into | Purpose |
  |---|---|---|
  | `project-context.md` | Project Context | what the project *is* (domain, purpose) |
  | `technical-context.md` | Project Context + `openspec/config.yaml` context | how it's *built* (stack, commands) |
  | `coding-standards.md` | Coding Standards | rules beyond the feature sets |
  | `pr-labels.md` | the `git-commit-push-pr` skill's label step | repo-specific change-type → existing-label mapping (augments dynamic `gh label list` discovery; never creates labels) |

- **OpenSpec rule splices** — `.skillshare/openspec-rules/{proposal,design,specs,tasks}.md` (plain names). Each is read
  directly and injected into the matching composed template via a `{{ customRules }}` variable (not a
  `{% include %}`). They hold YAML list items, support Nunjucks vars/flag conditionals, and may declare new
  flags. Missing/empty files are silently ignored.

- **QA-generation guidance** — `.skillshare/references/qa-conventions.md` (optional). Used by the
  `create-qa-instructions` skill (the `openspec-enhanced` `qaInstructions` task) to add repo-specific
  QA-generation guidance — mandatory environments, required scenario types, house format rules. It is **spliced
  onto the end of** the skill's shipped defaults in `references/qa-conventions.md` at sync time (repo guidance is
  appended and wins on conflict) and is discovered **by presence** — no config entry. Absent ⇒ shipped defaults
  only.

### Shared template partials (`content/references/`)

`content/references/` holds **include-only** Nunjucks partials — reusable fragments with no frontmatter and no
synced output (so no content-type registry entry). They resolve via the existing `content/` loader root and are
pulled into composed templates with `{% include "references/<name>.md" ignore missing -%}`.

| Partial | Consumed by | Renders |
|---|---|---|
| `engineers-list.md` | the generated `openspec/engineers.md` output (via `planRulesItem`) | one bullet per item (the engineer `name` and `description`) in the injected `engineers` render variable |
| `engineer-edit-principles.md` | `skillshare-engineers-reflect`, `skillshare-improve-engineer` | the shared minimal-edit principles for editing `.skillshare/engineers/<name>.md`, spliced inline into both skills |
| `lsp-navigation.md` | coding engineers (`.skillshare/engineers/<name>.md`, at the end of `agent.instructions`; scaffolded by `skillshare-create-engineer`) | the LSP-first navigation note (go-to-definition/hover/find-references, grep still the completeness check) — self-gated on `flags.lspNavigation and target.id == "claude"`, so it renders to nothing with the flag off or on a non-Claude target |
| `writing-instructions.md` | `skillshare-create-skill`, `skillshare-modify`, `skillshare-create-engineer`, `skillshare-improve-engineer`, `skillshare-engineers-reflect`, `skillshare-setup-coding-engineers`, `skillshare-evaluate` | research-backed principles for writing instructions for an AI agent (affirmative, measurable, lean), spliced inline wherever a skill authors or edits instruction/prose content; also the rewrite standard for `skillshare-evaluate` R14 |
| `autonomy-contract.md` | the `dispatch` skill (embedded once, then carried into every member spawn prompt) | the shared autonomy contract for unattended execution — gate defaults, never ask, outcome reporting, hard-stop list — reusable beyond skillsets (e.g. a future session-wide autonomous mode) without duplicating its text |

The same include-only pattern is used for a couple of partials under `content/instructions/` (spliced via `{% include "instructions/<name>.md" %}`): `commit-conventions/format.md` (the git-\* commit/PR conventions, selected by `commitFormat`) and `workflow-routing.md` (the authoritative map of what information goes in `tasks.md`, the PR body, QA Instructions, or Post-Merge Items — spliced into `create-qa-instructions`, `create-post-merge-checklist`, and `git-commit-push-pr` so each check-producer emits only its own lane).

Beyond the config-supplied `variables:` (above), the sync engine injects a few **render-context variables** at
render time. Their availability varies by surface — see the **Available to** column: some inject into
rule/instruction templates (alongside `{{ customRules }}`), while others (e.g. `model`) appear only in per-tool
renders (skills, agents, engineers):

| Render variable | Type | Source | Available to | Currently consumed by |
|---|---|---|---|---|
| `engineers` | `{ name, description }[]` | the pipeline-resolved engineer set (the same set materialized as subagents or skills per `features.coding-engineers.settings.mode`); defaults to `[]` for other renders | skill + rule + instruction templates | `openspec-rules/tasks.md` (engineer-assignment rule gate + TDD reconciliation) and `references/engineers-list.md` (rendered into `openspec/engineers.md`) — the cascade-resolved coding engineers |
| `engineersListPath` | `string` | the single-sourced path of the generated engineer-list file (`openspec/engineers.md`); feeds both the rule text and the file generator so they cannot drift | rule templates | `openspec-rules/tasks.md` — the engineer task-assignment rule references this path instead of enumerating engineers inline |
| `model` | `{ sm, md, lg, inherit }` | the active tool's `toolDefinitions.<tool>.models` map, plus a synthesized `inherit`; built per tool. A missing tier resolves to `inherit` (warns if the tool defines some tiers but not that one) | per-tool renders only (skills, agents, engineers) — **not** shared instruction files | sub-agent `model:` frontmatter and any content that spawns a tiered sub-agent (e.g. `content/agents/docs-research-agent.md`) |

### OpenSpec rules surface

A feature declares two OpenSpec contributions in `content/features.yaml`: `openspec-context` (the instruction
file rendered into the generated config's `context`) and `openspec-rules` (an artifact-key → rule-filename map,
e.g. `{ proposal: proposal.md, design: design.md, specs: specs.md, tasks: tasks.md }`). Each map value resolves
to a shared template under `content/openspec-rules/<file>`, composed with the repo-local
`.skillshare/openspec-rules/<artifact>.md` splice. The map keys become the `rules:` keys in the generated
`openspec/config.yaml`. `config.yaml` is generated whenever a feature contributes context or rules: the
`schema` key is always emitted, `context` when `openspec-context` is declared, and the `rules` block only when
the merged map is non-empty.

> The skillshare-side vocabulary is `openspec-context`/`openspec-rules`; the **generated** `openspec/config.yaml`
> keys stay `schema`/`context`/`rules` (the OpenSpec contract) — the `openspec-*` names are skillshare-side only.

When coding engineers are **active** — the `coding-engineers` feature enabled with a non-empty resolved engineer
set — sync also emits a sibling **`openspec/engineers.md`** alongside `config.yaml` (rendered from
`references/engineers-list.md` over the resolved `engineers`). This is independent of delivery mode: the
`features.coding-engineers.settings.mode` setting only selects whether engineers ship as subagents or skills, not whether this file and the
engineer task-assignment rule are emitted. It is a managed `PlannedFile`, manifest-tracked, and **always gitignored / never committed** — a per-machine
derived artifact (as user-specific as `user.yml`) reflecting the developer's full resolution, personal engineers
included; it is sourced from the user surface regardless of any `content.*.committed` setting. The
top-of-`rules.tasks` engineer rule references it by path (`{{ engineersListPath }}`) instead of enumerating
engineers inline, so `config.yaml` carries only stable scalars and always parses. An empty resolved set (or the
feature disabled) emits neither the file nor the rule reference.
- **Repo-local skills / agents / engineers** — add `.skillshare/skills/<name>/`, `.skillshare/agents/<name>.md`,
  or `.skillshare/engineers/<name>.md`; the item is enabled by presence (no config entry needed) and removable
  with `<type>: { <name>: false }`. A repo-local item overrides a shared one of the same name. A `README.md`
  in any of these dirs is reserved and never synced as content.
- **Template overrides (advanced)** — a file under `.skillshare/targets/` shadows the same-named
  `content/targets/<name>.md` via the dual-root loader: a custom instruction template, or a custom
  `openspec/config.yaml` shape (`.skillshare/targets/openspec-config.yaml`).

### Personal (gitignored) content

Two **personal** content layers let a developer add content of every type without committing it. Both are
gitignored, synced by default (enabled by presence), and **never** influence committed outputs, the managed
`.gitignore` block, or `skillshare check --ci`. They are the content equivalent of the personal config layers.

Content resolves across four layers, lowest → highest precedence (closest-to-developer wins on a name
collision): `content/<type>/` (shared catalog) < `.skillshare/<type>/` (repo-local, committed) <
`~/.skillshare/<type>/` (global-user) < `.skillshare/<type>/user/` (repo-user). The last two are the personal
layers below.

| Layer | Source | Scope | Tag |
|---|---|---|---|
| **global-user** | `~/.skillshare/<type>/` (top level — no `user/` subfolder; the whole home dir is personal) + `~/.skillshare/user.yml` | every repo you sync | `global-user` |
| **repo-user** | `.skillshare/<type>/user/` | this repo only | `repo-user` |

- **Layout** — repo-user content lives in a `user/` subfolder of each type dir
  (`.skillshare/skills/user/<name>/`, `.skillshare/agents/user/<name>.md`,
  `.skillshare/instructions/user/`, `.skillshare/openspec-rules/user/<artifact>.md`,
  `.skillshare/targets/user/`). Global-user content mirrors it without the `user/` subfolder
  (`~/.skillshare/skills/<name>/`, …). `user` is therefore a **reserved name** in repo type dirs (handled like
  `README.md`).
- **Personal instructions are additive, not shadowing** — the composed instruction file gains two `ignore
  missing` anchors that append (rather than override-by-name): `.skillshare/instructions/user/user-instructions.md`
  (repo-user) and `~/.skillshare/instructions/global-user-instructions.md` (global-user). When
  `content.instructions.committed: true`, the committed instruction file is git-tracked, so these anchors are
  **inert** (a committed file cannot carry per-developer content).
- **Never committed** — a personal item's output is forced gitignored regardless of `content.<type>.committed`;
  if it would land in a committed output dir, its ignore goes to `.git/info/exclude` (per-clone, never
  committed), reusing the user-only-tool exclude path.
- **Excluded type** — `github-workflows` has no personal layer (`.github/workflows/` must be committed to run).

## Available skills

| Skill | Feature |
|---|---|
| `skillshare-create-skill`, `skillshare-modify`, `skillshare-migrate`, `skillshare-evaluate` | `skillshare-management` |
| `skillshare-onboard` | `onboarding-skill` |
| `openspec-new-change`, `openspec-propose`, `openspec-explore`, `openspec-continue-change`, `openspec-apply-change`, `openspec-verify-change`, `openspec-archive-change`, `openspec-sync-specs`, `create-qa-instructions` | `openspec-enhanced` |
| `docs-add`, `docs-audit`, `docs-init`, `docs-lookup`, `docs-revise` | `auto-docs` |
| `resolve-reviews`, `resolve-reviews-loop` | `review-triage` |
| `skillshare-setup-coding-engineers`, `skillshare-create-engineer`, `skillshare-improve-engineer`, `skillshare-engineers-reflect` | `coding-engineers` |
| `typescript-lsp` | `ts7-lsp` |
| `git-commit`, `git-commit-push`, `git-commit-push-pr`, `git-branch-cleanup`, `git-worktree-cleanup`, `git-cleanup` | `git-commands` |
| `dispatch` | `skillsets` |

**Skillset `skillset:` skill-frontmatter block** — a skill (shared, repo-local, or personal) joins a skillset
by declaring a `skillset:` block in its own frontmatter: `name` (must name a skillset declared by a feature's
`skillsets` map in `content/features.yaml`), `when` (the coarse triage condition evaluated at dispatch time),
`phase` (`work` default, or `publish`), `writes` (default `false` — writers serialize within the work
phase), `runsOn` (`any` default, `main`, or `subagent` — execution-lane placement in `subagents` mode), and
`modelTier` (`sm`/`md`/`lg`/`inherit`, no default — the model tier for the member's spawned sub-agent, falling
through to the `skillsets.modelTier` feature setting when unset). The value may be a single block or an array of
blocks for multi-skillset membership, one block per skillset, each with its own `when`. Unlike the `agent:`
block below, this is a **closed** schema — unknown keys are rejected. The block is stripped from every rendered
tool output; it exists only for `skillshare skillset <name> --json` to resolve skillset membership, and it is
inert when `skillsets` is disabled. The shipped skillsets and their members' `when:` conditions are declared on
`create-qa-instructions`, `create-post-merge-checklist`, `docs-revise`, `git-commit-push-pr` (`wrap-up`) and
`openspec-verify-change`, `resolve-reviews-loop` (`review`). Every member spawn is run under the shared
`content/references/autonomy-contract.md` reference (gate defaults, never ask, outcome reporting, hard-stop
list), embedded in the `dispatch` skill rather than restated.

> `typescript-lsp` is a **plugin-style** skill: it ships `.claude-plugin/plugin.json` + `.lsp.json` and no
> `SKILL.md`, so it is never prompted or listed as an invocable skill — Claude Code auto-registers the folder in its
> skills dir as a plugin and attaches the language server at session start. Non-`.md` skill files sync **verbatim**
> (no managed header, no rendering), so the literal `${CLAUDE_PROJECT_DIR}` in `.lsp.json` survives and Claude Code
> substitutes it at runtime. The two files also land inert in non-Claude tools' skills dirs.

## Available agents & workflows

Shared agents sync to agent-capable tools (skill fallback otherwise); `flags.docsSubagent: false` forces
skill-only output (the engineer `mode` setting governs coding engineers only).

**Agent/engineer `agent:` block contract** — the `agent:` frontmatter block is open: `tools`, `model`, and
`instructions` carry special semantics (tool list, model tier placeholder, persona preamble); any other key
inside the `agent:` block (e.g. `skills: [my-skill]`) passes through verbatim into the rendered agent
definition on every agent-capable tool. Unknown keys are NOT validated — a typo rides through as a visible
dead key (intentional). This passthrough applies only inside `agent:` — top-level frontmatter (`description`,
etc.) remains closed and validated. The skill-fallback path drops the whole `agent:` block.

| Agent | Feature |
|---|---|
| `docs-research-agent` | `auto-docs` |

Workflows render to `.github/workflows/skillshare-<name>.yml` (committed outputs — see Content committedness above):

| Workflow | Feature | Jobs / purpose |
|---|---|---|
| `pr-quality-assessment` | `openspec-enhanced` + `auto-docs` + `skillshare-management` | `openspec-check`, `docs-check`, opt-in `sync-check` (`flags.syncCheck`); a `no-checks-enabled` no-op renders if none are active |
| `openspec-to-confluence` | `openspec-enhanced` | publish OpenSpec changes/specs to Confluence |
| `docs-to-confluence` | `auto-docs` | publish `docs/` to Confluence |

The Confluence + sync-check jobs authenticate to AWS CodeArtifact via GitHub OIDC (role
`skillshare-managed-workflows`, trust-locked to the `skillshare-` workflow prefix). One-time per AWS
account/GitHub org: deploy `infra/` (`bunx cdk deploy GithubActionRunnersStack`) and set the org Actions
variable `SKILLSHARE_AWS_ROLE_ARN`. Per repo: a `package.json` `npm:login` script
(`aws codeartifact login --namespace=@msys --tool npm --repository msys-npm --domain msys`).

## Committed vs gitignored

`sync` maintains a managed block in `.gitignore` computed from the **committed surface** (`global + repo`, never
`user.yml`), so outputs are untracked identically on every machine. Patterns are **derived** from each defined
tool's structural fields — `skillsDir`/`agentsDir` → `<dir>/*`, `instructionFile` → `/<file>` — gated by each
content type's committedness, plus fixed paths (`/openspec/config.yaml` when `openspec-rules` is not committed,
`.skillshare/README.md` only when `readme` is flipped off — `readme` is committed by default — and the
always-ignored `.skillshare/manifest.user.json`, `.skillshare/user.yml`, and `.skillshare/*/user/` — the latter one
rule covers every repo-user personal type dir). Patterns are **narrow**
(`.claude/skills/*`, `/CLAUDE.md`) — skillshare ignores only what it generates, so user-owned files in a tool
dir (e.g. `.claude/settings.json`) stay tracked.

**Committed:** `.skillshare/repo.yml`, `.skillshare/user.example.yml`, the managed `.skillshare/README.md`, the
splice files + repo-local dir `README.md`s, the committed lockfile `.skillshare/manifest.json`, the
`.gitignore`/`.gitattributes` managed blocks, `.github/workflows/skillshare-*.yml`, and — when `github-copilot` is
committed-selected (the default) — `.github/copilot-instructions.md` (read server-side by GitHub's Copilot reviewer).
**Gitignored (regenerated per machine):** instruction files (except the committed Copilot file above), tool skill/agent dirs, `openspec/config.yaml`,
`openspec/engineers.md`, `.skillshare/manifest.user.json`, `.skillshare/user.yml`, and the personal content tree
`.skillshare/*/user/` (the global-user layer lives outside the repo, in `~/.skillshare/`).

Managed files carry a header (`<!-- Managed by @msys/skillshare … -->`); the manifests track SHA-256 hashes for
drift detection and stale-file cleanup — the committed lockfile `.skillshare/manifest.json` (committed-surface
entries) and the per-machine `.skillshare/manifest.user.json`. Opt out of the
`linguist-generated` `.gitattributes` block with `gitattributes: false`.

## Bootstrap (postinstall)

Because outputs are gitignored, each machine regenerates them through its install step:
`"postinstall": "skillshare sync --yes"` (wired by `init`/`skillshare-migrate`, chained after any existing script;
`--yes` keeps the install-time sync non-interactive).
A short README pointer tells developers the AI files are skillshare-managed and appear after install. Pin the
exact `@msys/skillshare` version — the pin is what keeps output identical everywhere. If you pull a pin bump
without reinstalling, any `skillshare` command stops with a version-pin error (bypass with
`--no-version-check`).

## CLI commands

| Command | Description |
|---|---|
| `skillshare init` | scaffold `.skillshare/`, wire postinstall, write the `.gitignore` block |
| `skillshare init --empty` | minimal `repo.yml` (no comments/examples) |
| `skillshare sync` | resolve cascade, render, write outputs, update `.gitignore`/manifest |
| `skillshare sync -y` | auto-confirm overwrite prompts (CI) |
| `skillshare check` | local: is **this machine** stale? |
| `skillshare check --ci` | CI: do **committed** outputs match the **committed** config? (deterministic) |
| `skillshare ci confluence <cmd>` | Confluence publishing pipeline utilities |
| `skillshare ci pr-quality <cmd>` | PR quality gate utilities |

## Migrating from 1.x

The 1.x layout (`.skillshare/config.yaml`, committed outputs) is implicit major `1` and not 2.0-compatible.
There is **no final 1.x release** — 2.0 self-bootstraps: on a stale layout, `sync` (incl. via postinstall)
places the `skillshare-migrate` skill, prints a pointer, skips the sync, and exits `0`; `check --ci` refuses
non-zero. Run the `skillshare-migrate` skill (an evergreen, never-auto-disabled orchestrator that reads the
packaged [`MIGRATION.md`](../MIGRATION.md)) — it transforms `config.yaml` into a `repo.yml` built from the
commented template, converts `disable*` flags to positive names and include/exclude lists to selection maps,
moves custom rules into `.skillshare/openspec-rules/<artifact>.md`, scaffolds the repo-local dirs + `user.example.yml`,
and un-tracks the now-gitignored managed paths. `MIGRATION.md` is also the manual fallback.
