# `.skillshare/skills/`

Repo-local skills. Drop skill definitions here to add skills that aren't in the
shared catalog, or to override a shared skill of the same name.

- One directory per skill: `.skillshare/skills/<skill-name>/SKILL.md` (plus any
  supporting files the skill references).
- A repo-local skill is **enabled by presence** — dropping the directory here
  syncs it; no config entry is needed. Exclude one with `skills: { <name>: false }`
  in `repo.yml` or `user.yml`.
- A repo-local skill **overrides** the shared catalog skill of the same name —
  the local copy wins.
- This `README.md` is **never synced as content**: the catalog resolver reserves
  and skips the `README.md` name, so it is documentation only.
