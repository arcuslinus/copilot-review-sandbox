# `.skillshare/targets/`

Repo-local target templates. Files here **shadow** the shipped templates in
`content/targets/<name>.md` via the dual-root template loader (`.skillshare/`
is searched before `content/`), so you can customize how outputs are rendered
without a skillshare release.

- Custom instruction templates: shadow a built-in template name (e.g.
  `plain.md`, `cursor-rule.md`), or supply a new one referenced by a tool's
  `toolDefinitions.<tool>.instructionTemplate`.
- The openspec-config format: shadow `openspec-config.yaml` to customize the
  generated `openspec/config.yaml`. Note its name, output path, and context
  (`managedHeader`, `rulesContext`, `hasRules`, `rulesArtifacts`)
  are fixed, and it is feature-gated.
- This `README.md` is documentation only — `targets/` is loader-resolved (not a
  content type), so the README is never rendered or synced.
