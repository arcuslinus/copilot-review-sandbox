# `.skillshare/agents/`

Repo-local agents. Drop agent definitions here to add agents that aren't in the
shared catalog, or to override a shared agent of the same name.

- One file per agent: `.skillshare/agents/<agent-name>.md` (YAML frontmatter with
  a `description` and an `agent` block, plus the markdown body).
- A repo-local agent is **enabled by presence** — dropping the file here syncs it;
  no config entry is needed. Exclude one with `agents: { <name>: false }` in
  `repo.yml` or `user.yml`.
- A repo-local agent **overrides** the shared catalog agent of the same name —
  the local copy wins.
- This `README.md` is **never synced as content**: the catalog resolver reserves
  and skips the `README.md` name, so it is never resolved as an agent.
