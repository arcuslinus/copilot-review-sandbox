{# Repo-specific design rules. Automatically spliced into the end of the shared
   design rules (content/openspec-rules/design.md) when the rules output is generated.

   Each line should be a YAML list item (starting with "- ").
   You may use template variables ({{ runPrefix }}, {{ formatCommand }}, …) and
   flag conditionals ({% if flags.x %}), and declare new flags in frontmatter.

   Delete these comments and replace with your content,
   or leave the file empty — empty files are silently ignored. #}
