{# Repo-specific task rules. Automatically spliced into the end of the shared
   task rules (content/openspec-rules/tasks.md) when the rules output is generated.

   Each line should be a YAML list item (starting with "- ").
   You may use template variables ({{ runPrefix }}, {{ formatCommand }}, …) and
   flag conditionals ({% if flags.x %}), and declare new flags in frontmatter.

   Example:
   - Check for infrastructure changes and flag if CloudFormation/CDK updates are needed

   Delete these comments and replace with your content,
   or leave the file empty — empty files are silently ignored. #}
