# `.skillshare/engineers/`

Repo-local coding engineers — the specialized coding-agent content type. Drop
engineer definitions here to add repo-specific coding agents.

- One file per engineer: `.skillshare/engineers/<engineer-name>.md` (YAML
  frontmatter plus the markdown body).
- An engineer is **enabled by presence** — dropping the file here syncs it; no
  config entry is needed. Exclude one with `engineers: { <name>: false }` in
  `repo.yml` or `user.yml`.
- This `README.md` is **never synced as content**: the catalog resolver reserves
  and skips the `README.md` name, so it is never resolved as an engineer.
