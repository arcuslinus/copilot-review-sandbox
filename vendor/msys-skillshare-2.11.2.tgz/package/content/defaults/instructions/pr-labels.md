{# Optional repo-specific PR label mapping for the git-commit-push-pr skill.
   Spliced into the skill's label step alongside the dynamic `gh label list`
   discovery — it does not replace it.

   Use this to spell out explicit rules for how change types map to THIS repo's
   labels, so the skill picks the right ones without re-inferring each time.
   Only reference labels that already exist in the repo — the skill never creates
   labels, and an unmatched mapping simply falls back to a label-less PR.

   Examples of what belongs here:
   - "Dependency bumps (package.json / lockfile only) → `dependencies`"
   - "Changes under `docs/` → `documentation`"
   - "Bugfix branches (`fix/*`, `bug/*`) → `bug`"
   - "Anything touching `infra/` → `infra`, plus `needs-deploy`"

   Delete these comments and replace with your content,
   or leave the file empty — empty files are silently ignored. #}
