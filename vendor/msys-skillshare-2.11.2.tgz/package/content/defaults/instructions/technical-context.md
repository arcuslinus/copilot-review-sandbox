{# How the project is built — tech stack, architecture, system topology.
   Appears under "Project Context" in instruction files AND as the
   context block in the generated openspec/config.yaml.

   Examples of what belongs here:
   - Frameworks, databases, infra (Express, PostgreSQL, SNS/SQS, ...)
   - System architecture (monorepo structure, service topology)
   - Build, test, and CI commands and patterns

   Delete these comments and replace with your content,
   or leave the file empty — empty files are silently ignored. #}
