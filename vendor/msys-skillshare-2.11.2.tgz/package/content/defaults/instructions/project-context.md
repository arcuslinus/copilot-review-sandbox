{# What this project IS — purpose, business domain, high-level description.
   Appears under "Project Context" in all instruction files.

   Examples of what belongs here:
   - "Enterprise SaaS platform for ..."
   - "Turbo monorepo with 20+ apps and 89+ shared libraries"
   - Team structure, ownership boundaries

   Delete these comments and replace with your content,
   or leave the file empty — empty files are silently ignored. #}
