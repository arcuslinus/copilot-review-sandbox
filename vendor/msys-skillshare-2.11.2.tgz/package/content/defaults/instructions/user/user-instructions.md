{# Personal (repo-user) instructions — YOURS only, only in THIS repo.

   Its content is APPENDED to your generated instruction file (e.g. CLAUDE.md)
   on sync, after all shared instruction content — it does not shadow any shared
   splice. The base template references it through the dynamic
   `repoUserInstructionsInclude` anchor, which (on the user surface) resolves to
   this file at the loader path `instructions/user/user-instructions.md`.

   It lives under the gitignored `.skillshare/instructions/user/` subfolder, so
   it is never committed, never affects `skillshare check --ci`, and never
   appears in another developer's outputs. For preferences that should follow
   you across every repo, use `~/.skillshare/instructions/global-user-instructions.md`
   instead.

   NOTE: when `content.instructions.committed` is `true`, the instruction file
   is git-tracked and these personal anchors are inert (a committed file cannot
   carry per-developer content).

   Examples of what belongs here:
   - Personal workflow reminders ("run my local lint script before committing")
   - Tone/format preferences for this repo's AI tools
   - Scratch context you don't want to share with the team

   Delete these comments and replace with your content,
   or leave the file empty — empty files are silently ignored. #}
