{# How to write code in this project — repo-specific rules beyond what
   feature sets provide (ts-coding-standards covers no-!, no-any).
   Appears under "Coding Standards & Instructions" in all instruction files.

   Examples of what belongs here:
   - Type-check commands (e.g. how to run tsc for specific packages)
   - Import conventions (file extensions, cross-package rules)
   - Framework-specific rules (e.g. "use Kysely, not raw SQL")
   - Testing patterns (e.g. unit test file naming, integration test folders)

   Delete these comments and replace with your content,
   or leave the file empty — empty files are silently ignored. #}
