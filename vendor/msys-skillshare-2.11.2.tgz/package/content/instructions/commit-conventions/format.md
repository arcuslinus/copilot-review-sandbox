{%- if commitFormat == "commitlint-jira-type" %}
{% include "instructions/commit-conventions/jira-type.md" -%}
{%- else %}
- Commit message & pull request format: `(<TICKET-ID>) description` (e.g. `(MEIS-12179) initialize OpenSpec`)
{%- endif %}
- Always include the JIRA ticket ID from the current branch name
- Never add a Co-Authored-By trailer
