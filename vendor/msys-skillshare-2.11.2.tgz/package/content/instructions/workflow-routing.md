Every action or note produced during a change has exactly one home. When producing any one
of these outputs, emit **only your own lane**; anything that belongs to another lane is
named-and-redirected for the user, never written into your output — even if that other lane
is currently disabled (then it goes nowhere, by design; never absorb it to "rescue" it).

<!-- prettier-ignore -->
| Destination | Holds |
| --- | --- |
| `tasks.md` | Work to BUILD the change — completable before merge. |
| PR body | What changed + why; technical pre-merge verification — from the code, diff, branch, a build/test run, a CLI, or logs. |
| QA Instructions | Functional scenarios a NON-TECHNICAL tester runs in the product on whichever environment carries this change. No code / CLI / diff / logs — ever. |
| Post-Merge Items | Actions only possible once the merged code is live in prod / a shared environment. |
| → follow-up ticket | New or separate scope this change merely surfaced. |

Work vs. context route themselves (build → `tasks.md`; what/why → PR body). All the real
confusion is among the three **CHECK** destinations — decide with:

```
A CHECK →  done only after merge (needs merged code live)? ── yes ─► Post-Merge Items
           │ no (doable before merge)
           └─ a non-technical tester can do it in the product UI? ── yes ─► QA Instructions
                                                                     no  ─► PR body (verification)
```

The QA persona settles the QA↔PR line mechanically: any step that touches code, a CLI, a
file path, a diff, or logs is by definition **not** QA — it is PR verification.

- **Void, not fallback.** A producer emits only its own lane. Items for another lane are
  redirected or dropped — never absorbed into a sibling lane, and a producer never inspects
  another lane's feature state to decide whether to rescue an item. If the owning lane is
  disabled, the item goes to void.
- **Per-action, not per-topic.** One subject can land in several lanes: a migration gives
  "write the migration" (`tasks.md`), "confirm it applied in prod" (Post-Merge Items), and
  "the records screen still loads" (QA Instructions) — three actions, three homes.
- **Redirect is surfaced, not silent.** A skill that drafts a Jira comment and spots an
  out-of-lane candidate mid-draft names the destination it belongs to during draft review,
  while omitting it from the posted output.
