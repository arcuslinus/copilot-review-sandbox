**Writing instructions for an AI agent — above all, keep them short and precise.** Use the smallest set of high-signal tokens that fully specifies the behavior: one or two sentences per rule, and cut any sentence whose removal wouldn't change what the agent does. Apply when writing or editing any instruction, skill body, or prompt:

- **Say what to do, not what to avoid** — a bare prohibition leaves nothing to aim at; if you must prohibit, give the reason.
- **Prefer measurable constraints over vague adjectives** — "answer in ≤3 sentences" beats "be concise".
- **Lead with the imperative; add the reason only when it isn't obvious.**
- **Aim for the right altitude** — concrete enough to give a clear signal, general enough to avoid brittle edge-case lists; prefer one canonical example over a list of caveats.
- **Make examples mirror the exact behavior you want, and match the document's own style to the output.**
- **Use direct phrasing, not shouting** — "Use this tool when…", not "CRITICAL: you MUST…".
