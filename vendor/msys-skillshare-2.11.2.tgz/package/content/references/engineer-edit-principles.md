**Engineer-edit principles** (the bar for any change to `.skillshare/engineers/<name>.md`):

- Edits are **minimal, surgical, and well-placed**. Touch the smallest amount of text that captures the improvement, and put it in the section it belongs to.
- **Prefer tightening an existing line over adding a new section.** A clarified sentence almost always beats a new heading.
- **Never restructure the file to add a single convention.** Reorganizing sections to fit one note is out of scope.
- **Ground every edit in actual codebase patterns and what happened during the work** — not generic best-practice advice.
- **Reject suggestions that merely restate the diff or are speculative.** If a note just narrates what was done, or guesses at future needs that did not come up, drop it.
