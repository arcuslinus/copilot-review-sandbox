{%- if flags.lspNavigation and target.id == "claude" %}
Prefer the LSP tool for code navigation (go-to-definition, hover types, find references); a whole-tree text search (ripgrep, grep, or a faster equivalent) remains the authoritative completeness check for exhaustive reference sweeps.
{%- endif %}
