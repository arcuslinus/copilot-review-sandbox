# @msys/skillshare — Migration Guide

This document ships **inside the npm package** at the package root (`MIGRATION.md`).
It is the version-specific playbook read by the evergreen `skillshare-migrate`
skill. The skill itself contains no migration steps — all transition-specific
knowledge lives here.

> **Audience.** This guide is written for an AI agent executor. Steps are
> deterministic; decision points are called out explicitly; each phase ends with
> a verification gate. Do not improvise — if a step's precondition is not met,
> stop and report rather than guessing.

## How this guide is organized

Migration is driven by a `schemaVersion` integer (config-schema major), not by
filenames. The CLI holds the major it supports as a built-in constant
(`CURRENT_SCHEMA_VERSION`). A 1.x `config.yaml` predates the field and is the
**implicit** major `1`; a `repo.yml`/`user.yml` declares its `schemaVersion`
explicitly.

This document has **one section per (transition × surface)**. The skill detects
the gap and the stale surface(s) and reads the matching section:

| Transition | Surface                          | Section                                                             |
| ---------- | -------------------------------- | ------------------------------------------------------------------- |
| `1 → 2`    | committed (legacy `config.yaml`) | [1 → 2 (committed surface)](#1--2-committed-surface)                |
| `2 → 3+`   | `repo.yml` and/or `user.yml`     | [2 → 3+ (config-schema transforms)](#2--3-config-schema-transforms) |

`1 → 2` is the one **structural** transition (un-track outputs, wire postinstall,
write the gitignore block, `config.yaml` → `repo.yml`). Every later transition is
a **pure config-schema transform** — no re-untracking, no postinstall wiring
(outputs are already gitignored).

Output-behavior changes shipped in **minor** releases — no schema transition, so
the migrate skill is not involved — are collected in
[Minor upgrades within schema major 2](#minor-upgrades-within-schema-major-2).

---

## 1 → 2 (committed surface)

Skillshare 2.0 replaces the single committed `.skillshare/config.yaml` with a
three-layer config cascade and gitignores all generated outputs except GitHub
workflows. A repo on the 1.x layout (`.skillshare/config.yaml` present, no
`.skillshare/repo.yml`) is the **implicit schema major `1`** and is detected as a
stale committed surface by 2.0 `sync`/`check` until migrated. The produced
`repo.yml` carries `schemaVersion: 2`.

### Layout detection

| Marker present                                           | Schema major        | Action                                                                |
| -------------------------------------------------------- | ------------------- | --------------------------------------------------------------------- |
| `.skillshare/config.yaml`, **no** `.skillshare/repo.yml` | implicit `1`        | Run this 1 → 2 migration                                              |
| `.skillshare/repo.yml`                                   | its `schemaVersion` | If `2`, already current — stop; if `< 2`, run the matching transition |
| neither                                                  | —                   | Not a migration — run `skillshare init`                               |

### What changes

- `.skillshare/config.yaml` → `.skillshare/repo.yml`, **built from the commented
  `content/defaults/repo.yml` template** (comments preserved); deviations-only
  except the `features:` block, which fully enumerates every feature. Org defaults
  now ship in the package's `global.yml`.
- `disable*`/`enable*` flags → positive names.
- `skills`/`workflows` `include`/`exclude` glob lists → `name: true|false`
  selection maps (no globs); the `workflows` selection map is renamed to
  `github-workflows` (1g/1e).
- `variables` carried over **unchanged** (2.0 performs no inference).
- 1.x per-artifact `rules` arrays → content moved into flat plain-named
  `.skillshare/openspec-rules/<artifact>.md` splice files (no `custom-` prefix).
- Generated outputs (skills, agents, engineers, instructions, rules) become
  **gitignored** via a narrow, derived managed `.gitignore` block; only
  `.github/workflows/skillshare-*.yml` stay committed.
- Repo-local scaffolding is brought up to a fresh-`init` shape: any missing
  `.skillshare/{skills,agents,engineers,instructions,openspec-rules,targets}/`
  subdirectories are created with their explanatory `README.md` files, and a
  tracked `.skillshare/user.example.yml` is placed (no gitignored `user.yml` is
  created).
- A `postinstall` hook regenerates outputs on every install.

---

## Phase 0 — Preconditions (verify before touching anything)

1. Confirm the surface is the **implicit major `1`**: `.skillshare/config.yaml`
   exists and `.skillshare/repo.yml` does **not**. If `repo.yml` exists, read its
   `schemaVersion` instead — if it is `2`, **stop** (already current); if it is
   lower than `2`, this is a different transition (see the `2 → 3+` section shape).
2. Confirm `.skillshare/manifest.json` exists. It is the authoritative list of
   committed 1.x managed files used for un-tracking (Phase 3). If it is missing,
   **stop and report** — do not invent the list.
3. Confirm the working tree is **effectively** clean for migration purposes.
   `sync` self-placed this very skill to bootstrap the migration, so the tree is
   never literally clean — `git status --porcelain` will show untracked
   `**/skills/skillshare-migrate/` directories (and possibly other freshly
   sync-placed or 2.0-gitignored outputs). **Exclude those expected sync-placed
   paths from the cleanliness check** and do **not** warn about this skill's own
   presence — it is there by design. Only genuine unrelated changes (edits or new
   files the developer made) block the migration; if any are present, ask the user
   to commit or stash them first so the post-migration `git diff` stays reviewable.
4. Read `.skillshare/config.yaml` in full. Real configs contain comments and
   judgment calls — preserve intent, not just keys.

**Gate:** all four hold, or stop.

---

## Phase 1 — Transform `config.yaml` → `repo.yml` (+ repo-local scaffolding)

**Start from the commented template.** Copy `content/defaults/repo.yml` (the
commented starter shipped in the installed package) as the basis for
`.skillshare/repo.yml`, preserving its explanatory comments, then fill in this
repo's values. Apart from the `features:` block (which fully enumerates every
feature — see 1f), `repo.yml` holds only this repo's **deviations**. Do **not**
copy org defaults (tool definitions, committedness, hooks) — those live in the
package's `global.yml` and apply through the cascade.

### 1a. Schema version — always present

The produced `repo.yml` declares the 2.0 config-schema major as its bare first
line (no attached comment); the template already carries it:

```yaml
schemaVersion: 2
```

This is the durable detection key for future migrations; `skillshare init` writes
it too. The 1.x `config.yaml` had no such field (it is the implicit major `1`).

### 1b. Variables — carry over unchanged

Copy the entire `variables:` map verbatim. 2.0 infers nothing from
`package.json`, the lockfile, or `.nvmrc`, so every value the templates reference
must remain explicit.

```yaml
# config.yaml (1.x)            →    repo.yml (2.0)
variables:                          variables:
  repoName: my-repo                   repoName: my-repo
  packageManager: pnpm                packageManager: pnpm
  runPrefix: pnpm                     runPrefix: pnpm
  nodeVersion: "20"                   nodeVersion: "20"
  formatCommand: "pnpm oxfmt"         formatCommand: "pnpm oxfmt"
```

`commitFormat` (if present) carries over unchanged. `defaultBranch` ships in
`global.yml`; keep it in `repo.yml` only if the 1.x config overrode it (e.g.
`master`).

### 1c. Tools — omit from `repo.yml` (default to all)

Do **not** carry the 1.x `tools:` list into `repo.yml`. Omit `tools:` entirely so
the repo baseline defaults to **all** defined tools (absent = all defined tools).
A developer who only uses some tools narrows them in their personal, gitignored
`.skillshare/user.yml` (e.g. `tools: [claude]`, replace semantics) — not in the
committed `repo.yml`. The seven built-in tool **definitions** ship in `global.yml`;
do not re-declare them in `repo.yml`.

(If a 1.x repo deliberately narrowed `tools:` at the team level and you want to
preserve that team-wide choice, keep the list in `repo.yml`. The default for a
migration, however, is to omit it — tool selection is a per-developer preference.)

### 1d. Flags — rename to positive names

1.x flags are opt-out (`disable*`/`enable*`); 2.0 flags are positive and
declared with their defaults by the content that consumes them. Invert each
flag's sense when renaming: a 1.x `disableX: true` becomes the 2.0 positive flag
set to `false`; `enableSyncCheck` becomes `syncCheck` (default `false` in 2.0,
i.e. opt-in — see the conversion rule below). **Only
emit flags that deviate from the 2.0 default** — drop any 1.x flag that was left
at its default.

| 1.x flag                      | 2.0 flag               | 2.0 default | Declared in                                   |
| ----------------------------- | ---------------------- | ----------- | --------------------------------------------- |
| `disableBranchConventions`    | `branchConventions`    | `true`      | `content/instructions/base.md`                |
| `disableCommitConfirmation`   | `commitConfirmation`   | `true`      | `content/instructions/base.md`                |
| `disableJiraPrefix`           | `jiraPrefix`           | `true`      | `content/instructions/base.md`                |
| `disableFormatCommand`        | `formatCommandRule`    | `true`      | `content/instructions/base.md`                |
| `disableUserInteraction`      | `userInteraction`      | `true`      | `content/instructions/base.md`                |
| `disableJiraConventions`      | `jiraConventions`      | `true`      | `content/openspec-rules/proposal.md`          |
| `disableScopeBoundaries`      | `scopeBoundaries`      | `true`      | `content/openspec-rules/proposal.md`          |
| `disableAppImpact`            | `appImpact`            | `true`      | `content/openspec-rules/proposal.md`          |
| `disableChangeImpact`         | `changeImpact`         | `true`      | `content/openspec-rules/proposal.md`          |
| `disableArchitecturePatterns` | `architecturePatterns` | `true`      | `content/openspec-rules/design.md`            |
| `disableDataChanges`          | `dataChanges`          | `true`      | `content/openspec-rules/design.md`            |
| `disableAcceptanceScenarios`  | `acceptanceScenarios`  | `true`      | `content/openspec-rules/specs.md`             |
| `disableApiContracts`         | `apiContracts`         | `true`      | `content/openspec-rules/specs.md`             |
| `disableTaskStructure`        | `taskStructure`        | `true`      | `content/openspec-rules/tasks.md`             |
| `disableFormatStep`           | `formatStep`           | `true`      | `content/openspec-rules/tasks.md`             |
| `disableTddWorkflow`          | `tddWorkflow`          | `true`      | `content/openspec-rules/tasks.md`             |
| `disableSubagents`            | `subagents`            | `true`      | `content/features.yaml` (`coding-engineers`)  |
| `enableSyncCheck`             | `syncCheck`            | `false`     | `content/features.yaml` (`openspec-enhanced`) |

> Two renames are not a mechanical `disable→positive` strip:
> `disableFormatCommand` → `formatCommandRule` and `enableSyncCheck` → `syncCheck`.
> The rest drop the `disable` prefix and lower-case the first letter.

Conversion rule, per 1.x flag:

- `disableX: true` → emit `<positiveX>: false`
- `disableX: false` (or absent) → emit nothing (default is `true`)
- `enableSyncCheck: true` → emit `syncCheck: true` (opt into the gate; the 2.0 default is `false`)
- `enableSyncCheck: false` (or absent) → emit nothing (2.0 default is `false`)
  (sync-check remains opt-in: it was opt-in in 1.x and stays opt-in in 2.0 — only the flag name changed)

Example:

```yaml
# config.yaml (1.x)
flags:
  disableAppImpact: true
  disableDataChanges: true
  enableSyncCheck: true # opt-in → emit syncCheck: true
```

```yaml
# repo.yml (2.0)
flags:
  appImpact: false
  dataChanges: false
  syncCheck: true
```

A flag set in `repo.yml` that is not declared anywhere is a **validation error**
in 2.0 — re-check every emitted key against the table above.

### 1e. Selection maps — `include`/`exclude` → `name: true|false`

The 1.x top-level `skills`/`workflows` (and any per-feature) `{ include, exclude }`
lists become name→bool maps. `include` entries → `true`; `exclude` entries →
`false`. Globs are no longer permitted — expand any glob to the explicit catalog
names it matched in 1.x (read the 1.x synced output or `manifest.json` to see what
the glob actually resolved to).

The 1.x `workflows` selection map is **renamed** to `github-workflows` in 2.0 (the
content type only ever produces GitHub Actions workflows). Emit the new key —
there is no back-compat alias accepting `workflows:` (see the note at the end of
this sub-section). The `.github/workflows/skillshare-*.yml` **output** path is
unchanged — only the config key changed.

```yaml
# config.yaml (1.x)            →    repo.yml (2.0)
skills:                             skills:
  include: [openspec-apply]           openspec-apply-change: true
  exclude: [docs-init]                docs-init: false
workflows:                          github-workflows:
  include: [docs-to-confluence]       docs-to-confluence: true
  exclude: [openspec-to-confluence]   openspec-to-confluence: false
```

> **No alias, no version bump.** Skillshare 2.0 is unpublished, so this rename
> ships as part of the 1.x → 2.0 migration with no back-compat alias for the old
> `workflows:` key and no config-version bump — the migration simply emits the new
> `github-workflows:` name. This mirrors the `rules` → `openspec-rules` and
> `disable*` → positive-name renames elsewhere in this guide.

> Note the 1.x→2.0 skill **name** changes where they apply (e.g. the OpenSpec
> skills are `openspec-apply-change`, `openspec-new-change`, … in the 2.0
> catalog). Validate every name against `content/features.yaml` / the catalog;
> an unknown name is a sync error.

`agents` and `engineers` gain the same map shape (per-item control) but had no
1.x selection surface — only emit entries if the 1.x config force-included or
force-excluded one.

### 1f. Features — fully enumerated

Unlike every other section (deviations-only), the `features:` block **enumerates
every feature** with an explicit `true`/`false`, so a developer sees all available
feature sets and their state without consulting `global.yml`. The commented
template's `features:` block is already a full enumeration at the `global.yml`
defaults — start from it and, for each feature, write:

- the value from the source `config.yaml` if it set one (carrying any per-feature
  override object), or
- the `global.yml` default if the source omitted it.

This includes the default-on `skillshare-management` feature (it ships the
`skillshare-create-skill`, `skillshare-modify`, and `skillshare-migrate` skills);
leave it `true` unless the source explicitly disabled it.

Bare feature toggles (`auto-docs: true`) carry over as-is. 1.x per-feature
override objects used the `{ include, exclude }` shape; 2.0 uses the same
name→bool map shape as the top-level maps:

```yaml
# config.yaml (1.x) — only some features set
features:
  openspec-enhanced:
    enabled: true
    workflows:
      exclude: [openspec-to-confluence] # 1.x key — renamed below
  coding-engineers: false
```

```yaml
# repo.yml (2.0) — EVERY feature enumerated (source value, else global default)
features:
  skillshare-management: true # global default
  onboarding-skill: true # global default
  openspec-enhanced: # carried-over override object
    enabled: true
    github-workflows: # 1.x `workflows` → 2.0 `github-workflows`
      openspec-to-confluence: false
  auto-docs: true # global default
  ts-coding-standards: true # global default
  review-triage: true # global default
  coding-engineers: false # from source config.yaml
```

> Enumerate exactly the feature set that `global.yml` defines. Validate every
> feature name against `content/features.yaml`; an unknown feature is an error.

### 1g. Rules config — moved out of `repo.yml` entirely

2.0 has **no** `rules` selection key, no `rules.schema`, and no rule catalog.
Rules are composed per-artifact templates driven by a feature's `openspec-rules`
artifact map (with `openspec-context` supplying the config's context). Therefore:

- Drop any `rules:` block from the produced `repo.yml`.
- Move the **content** of any 1.x repo-local rule template (the bullet text the
  repo added under an artifact) into the matching flat splice file:

  | 1.x source              | 2.0 destination                          |
  | ----------------------- | ---------------------------------------- |
  | proposal rule additions | `.skillshare/openspec-rules/proposal.md` |
  | design rule additions   | `.skillshare/openspec-rules/design.md`   |
  | specs rule additions    | `.skillshare/openspec-rules/specs.md`    |
  | tasks rule additions    | `.skillshare/openspec-rules/tasks.md`    |

  Note the **flat, plain-named** layout — no `custom-` prefix and no `proposal/`,
  `design/` sub-folders (1.x used `.skillshare/rules/<artifact>/<name>.md`). 2.0
  reads `.skillshare/openspec-rules/<artifact>.md` directly from the repo and injects its
  rendered content into the composed artifact template. Each splice file holds
  YAML list items (lines starting with `- `). The repo-local scaffolding step
  (1i, below) creates these with comment-only placeholders; populate the matching
  one with the moved content.

If the 1.x repo only used the shared `base-<artifact>` rules with no repo-local
additions, no splice files are needed.

### 1h. Hooks / gitattributes / committedness

- `hooks.postSync` carries over only if it deviated from the org default
  (`{{ packageManager }} run format:fix`). Otherwise drop it.
- `gitattributes: false` carries over if set.
- If the repo wants to **keep** a content type committed during a staged
  migration, set `content.<type>.committed: true` in `repo.yml` (e.g.
  `content: { skills: { committed: true } }`). Otherwise omit `content` — the
  org default gitignores everything but `github-workflows`. The committedness
  content-type keys use the 2.0 ids: `github-workflows` (renamed from
  `workflows`, default committed) and `openspec-rules` (the rule-output id,
  default gitignored).

### 1i. Repo-local scaffolding + tracked `user.example.yml`

Bring the `.skillshare/` directory up to the same shape a fresh `skillshare init`
produces, **preserving any existing files** (never overwrite repo content):

- Create any missing repo-local subdirectory —
  `.skillshare/{skills,agents,engineers,instructions,openspec-rules,targets}/` — each with
  its explanatory `README.md`. (The resolver reserves `README.md`, so these docs
  are never mistaken for synced content.) This is also where the
  `.skillshare/openspec-rules/<artifact>.md` splice placeholders from 1g are created.
- Place a **tracked** `.skillshare/user.example.yml` (the copy-me starter for the
  personal layer). Do **not** create a gitignored `.skillshare/user.yml` — that is
  the per-developer copy each developer makes from the example, and it stays
  gitignored.

**Gate (validation):** the produced `repo.yml` must validate against the 2.0
partial schema. After writing it, a dry `skillshare check` (run later, after
postinstall wiring) confirms this. Present the full `repo.yml` to the user before
proceeding.

---

## Phase 2 — How 2.0 computes the committed surface and the `.gitignore` block

You do **not** need to read the CLI source to know what stays committed and what
gets ignored. 2.0 computes the managed `.gitignore` block **deterministically**
from the resolved configuration, and `skillshare sync` writes it (Phase 5). The
patterns are **narrow** — derived only from skillshare's own structural output
fields — so they cover only files skillshare generates and never sweep up
unrelated (foreign) files a tool directory may also contain. (This is why 2.0
needs **no** foreign-file pre-check: there is nothing for a narrow pattern to
accidentally ignore.)

The block is the union of:

- **Per-tool derived patterns.** For **every** tool defined in `global.yml`'s
  `toolDefinitions` (the defined set, not whichever tools you selected — so the
  committed block is identical for every developer), for each tool-dir content
  type whose `committed` resolves to `false`, the pattern derived from that type's
  structural field:

  | content type       | tool field        | emitted pattern (when not committed) |
  | ------------------ | ----------------- | ------------------------------------ |
  | skills             | `skillsDir`       | `<skillsDir>/*`                      |
  | agents / engineers | `agentsDir`       | `<agentsDir>/*`                      |
  | instructions       | `instructionFile` | `/<instructionFile>`                 |

  e.g. for `claude` (`skillsDir: .claude/skills`, `agentsDir: .claude/agents`,
  `instructionFile: CLAUDE.md`) with those types not committed, the block carries
  `.claude/skills/*`, `.claude/agents/*`, and `/CLAUDE.md` — **not** a coarse
  `.claude/*`.

- **Fixed paths.** `/openspec/config.yaml` (when `rules` is not committed),
  `.skillshare/README.md` (when `readme` is not committed), and the always-ignored
  `.skillshare/manifest.user.json` (the per-machine manifest) and `.skillshare/user.yml`.
  The committed lockfile `.skillshare/manifest.json` is **not** ignored — it is a
  committed artifact that `check --ci` verifies against.

Workflows stay committed, so no workflow pattern appears. A content type set to
`content.<type>.committed: true` in `repo.yml` is **excluded** from the block (its
files stay committed). Directory patterns use the `dir/*` form (not `dir/`) so a
later `!dir/<file>` negation outside the managed block can re-include a single
file. Patterns are sorted and deduplicated, so the block is byte-identical across
machines given the same `global.yml` + `repo.yml` (it never depends on `user.yml`;
a developer's user-only tool patterns route to `.git/info/exclude` instead).

**The upshot for un-tracking (Phase 3):** the set of previously-committed managed
paths you must un-track is exactly the set the freshly-written `.gitignore` block
now covers — every output under an ignored tool dir, the ignored instruction
files, and the ignored fixed paths. Workflows stay committed.

---

## Phase 3 — Un-track the now-ignored managed outputs

2.0 gitignores generated outputs; the previously committed copies must be
**un-tracked** (removed from the index) while staying on disk. Un-track exactly
the previously-committed managed paths that the `.gitignore` block covers — the
set is deterministic from the committed config (Phase 2), so you know it before
`sync` actually writes the block in Phase 5. No foreign-file decision gate is
needed, because the narrow derived patterns never reach non-managed files.

1. Read every path from `.skillshare/manifest.json` (the authoritative list of the
   1.x committed managed files).
2. **Exclude** the still-committed surface from un-tracking — `.github/workflows/skillshare-*.yml`
   stay committed in 2.0 (they are not in the `.gitignore` block). Do not
   `git rm --cached` those.
3. For every other manifest path (i.e. every managed path the block now covers):
   `git rm --cached -- <path>` (note `--cached`: removes from the index only,
   leaves the working-tree file intact).

```bash
# Conceptually, for each non-workflow path P in manifest.json:
git rm --cached -- "$P"
```

**Do NOT** delete working-tree files. After this phase, `git status` shows the
un-tracked files as deletions staged from the index plus new untracked files on
disk — that is expected; the managed `.gitignore` block keeps them untracked going
forward.

**Gate:** every non-workflow manifest path is un-tracked; working-tree copies
still present on disk.

---

## Phase 4 — Wire the bootstrap (postinstall + README)

### 4a. postinstall

Add `skillshare sync --yes` to `package.json` `scripts.postinstall`, **chaining**
any existing script with `&&` rather than overwriting it. The `--yes` flag is
required because postinstall runs non-interactively (fresh installs, CI).

- No existing `postinstall` → set `"postinstall": "skillshare sync --yes"`.
- Existing `postinstall` (e.g. `"husky"`) → set `"postinstall": "husky && skillshare sync --yes"`.
- Already contains `skillshare sync` (bare or `--yes`) → leave unchanged (idempotent); do not rewrite a bare command in place.

### 4b. README pointer section

Add a short section to the repo's `README.md` pointing developers at the managed
setup. **Placement is agent-judged** — pick a natural location (near
"Development" / "Getting Started"). This is brief prose, **not** a managed block.
Convey: skillshare-managed AI instruction/skill files are gitignored and
regenerated on install; running the install step (`<packageManager> install`)
triggers `postinstall` → `skillshare sync --yes`, which materializes them. Example:

```markdown
## AI tooling (skillshare)

AI instruction files, skills, and OpenSpec rules in this repo are managed by
[@msys/skillshare](https://github.com/FoundfairVC/msys-skillshare) and are
gitignored. They regenerate automatically on `<packageManager> install` (via the
`postinstall` hook). To regenerate manually, run `skillshare sync`.
```

**Gate:** postinstall chained correctly; README section added at a sensible spot.

---

## Phase 5 — First 2.0 sync + verify

1. Run the **first 2.0 sync**: `skillshare sync`. This writes the regenerated
   outputs, the managed `.gitignore` block (computed from the committed surface),
   and the `.gitattributes` block, and runs the post-sync hook.
2. Run `skillshare check --ci`. The committed surface (workflows + `.gitignore`
   block) must match the committed config. A clean result confirms `repo.yml`
   validates and the committed surface is consistent.
3. Surface `git diff` (and `git status`) for the user to review:
   - **Deletions** (staged): the un-tracked outputs from Phase 3 — expected.
   - **`.gitignore`**: a new managed block listing the narrow per-tool derived
     patterns (`.claude/skills/*`, `/CLAUDE.md`, …) and the fixed paths — expected.
   - **`.gitattributes`**: shrinks to committed outputs (workflows) only.
   - **`.github/workflows/skillshare-*.yml`**: may update to the 2.0-rendered
     content — expected and committed.
   - **`package.json`**: the postinstall change.
   - **`.skillshare/repo.yml`**: the transformed config (built from the commented
     template, features fully enumerated) carrying `schemaVersion: 2`;
     `config.yaml` removed.
   - **`.skillshare/`**: the tracked `user.example.yml`, any newly scaffolded
     `{skills,agents,engineers,instructions,openspec-rules,targets}/README.md` files, and
     any populated `.skillshare/openspec-rules/<artifact>.md` splice files — expected
     (tracked). No `.skillshare/user.yml` is created.
   - **`README.md`**: the new pointer section.
4. Confirm no template/render errors and that working-tree copies of the
   un-tracked outputs are still present.

**Gate:** `skillshare sync` runs clean, `skillshare check --ci` passes, the diff
matches the expectations above. Present the diff summary to the user for the
commit decision (do not commit automatically).

---

## 2 → 3+ (config-schema transforms)

> This section is a **shape note** for future schema majors. It has no concrete
> steps yet — when a `2 → 3` (or later) transition ships, its transform rules are
> filled in here, one sub-section per stale surface. Until then, a repo at
> `schemaVersion: 2` with a current CLI is already current and needs no migration.

Once a repo has completed `1 → 2`, every later major is a **pure config-schema
transform**. The structural work (un-tracking, postinstall wiring, gitignore
block) was a one-time event in `1 → 2` and is **never repeated** — outputs are
already gitignored. A `2 → 3+` migration therefore:

- Reads only the stale surface(s) the gap names — `repo.yml`, `user.yml`, or both.
- Rewrites those file(s) to the new schema and bumps their `schemaVersion` to the
  CLI's supported major.
- Does **not** run `git rm --cached`, edit `package.json` postinstall, or touch
  the `.gitignore` block.
- Verifies with a final `skillshare sync` (re-renders from the migrated config)
  and, for a committed-surface change, `skillshare check --ci`.

### `repo.yml` (committed surface)

A stale `repo.yml` (its `schemaVersion` lower than the CLI major) drives a **team
migration**. Transform the committed `repo.yml` to the new schema per this
section's (future) rules, set its `schemaVersion` to the new major, present the
diff, and verify with `skillshare sync` + `skillshare check --ci`. Do not touch
`user.yml` or re-run any structural step.

### `user.yml` (personal surface)

A developer's `user.yml` is migrated **standalone**. When `repo.yml` is already
current but a developer's `user.yml` declares an older `schemaVersion`, the
committed surface is unaffected (skillshare drops the stale `user.yml` from the
merge with a warning, never blocking the team). Migrate `.skillshare/user.yml`
alone:

- Transform `user.yml` to the new schema per this section's (future) rules and set
  its `schemaVersion` to the new major.
- A `user.yml` that carries any active (non-comment) keys MUST declare
  `schemaVersion`; an absent or entirely-commented `user.yml` is version-agnostic
  and needs no migration.
- Do **not** read or modify the committed `repo.yml`, and do **not** run any
  structural step. Verify with `skillshare sync`; `check --ci` is unaffected (it
  ignores `user.yml` by design).

---

## Minor upgrades within schema major 2

A minor `@msys/skillshare` release can change sync OUTPUT behavior without a
config-schema transition: `schemaVersion` stays `2`, no surface is detected as
stale, and the migrate skill plays no part. Each entry below is a one-time,
per-repo follow-up surfaced by the first `skillshare sync` after the bump.

### `.github/copilot-instructions.md` becomes committed (AIM-145)

GitHub's Copilot PR reviewer reads `.github/copilot-instructions.md`
**server-side from the committed tree** — a gitignored copy is invisible to it,
exactly as an uncommitted GitHub workflow would never run. The `github-copilot`
tool definition therefore ships `serverSideInstructions: true`: its instruction
file is committed by necessity (in repos whose committed `tools` selection
includes the tool), while every other instruction file (CLAUDE.md
etc., read locally) stays gitignored.

After bumping to a version with this capability, in each consumer repo **whose
committed `tools` selection includes `github-copilot`** (an omitted `tools` key —
the default — selects all tools; a repo that excludes the tool keeps the file
gitignored and skips these steps):

1. Run `skillshare sync` (the postinstall hook does this on install). The
   managed `.gitignore` block no longer contains
   `/.github/copilot-instructions.md`, so the regenerated file shows up as
   **untracked**; the `.gitattributes` managed block gains its
   `linguist-generated` entry; the committed lockfile
   `.skillshare/manifest.json` gains its entry.
2. One-time: `git add .github/copilot-instructions.md` and commit it together
   with the sync-updated `.gitignore`, `.gitattributes`, and
   `.skillshare/manifest.json` — from this commit on, the Copilot reviewer can
   finally read its instructions.

Afterwards the file is an ordinary committed managed output: `skillshare sync`
keeps it up to date and `skillshare check --ci` verifies it. No
`git rm --cached`, no postinstall change, no `schemaVersion` change.

Rolling back the bump requires one extra step: run
`git rm --cached .github/copilot-instructions.md` (and commit) **before** the
downgraded version syncs again. The old planner renders this path as an
ordinary user-surface instruction file with personal instruction anchors
active, and the restored `.gitignore` pattern does not protect an
already-tracked file — without the index removal, a later sync could put
per-developer personal content into a tracked diff.

**Stricter structural-path validation (same release).** Tool-definition path
fields (`skillsDir`, `agentsDir`, `instructionFile`) are now validated as
literal, canonical, gitignore-neutral write locations. If `skillshare sync`
fails after the bump with an error like `skillsDir must be a canonical
repo-relative path …` or `… is a literal path — glob metacharacters … are not
allowed`, a custom `toolDefinitions` entry carries a value the validation now
rejects (globs, dot segments, `//`, backslashes, leading/trailing `/`, leading
`!`/`#`, surrounding whitespace, control characters, or a `.git/` path).
Correct the path — such values previously produced broken managed-`.gitignore`
patterns silently. Built-in tools are unaffected.

---

## Rollback

If the migration must be reverted on a repo:

1. Pin the skillshare dependency back to the last 1.x version in `package.json`
   (the exact version the repo used before — 1.x consumers pin exact versions).
2. `git revert` the migration commit. This restores `.skillshare/config.yaml`,
   re-tracks the previously committed outputs, removes the `repo.yml` /
   `user.yml` / postinstall / README changes, and restores the 1.x `.gitignore` /
   `.gitattributes` state.
3. Reinstall dependencies and run the 1.x `skillshare sync` to regenerate the 1.x
   committed outputs.

Because 1.x keeps working independently, repos migrate when they bump the
dependency; a per-repo rollback never affects other repos.
