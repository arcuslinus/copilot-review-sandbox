# @msys/skillshare

Shared AI skills, instruction file templates, and AI workflows for cross-repository development tooling at MeisterSystems.

## Documentation

> Auto-generated table of contents. Do not edit manually — maintained by `/docs-add`, `/docs-audit` and `/docs-revise` skills.

### Architecture

<!-- prettier-ignore -->
| Document | Description |
|---|---|
| [Config cascade](docs/architecture/config-cascade.md) | Three-layer config resolution (global/repo/user), merge semantics, selection maps, flags, and the committed-surface guard |
| [Confluence pipelines](docs/architecture/confluence-pipelines.md) | Two GitHub Actions pipelines that publish docs and OpenSpec artifacts to Confluence |
| [Infrastructure](docs/architecture/infrastructure.md) | CDK stack for CodeBuild runners, OIDC provider, and IAM roles |
| [Output management](docs/architecture/output-management.md) | Gitignored outputs, managed gitignore/exclude blocks, postinstall bootstrap, and per-type committedness |
| [Sync engine](docs/architecture/sync-engine.md) | Core sync pipeline from cascade resolution through manifest update and stale file cleanup |
| [Template rendering](docs/architecture/template-rendering.md) | Nunjucks environment, dual-root loader, instruction templates, composition, and splice points |

### Features

<!-- prettier-ignore -->
| Document | Description |
|---|---|
| [Auto docs](docs/features/feature-sets/auto-docs.md) | Docs skills and Confluence workflow for automated documentation lifecycle |
| [Coding engineers](docs/features/feature-sets/coding-engineers.md) | Domain-specific coding engineer definitions that sync as agent definitions or skill fallbacks per tool |
| [Git commands](docs/features/feature-sets/git-commands.md) | On-demand git-* skills carrying the org's commit/PR conventions, plus branch and worktree cleanup |
| [Skillsets](docs/features/feature-sets/skillsets.md) | Background skillset dispatch engine — triage and run post-implementation follow-up work (docs, QA, checklist, PR) as sub-agents or on the main agent |
| [Onboarding skill](docs/features/feature-sets/onboarding-skill.md) | Guided onboarding skill for first-time skillshare setup |
| [Openspec enhanced](docs/features/feature-sets/openspec-enhanced.md) | OpenSpec workflow skills, Confluence sync, PR quality gates, and baseline rules |
| [Overview](docs/features/feature-sets/overview.md) | What feature sets are, how they work, expansion and override mechanism |
| [Review triage](docs/features/feature-sets/review-triage.md) | Two skills for triaging and resolving PR review comments from bots or human reviewers |
| [Ts coding standards](docs/features/feature-sets/ts-coding-standards.md) | Strict TypeScript coding standards (no `!`, no `any`) |
| [Ts7 lsp](docs/features/feature-sets/ts7-lsp.md) | TypeScript code intelligence for Claude Code via the workspace-pinned native language server (TS ≥ 7) |
| [Auto skip](docs/features/pr-quality-gates/auto-skip.md) | Meta-file pattern detection for auto-skipping PR quality gates |
| [Docs check](docs/features/pr-quality-gates/docs-check.md) | Enforces docs/ updates when OpenSpec tasks reference docs-revise |
| [Openspec check](docs/features/pr-quality-gates/openspec-check.md) | Enforces archived OpenSpec change with valid ticket ID on every PR |
| [Overview](docs/features/pr-quality-gates/overview.md) | PR quality assessment workflow architecture with feature- and flag-gated jobs |
| [Sync check](docs/features/pr-quality-gates/sync-check.md) | Default-on PR job that runs skillshare check --ci to verify the committed surface |

### Guides

<!-- prettier-ignore -->
| Document | Description |
|---|---|
| [Adding content](docs/guides/adding-content.md) | How to add skills, workflows, rules, flags, feature sets, and custom tools |
| [Bumping the OpenSpec dependency](docs/guides/bumping-openspec.md) | Re-vendoring the openspec skills when bumping `@fission-ai/openspec`, via the `skillshare-bump-openspec` skill |
| [Migrating from 1 x](docs/guides/migrating-from-1-x.md) | Consumer-facing 1.x to 2.0 migration via the skillshare-migrate skill |
| [Onboarding consumer repo](docs/guides/onboarding-consumer-repo.md) | Step-by-step guide for adding skillshare to a new repository |
| [Releasing](docs/guides/releasing.md) | Changesets workflow, Release PR flow, and CodeArtifact publishing |

### Setup

<!-- prettier-ignore -->
| Document | Description |
|---|---|
| [Getting started](docs/setup/getting-started.md) | Prerequisites, install, build, test, and run CLI locally |
